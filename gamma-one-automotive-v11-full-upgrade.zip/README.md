# Gamma One — Next.js Luxury Automotive Platform v8.3

Versione v4: direzione **B / luxury automotive / Awwwards**, non più SIXT-oriented.  
Obiettivo: un sistema gestibile dove il proprietario entra, aggiunge auto/moto, modifica prezzi, vede lead e gestisce appuntamenti.

## Cosa contiene

### Pubblico
- Home luxury con hero cinematografica.
- Showroom scenografico.
- Ricerca avanzata stile AutoScout ma più premium.
- 20 veicoli demo:
  - 10 auto
  - 10 moto/scooter
  - vendita
  - noleggio
  - luxury
  - normali
- Schede dinamiche `/veicoli/[slug]`.
- Richiesta su misura.
- Calendario appuntamenti.
- Privacy, cookie, condizioni vendita, condizioni noleggio.

### Proprietario / Staff
- `/login` login Supabase Auth.
- `/admin` dashboard.
- `/admin/veicoli` gestione catalogo.
- `/admin/lead` pipeline richieste.
- `/admin/calendario` gestione appuntamenti.

### Backend / integrazioni
- Supabase/PostgreSQL.
- Prisma schema.
- API CRUD veicoli.
- API lead.
- API appuntamenti.
- Upload foto Cloudinary o S3.
- Resend email.
- WhatsApp link/API.
- Google Calendar.
- Cookie consent log.

## Avvio locale

```bash
npm install
cp .env.example .env.local
npm run dev
```

Apri:

```bash
http://localhost:3000
```

## Configurazione Supabase

1. Crea progetto Supabase.
2. Compila `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
DATABASE_URL=
```

3. Esegui in Supabase SQL Editor:

```text
supabase/schema.sql
```

4. Crea utenti:

```text
Supabase → Authentication → Users
```

5. Accedi da:

```text
/login
```

## Upload foto

Cloudinary:

```env
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
CLOUDINARY_URL=
```

Oppure S3:

```env
S3_REGION=
S3_BUCKET=
S3_ACCESS_KEY_ID=
S3_SECRET_ACCESS_KEY=
S3_PUBLIC_BASE_URL=
```

Endpoint:

```text
POST /api/upload
```

## Lead / Email

```env
RESEND_API_KEY=
LEAD_NOTIFICATION_EMAIL=
RESEND_FROM=
```

Endpoint:

```text
POST /api/leads
PATCH /api/leads/[id]
```

## Calendario

```env
GOOGLE_CALENDAR_ID=
GOOGLE_CLIENT_EMAIL=
GOOGLE_PRIVATE_KEY=
```

Endpoint:

```text
POST /api/appointments
PATCH /api/appointments/[id]
```

## WhatsApp

Link precompilato:

```env
NEXT_PUBLIC_COMPANY_WHATSAPP=
```

WhatsApp API:

```env
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_ACCESS_TOKEN=
```

## Nota immagini

Le immagini demo sono placeholder da URL pubblici per mockup. Per produzione vanno sostituite con foto reali dei mezzi o immagini con licenza corretta. Non usare immagini prese da Google senza autorizzazione.

## Stato del progetto

Questa è una bozza tecnica avanzata. Non è ancora produzione finale finché non vengono inseriti:

- dati reali aziendali
- veicoli reali
- foto reali
- condizioni noleggio reali
- condizioni vendita reali
- privacy/cookie revisionate
- account e chiavi API reali
- test finale mobile/performance/security


## Typography

La v6 usa una gerarchia tipografica più premium:

- Titoli grandi: `Instrument Serif`
- UI, menu, form e bottoni: `Inter`
- Prezzi, km, CV e numeri: `Space Grotesk`

La regola è: serif solo per momenti editoriali, sans per leggibilità, numeric font per dati automotive.


## v7 additions

Questa versione aggiunge una struttura molto più completa:

- Pagine pubbliche dedicate:
  - `/veicoli`
  - `/noleggio`
  - `/permuta`
  - `/ricerca-su-richiesta`
  - `/chi-siamo`
  - `/contatti`
  - `/garanzia`
  - `/finanziamento`
- WhatsApp contestuale per veicolo, noleggio, permuta e ricerca su richiesta.
- Sezione Metodo Gamma One.
- Sezione fiducia e trasparenza.
- Sitemap dinamica.
- Robots con blocco admin/login/api.
- API PATCH/DELETE per veicoli.
- API PATCH per richieste e appuntamenti.
- Punteggio qualità schede veicolo in admin.
- Campi mancanti segnalati nel pannello veicoli.
- Footer e navigazione pubblica più commerciali.


## v7.1 fix

- Corretto errore JSX in `components/ui.tsx` nel footer: chiusura mancante del link Calendario.


## v8 clean rebuild

Questa versione corregge la direzione della v7:

- Home molto più corta e ordinata.
- Mega filtri rimossi dalla home.
- Catalogo avanzato spostato su `/veicoli`.
- Filtri più leggibili, meno invasivi e con `select option` corretto.
- Card veicolo più pulite.
- Header e footer più premium.
- Logo SVG originale inserito nel codice.
- Icone SVG originali per servizi.
- Asset generati inclusi in `/public/brand`:
  - `gamma-one-brand-board.png`
  - `gamma-one-icon-system-board.png`
- CSS ripulito e riorganizzato.
- Focus su: luxury davanti, gestionale dietro, contatti ordinati al centro.


## v8.1 image coherence

- Dataset demo ridotto e reso più coerente.
- Le immagini principali sono ora abbinate al modello o a una variante molto vicina tramite Wikimedia Commons.
- Aggiunto `IMAGE_LICENSES.md` con le fonti.
- Le immagini restano illustrative: non sono veicoli reali in stock.


## v8.2 polish

Questa versione non aggiunge funzioni: rifinisce la base.

- Metadata pubblici ripuliti.
- Tolto riferimento ad “Automotive OS”.
- Titoli leggermente meno compressi.
- Contrasto dei testi secondari migliorato.
- Card veicolo più leggibili.
- Prezzi meno aggressivi.
- Badge “Immagine illustrativa” sulle immagini demo.
- Miglioramento mobile su titoli e card.


## v8.3 motion

Questa versione aggiunge micro-interazioni premium senza trasformare il sito in un luna park:

- Scroll progress bar.
- Spotlight ambientale leggero collegato al mouse.
- Reveal on scroll con IntersectionObserver.
- Hero parallax leggero.
- Hero entrance animation.
- Hover più morbidi su card, servizi, pulsanti e pannelli.
- Shine leggero su bottoni e card servizi.
- Supporto `prefers-reduced-motion` per accessibilità.

Niente librerie pesanti aggiunte. Tutto via CSS + piccolo componente client.
