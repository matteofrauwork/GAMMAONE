# Gamma One — upgrade 10/10 applicato

Questa versione trasforma il progetto da sito automotive avanzato a base commerciale più vendibile:

- scheda veicolo con decision panel, trust strip e trasparenza dati;
- catalogo con preset rapidi, KPI di risultati e filtri più orientati alla conversione;
- card veicolo più premium con badge commerciali e CTA più chiare;
- dashboard dealer più operativa con priorità, alert produzione e qualità inventario;
- scoring qualità annuncio e priorità lead riutilizzabili nel backend;
- documentazione di consegna e checklist produzione.

## Cose da chiudere prima di venderlo come produzione

1. Sostituire immagini illustrative con foto reali.
2. Collegare Supabase reale e disattivare uso mock per il cliente.
3. Configurare WhatsApp, email lead e calendario aziendale.
4. Verificare privacy/cookie con consulente.
5. Testare Lighthouse mobile e form da telefono.
6. Inserire dati reali: condizioni, garanzie, documenti, costi accessori.

## Posizionamento commerciale consigliato

Non venderlo come semplice sito. Posizionalo come:

> Ecosistema automotive premium con catalogo gestibile, lead management, richieste finanziamento/noleggio/permuta e dashboard proprietario.
