# Gamma One — consegna cliente

## Cosa riceve il cliente

- sito pubblico premium;
- catalogo veicoli filtrabile;
- schede veicolo con CTA WhatsApp/appuntamento/finanziamento;
- area dealer per gestione stock, lead, clienti, appuntamenti e follow-up;
- predisposizione Supabase, email, calendario, Cloudinary/S3;
- SEO locale e dati strutturati base.

## Cosa NON promettere se non configurato

- upload immagini reale senza provider configurato;
- CRM multiutente production senza Supabase reale;
- email automatiche senza Resend;
- calendario automatico senza Google Calendar;
- privacy/cookie legalmente validati senza controllo consulente.

## Training proprietario

1. Accedere all'area dealer.
2. Creare/modificare veicolo.
3. Caricare immagini e ordinare gallery.
4. Controllare qualità scheda.
5. Gestire richiesta cliente e follow-up.
6. Aggiornare stato veicolo: bozza, online, venduto, nascosto.
