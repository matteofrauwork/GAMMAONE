# Gamma One Automotive V11 - Full Upgrade

Questa versione non aggiunge solo estetica: rafforza conversione, catalogo, scheda veicolo, validazione e argomentazione commerciale.

## Upgrade applicati

- Nuovo `lib/commercial.ts` con:
  - stima rata indicativa
  - fit score commerciale veicolo
  - next best action per ogni scheda
  - temperatura lead
- Nuovo `components/conversion-kit.tsx` con:
  - pannello decisione rapida in scheda veicolo
  - micro facts sopra la piega
  - stima finanziamento
  - CTA WhatsApp / appuntamento / simulazione
  - trust bar catalogo
- Scheda veicolo migliorata:
  - fatti chiave più visibili
  - pannello conversione dopo narrative
  - ragionamento più orientato alla decisione
- Catalogo migliorato:
  - trust bar con disponibili, finanziabili e vendita/noleggio
  - KPI stock più pulito
- API lead migliorata:
  - parsing JSON protetto
  - validazione telefono/email/nome/messaggio
  - errori più chiari per il cliente
- API appuntamenti migliorata:
  - parsing JSON protetto
  - validazione telefono/email/data/slot
  - riduzione richieste spazzatura
- CSS premium aggiunto:
  - conversion cards
  - trust bar
  - micro facts
  - responsive conversion grid

## Cosa resta da fare per produzione vera

1. Eseguire `npm install`.
2. Eseguire `npm run validate`.
3. Collegare Supabase reale.
4. Inserire foto vere dei veicoli.
5. Configurare Cloudinary o S3.
6. Configurare Resend per email lead.
7. Configurare numero WhatsApp aziendale.
8. Verificare policy privacy/cookie con dati reali.
9. Fare test mobile reale su iPhone/Android.
10. Sostituire ogni immagine illustrativa con stock reale quando il cliente carica mezzi veri.

## Posizionamento commerciale consigliato

Non venderlo come sito vetrina. La frase corretta è:

> Piattaforma automotive premium per catalogo veicoli, richieste clienti, appuntamenti, permuta, finanziamento e lead management leggero.

Prezzo coerente se rifinito e configurato: 4.000-7.000 euro. Sotto 3.000 euro è sottoprezzato.
