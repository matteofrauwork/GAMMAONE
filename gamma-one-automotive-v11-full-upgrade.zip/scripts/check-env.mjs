const required = [
  "NEXT_PUBLIC_SITE_URL",
  "NEXT_PUBLIC_COMPANY_WHATSAPP",
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "DATABASE_URL"
];
const optional = ["RESEND_API_KEY", "LEAD_EMAIL_TO", "CLOUDINARY_URL", "S3_BUCKET", "GOOGLE_CALENDAR_ID"];
const missing = required.filter((key) => !process.env[key]);
const presentOptional = optional.filter((key) => Boolean(process.env[key]));
console.log("Gamma One env check");
console.log("Required missing:", missing.length ? missing.join(", ") : "none");
console.log("Optional configured:", presentOptional.length ? presentOptional.join(", ") : "none");
if (missing.length) process.exitCode = 1;
