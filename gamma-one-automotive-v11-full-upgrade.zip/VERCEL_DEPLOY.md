# Gamma One - Deploy Vercel

Questo pacchetto e pronto per essere caricato su Vercel come progetto Next.js.

## Cosa caricare

Carica tutto il contenuto dello ZIP, mantenendo la struttura delle cartelle.

Non servono queste cartelle locali:

- `node_modules`
- `.next`
- `.npm-cache`

Sono escluse dallo ZIP perche Vercel installa le dipendenze e genera la build da solo.

## Impostazioni Vercel

- Framework: Next.js
- Install command: `npm install`
- Build command: `npm run build`
- Output directory: lasciare vuoto / default
- Node.js: versione 20 o superiore

## Variabili ambiente

In Vercel apri:

`Project Settings -> Environment Variables`

Inserisci le variabili presenti in `.env.example`.

Minime per aprire il sito demo:

```env
NEXT_PUBLIC_SITE_URL=https://tuo-link-vercel.vercel.app
NEXT_PUBLIC_COMPANY_NAME=Gamma One
NEXT_PUBLIC_COOKIE_CONSENT_VERSION=2026-05-v1
COOKIE_CONSENT_VERSION=2026-05-v1
PRIVACY_POLICY_VERSION=2026-05-v1
```

Per renderlo operativo con backend reale servono anche:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
RESEND_API_KEY=
LEAD_NOTIFICATION_EMAIL=
NEXT_PUBLIC_COMPANY_WHATSAPP=
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
CLOUDINARY_URL=
GOOGLE_CALENDAR_ID=
GOOGLE_CLIENT_EMAIL=
GOOGLE_PRIVATE_KEY=
```

## Supabase

1. Crea un progetto Supabase.
2. Apri SQL Editor.
3. Incolla ed esegui `supabase/schema.sql`.
4. Crea gli utenti admin in Supabase Auth.
5. Inserisci i profili nella tabella `admin_profiles` con ruolo:
   - `owner`
   - `staff`
   - `editor`
   - `viewer`

## Nota importante

I veicoli e le immagini incluse sono demo/illustrative. Prima della presentazione finale al cliente sostituire:

- foto reali dei veicoli
- veicoli reali
- telefono, email, WhatsApp, sede operativa e orari
- condizioni vendita e noleggio definitive
- privacy/cookie revisionate legalmente

## Test eseguiti prima dello ZIP

- `npm.cmd run typecheck`: OK
- `npm.cmd run lint`: OK
- `npm.cmd run build`: OK

La build locale Windows richiede il workaround presente in `next.config.mjs`. Su Vercel va testata la build: se Vercel compila senza problemi, si puo valutare di rimuovere il blocco `experimental`.
