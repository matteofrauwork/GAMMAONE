-- Replace the email and role before running.
-- Roles: owner, staff, editor, viewer.

insert into public.admin_profiles (id, role, full_name, active)
select id, 'owner'::public.admin_role, 'Gamma One Owner', true
from auth.users
where email = 'owner@gammaone.it'
on conflict (id) do update
set role = excluded.role,
    full_name = excluded.full_name,
    active = true,
    updated_at = now();
