-- Gamma One production Supabase schema
-- Run in Supabase SQL Editor. Then create users in Auth and insert their roles in admin_profiles.

create extension if not exists "pgcrypto";

do $$
begin
  create type public.admin_role as enum ('owner', 'staff', 'editor', 'viewer');
exception
  when duplicate_object then null;
end $$;

do $$
begin
  create type public.vehicle_visibility as enum ('public', 'draft', 'hidden');
exception
  when duplicate_object then null;
end $$;

do $$
begin
  create type public.saved_vehicle_kind as enum ('favorite', 'compare');
exception
  when duplicate_object then null;
end $$;

create table if not exists public.admin_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.admin_role not null default 'viewer',
  full_name text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  brand text not null,
  model text not null,
  version text,
  year integer not null,
  registration_month text,
  km integer not null default 0 check (km >= 0),
  price integer not null default 0 check (price >= 0),
  monthly_from integer check (monthly_from is null or monthly_from >= 0),
  rent_daily_from integer check (rent_daily_from is null or rent_daily_from >= 0),
  location text not null default 'Sardegna',
  distance_km integer not null default 0 check (distance_km >= 0),
  body text not null default 'Berlina',
  fuel text not null default 'Benzina',
  gearbox text not null default 'Manuale',
  power_hp integer not null default 0 check (power_hp >= 0),
  displacement text,
  doors integer default 5 check (doors >= 0),
  seats integer default 5 check (seats >= 0),
  color text,
  seller text not null default 'Gamma One',
  service text not null default 'Vendita',
  status text not null default 'Disponibile',
  visibility public.vehicle_visibility not null default 'draft',
  warranty_months integer check (warranty_months is null or warranty_months >= 0),
  finance boolean not null default false,
  iva boolean not null default false,
  neopatentati boolean not null default false,
  description text not null default '',
  hero_image text,
  video_url text,
  images jsonb not null default '[]'::jsonb,
  equipment jsonb not null default '[]'::jsonb,
  highlights jsonb not null default '[]'::jsonb,
  inspection jsonb not null default '{}'::jsonb,
  price_rating text,
  published_at timestamptz,
  created_by uuid references auth.users(id),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vehicle_images (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  url text not null,
  alt text,
  position integer not null default 0,
  is_cover boolean not null default false,
  is_real_photo boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  type text not null default 'Richiesta generica',
  message text not null,
  vehicle_slug text,
  status text not null default 'Nuovo',
  score integer not null default 0 check (score >= 0 and score <= 100),
  privacy_consent boolean not null default true,
  assigned_to uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  slot text not null,
  reason text not null default 'Visione veicolo',
  name text not null,
  phone text not null,
  email text,
  vehicle text,
  status text not null default 'Richiesto',
  assigned_to uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  email text,
  source text not null default 'Richiesta sito',
  interest text not null default '',
  status text not null default 'Nuovo',
  assigned_to uuid references auth.users(id),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.follow_ups (
  id uuid primary key default gen_random_uuid(),
  due_at timestamptz not null,
  customer_id uuid references public.customers(id) on delete set null,
  lead_id uuid references public.leads(id) on delete set null,
  title text not null,
  channel text not null default 'Telefono',
  status text not null default 'Da fare',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.cookie_consents (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'essential',
  version text not null,
  categories jsonb not null default '{}'::jsonb,
  user_agent text,
  ip text,
  created_at timestamptz not null default now()
);

create table if not exists public.user_vehicle_lists (
  user_id uuid not null references auth.users(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  kind public.saved_vehicle_kind not null,
  created_at timestamptz not null default now(),
  primary key (user_id, vehicle_id, kind)
);

create table if not exists public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  path text,
  vehicle_slug text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists touch_admin_profiles_updated_at on public.admin_profiles;
create trigger touch_admin_profiles_updated_at
before update on public.admin_profiles
for each row execute function public.touch_updated_at();

drop trigger if exists touch_vehicles_updated_at on public.vehicles;
create trigger touch_vehicles_updated_at
before update on public.vehicles
for each row execute function public.touch_updated_at();

drop trigger if exists touch_leads_updated_at on public.leads;
create trigger touch_leads_updated_at
before update on public.leads
for each row execute function public.touch_updated_at();

drop trigger if exists touch_appointments_updated_at on public.appointments;
create trigger touch_appointments_updated_at
before update on public.appointments
for each row execute function public.touch_updated_at();

drop trigger if exists touch_customers_updated_at on public.customers;
create trigger touch_customers_updated_at
before update on public.customers
for each row execute function public.touch_updated_at();

drop trigger if exists touch_follow_ups_updated_at on public.follow_ups;
create trigger touch_follow_ups_updated_at
before update on public.follow_ups
for each row execute function public.touch_updated_at();

create or replace function public.current_admin_role()
returns public.admin_role
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.admin_profiles
  where id = auth.uid()
    and active = true
  limit 1
$$;

create or replace function public.has_admin_role(allowed public.admin_role[])
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_admin_role() = any(allowed), false)
$$;

alter table public.admin_profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.vehicle_images enable row level security;
alter table public.leads enable row level security;
alter table public.appointments enable row level security;
alter table public.customers enable row level security;
alter table public.follow_ups enable row level security;
alter table public.cookie_consents enable row level security;
alter table public.user_vehicle_lists enable row level security;
alter table public.analytics_events enable row level security;

drop policy if exists "Admins read profiles" on public.admin_profiles;
create policy "Admins read profiles"
on public.admin_profiles for select
to authenticated
using (id = auth.uid() or public.has_admin_role(array['owner']::public.admin_role[]));

drop policy if exists "Owners manage profiles" on public.admin_profiles;
create policy "Owners manage profiles"
on public.admin_profiles for all
to authenticated
using (public.has_admin_role(array['owner']::public.admin_role[]))
with check (public.has_admin_role(array['owner']::public.admin_role[]));

drop policy if exists "Public read published vehicles" on public.vehicles;
create policy "Public read published vehicles"
on public.vehicles for select
to anon, authenticated
using (visibility = 'public' and status in ('Disponibile', 'In arrivo', 'Prenotato'));

drop policy if exists "Admins read all vehicles" on public.vehicles;
create policy "Admins read all vehicles"
on public.vehicles for select
to authenticated
using (public.has_admin_role(array['owner','staff','editor','viewer']::public.admin_role[]));

drop policy if exists "Editors manage vehicles" on public.vehicles;
create policy "Editors manage vehicles"
on public.vehicles for insert
to authenticated
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Editors update vehicles" on public.vehicles;
create policy "Editors update vehicles"
on public.vehicles for update
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Owners delete vehicles" on public.vehicles;
create policy "Owners delete vehicles"
on public.vehicles for delete
to authenticated
using (public.has_admin_role(array['owner','staff']::public.admin_role[]));

drop policy if exists "Public read vehicle images" on public.vehicle_images;
create policy "Public read vehicle images"
on public.vehicle_images for select
to anon, authenticated
using (
  exists (
    select 1 from public.vehicles v
    where v.id = vehicle_images.vehicle_id
      and v.visibility = 'public'
      and v.status in ('Disponibile', 'In arrivo', 'Prenotato')
  )
);

drop policy if exists "Editors manage vehicle images" on public.vehicle_images;
create policy "Editors manage vehicle images"
on public.vehicle_images for all
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Anyone insert leads" on public.leads;
create policy "Anyone insert leads"
on public.leads for insert
to anon, authenticated
with check (true);

drop policy if exists "Admins read leads" on public.leads;
create policy "Admins read leads"
on public.leads for select
to authenticated
using (public.has_admin_role(array['owner','staff','editor','viewer']::public.admin_role[]));

drop policy if exists "Staff update leads" on public.leads;
create policy "Staff update leads"
on public.leads for update
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Anyone insert appointments" on public.appointments;
create policy "Anyone insert appointments"
on public.appointments for insert
to anon, authenticated
with check (true);

drop policy if exists "Admins read appointments" on public.appointments;
create policy "Admins read appointments"
on public.appointments for select
to authenticated
using (public.has_admin_role(array['owner','staff','editor','viewer']::public.admin_role[]));

drop policy if exists "Staff update appointments" on public.appointments;
create policy "Staff update appointments"
on public.appointments for update
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Admins read customers" on public.customers;
create policy "Admins read customers"
on public.customers for select
to authenticated
using (public.has_admin_role(array['owner','staff','editor','viewer']::public.admin_role[]));

drop policy if exists "Staff manage customers" on public.customers;
create policy "Staff manage customers"
on public.customers for all
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Admins read follow ups" on public.follow_ups;
create policy "Admins read follow ups"
on public.follow_ups for select
to authenticated
using (public.has_admin_role(array['owner','staff','editor','viewer']::public.admin_role[]));

drop policy if exists "Staff manage follow ups" on public.follow_ups;
create policy "Staff manage follow ups"
on public.follow_ups for all
to authenticated
using (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));

drop policy if exists "Anyone insert consent" on public.cookie_consents;
create policy "Anyone insert consent"
on public.cookie_consents for insert
to anon, authenticated
with check (true);

drop policy if exists "Owners read consent" on public.cookie_consents;
create policy "Owners read consent"
on public.cookie_consents for select
to authenticated
using (public.has_admin_role(array['owner']::public.admin_role[]));

drop policy if exists "Users manage own saved vehicles" on public.user_vehicle_lists;
create policy "Users manage own saved vehicles"
on public.user_vehicle_lists for all
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists "Anyone insert analytics events" on public.analytics_events;
create policy "Anyone insert analytics events"
on public.analytics_events for insert
to anon, authenticated
with check (true);

drop policy if exists "Admins read analytics events" on public.analytics_events;
create policy "Admins read analytics events"
on public.analytics_events for select
to authenticated
using (public.has_admin_role(array['owner','staff']::public.admin_role[]));

create index if not exists vehicles_visibility_status_idx on public.vehicles (visibility, status, created_at desc);
create index if not exists vehicles_brand_model_idx on public.vehicles (brand, model);
create index if not exists leads_created_at_idx on public.leads (created_at desc);
create index if not exists appointments_date_idx on public.appointments (date, slot);
create index if not exists customers_status_idx on public.customers (status, created_at desc);
create unique index if not exists customers_phone_unique_idx on public.customers (phone) where phone <> '';
create index if not exists follow_ups_due_at_idx on public.follow_ups (due_at, status);
create index if not exists vehicle_images_vehicle_position_idx on public.vehicle_images (vehicle_id, position);
create index if not exists analytics_events_created_at_idx on public.analytics_events (created_at desc);
create index if not exists analytics_events_name_idx on public.analytics_events (name);

-- Optional: create a private storage bucket for vehicle originals.
-- The app currently supports Cloudinary/S3 uploads. Use this bucket if you later add Supabase Storage uploads.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('vehicle-images', 'vehicle-images', false, 10485760, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do nothing;

drop policy if exists "Admins manage vehicle image objects" on storage.objects;
create policy "Admins manage vehicle image objects"
on storage.objects for all
to authenticated
using (bucket_id = 'vehicle-images' and public.has_admin_role(array['owner','staff','editor']::public.admin_role[]))
with check (bucket_id = 'vehicle-images' and public.has_admin_role(array['owner','staff','editor']::public.admin_role[]));
