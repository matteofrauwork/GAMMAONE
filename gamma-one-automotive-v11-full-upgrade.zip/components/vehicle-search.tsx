"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { bodies, brands, fuels, gearboxes, vehicles as seedVehicles, formatCurrency, formatNumber } from "@/lib/data";
import type { Vehicle } from "@/lib/types";
import { VehicleCard } from "@/components/ui";
import { CatalogTrustBar } from "@/components/conversion-kit";

type Filters = {
  query: string;
  brand: string;
  model: string;
  service: string;
  body: string;
  fuel: string;
  gearbox: string;
  status: string;
  minPrice: number;
  maxPrice: number;
  minKm: number;
  maxKm: number;
  minYear: number;
  maxYear: number;
  finance: boolean;
  iva: boolean;
  neopatentati: boolean;
  warranty: boolean;
  order: string;
};

type SearchParamMap = Record<string, string | string[] | undefined>;

const currentYear = new Date().getFullYear();

const initialFilters: Filters = {
  query: "",
  brand: "Qualsiasi",
  model: "Qualsiasi",
  service: "Qualsiasi",
  body: "Qualsiasi",
  fuel: "Qualsiasi",
  gearbox: "Qualsiasi",
  status: "Qualsiasi",
  minPrice: 0,
  maxPrice: 150000,
  minKm: 0,
  maxKm: 300000,
  minYear: 2000,
  maxYear: currentYear,
  finance: false,
  iva: false,
  neopatentati: false,
  warranty: false,
  order: "Recenti"
};

const serviceOptions = ["Qualsiasi", "Vendita", "Noleggio", "Vendita/Noleggio"];
const statusOptions = ["Qualsiasi", "Disponibile", "In arrivo", "Prenotato", "Venduto", "Noleggiato"];
const orderOptions = ["Recenti", "Prezzo crescente", "Prezzo decrescente", "Km più bassi", "Anno più recente"];
const priceSteps = [0, 10000, 15000, 30000, 60000, 90000, 120000, 150000];
const kmSteps = [0, 30000, 80000, 150000, 200000, 300000];
const yearSteps = [2000, 2010, 2015, 2018, 2020, 2022, 2024, currentYear];

function readParam(params: SearchParamMap, ...names: string[]) {
  for (const name of names) {
    const value = params[name];
    if (Array.isArray(value)) {
      if (value[0]) return value[0];
    } else if (value) {
      return value;
    }
  }

  return "";
}

function numberParam(value: string, fallback: number) {
  if (!value) return fallback;
  const normalized = Number(value.replace(/[^\d]/g, ""));
  return Number.isFinite(normalized) && normalized >= 0 ? normalized : fallback;
}

function nonZeroParam(value: string, fallback: number) {
  const parsed = numberParam(value, fallback);
  return parsed > 0 ? parsed : fallback;
}

function priceParam(value: string, fallback: number) {
  if (!value) return fallback;
  if (value.includes("+")) return initialFilters.maxPrice;

  const matches = value.match(/\d[\d.]*/g);
  const lastMatch = matches?.[matches.length - 1] || "";
  return numberParam(lastMatch, fallback);
}

function optionParam(value: string, options: string[], fallback: string) {
  return options.includes(value) ? value : fallback;
}

function boolParam(value: string) {
  return value === "1" || value === "true" || value === "si" || value === "sì";
}

function getInitialFilters(params: SearchParamMap): Filters {
  const service = readParam(params, "service", "servizio");

  return {
    ...initialFilters,
    query: readParam(params, "query", "q"),
    brand: optionParam(readParam(params, "brand", "marca"), brands, initialFilters.brand),
    model: readParam(params, "model", "modello") || initialFilters.model,
    service: optionParam(service === "Ricerca su richiesta" ? "" : service, serviceOptions, initialFilters.service),
    minPrice: numberParam(readParam(params, "minPrice"), initialFilters.minPrice),
    maxPrice: nonZeroParam(String(priceParam(readParam(params, "maxPrice", "budget"), initialFilters.maxPrice)), initialFilters.maxPrice),
    minKm: numberParam(readParam(params, "minKm"), initialFilters.minKm),
    maxKm: nonZeroParam(readParam(params, "maxKm"), initialFilters.maxKm),
    minYear: nonZeroParam(readParam(params, "minYear"), initialFilters.minYear),
    maxYear: nonZeroParam(readParam(params, "maxYear"), initialFilters.maxYear),
    status: optionParam(readParam(params, "status"), statusOptions, initialFilters.status),
    finance: boolParam(readParam(params, "finance")),
    iva: boolParam(readParam(params, "iva")),
    neopatentati: boolParam(readParam(params, "neopatentati")),
    warranty: boolParam(readParam(params, "warranty")),
    order: optionParam(readParam(params, "order"), orderOptions, initialFilters.order)
  };
}

function serviceMatches(vehicleService: string, selectedService: string) {
  if (selectedService === "Qualsiasi") return true;
  if (selectedService === "Vendita") return vehicleService === "Vendita" || vehicleService === "Vendita/Noleggio";
  if (selectedService === "Noleggio") return vehicleService === "Noleggio" || vehicleService === "Vendita/Noleggio";
  return vehicleService === selectedService;
}

function matches(vehicle: Vehicle, filters: Filters) {
  const haystack = `${vehicle.title} ${vehicle.brand} ${vehicle.model} ${vehicle.version} ${vehicle.body} ${vehicle.fuel} ${vehicle.gearbox} ${vehicle.equipment.join(" ")}`.toLowerCase();

  if (filters.query && !haystack.includes(filters.query.toLowerCase())) return false;
  if (filters.brand !== "Qualsiasi" && vehicle.brand !== filters.brand) return false;
  if (filters.model !== "Qualsiasi" && vehicle.model !== filters.model) return false;
  if (!serviceMatches(vehicle.service, filters.service)) return false;
  if (filters.body !== "Qualsiasi" && vehicle.body !== filters.body) return false;
  if (filters.fuel !== "Qualsiasi" && vehicle.fuel !== filters.fuel) return false;
  if (filters.gearbox !== "Qualsiasi" && vehicle.gearbox !== filters.gearbox) return false;
  if (filters.status !== "Qualsiasi" && vehicle.status !== filters.status) return false;
  if (vehicle.price < filters.minPrice || vehicle.price > filters.maxPrice) return false;
  if (vehicle.km < filters.minKm || vehicle.km > filters.maxKm) return false;
  if (vehicle.year < filters.minYear || vehicle.year > filters.maxYear) return false;
  if (filters.finance && !vehicle.finance) return false;
  if (filters.iva && !vehicle.iva) return false;
  if (filters.neopatentati && !vehicle.neopatentati) return false;
  if (filters.warranty && !vehicle.warrantyMonths) return false;

  return true;
}

function sortResults(results: Vehicle[], order: string) {
  return [...results].sort((a, b) => {
    if (order === "Prezzo crescente") return a.price - b.price;
    if (order === "Prezzo decrescente") return b.price - a.price;
    if (order === "Km più bassi") return a.km - b.km;
    if (order === "Anno più recente") return b.year - a.year;
    return b.year - a.year;
  });
}

function serialize(filters: Filters) {
  const params = new URLSearchParams();

  (Object.keys(filters) as Array<keyof Filters>).forEach((key) => {
    const value = filters[key];
    const initial = initialFilters[key];

    if (value === initial || value === "Qualsiasi" || value === "" || value === false) return;
    params.set(key, String(value));
  });

  return params.toString();
}

function SelectField({ label, value, onChange, options }: { label: string; value: string | number; onChange: (value: string) => void; options: Array<string | number> }) {
  return (
    <label>
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </label>
  );
}

export function VehicleSearch({ initialParams = {}, items = seedVehicles }: { initialParams?: SearchParamMap; items?: Vehicle[] }) {
  const [filters, setFilters] = useState<Filters>(() => getInitialFilters(initialParams));
  const [drawerOpen, setDrawerOpen] = useState(false);

  const brandOptions = useMemo(() => {
    const merged = new Set([...brands.filter((brand) => brand !== "Qualsiasi"), ...items.map((vehicle) => vehicle.brand)]);
    return ["Qualsiasi", ...Array.from(merged).sort()];
  }, [items]);

  const modelOptions = useMemo(() => {
    const source = filters.brand === "Qualsiasi" ? items : items.filter((vehicle) => vehicle.brand === filters.brand);
    return ["Qualsiasi", ...Array.from(new Set(source.map((vehicle) => vehicle.model))).sort()];
  }, [filters.brand, items]);

  const results = useMemo(() => sortResults(items.filter((vehicle) => matches(vehicle, filters)), filters.order), [filters, items]);

  useEffect(() => {
    const query = serialize(filters);
    const nextUrl = query ? `/veicoli?${query}` : "/veicoli";
    window.history.replaceState(null, "", nextUrl);
  }, [filters]);

  function update<K extends keyof Filters>(key: K, value: Filters[K]) {
    setFilters((current) => {
      if (key === "brand") {
        return { ...current, brand: String(value), model: "Qualsiasi" };
      }

      return { ...current, [key]: value };
    });
  }

  function resetFilter(key: keyof Filters) {
    setFilters((current) => {
      if (key === "brand") {
        return { ...current, brand: initialFilters.brand, model: initialFilters.model };
      }

      return { ...current, [key]: initialFilters[key] } as Filters;
    });
  }

  function applyPreset(preset: "ready" | "finance" | "rental" | "starter" | "premium") {
    setFilters((current) => {
      if (preset === "ready") return { ...current, status: "Disponibile" } as Filters;
      if (preset === "finance") return { ...current, finance: true, service: "Vendita" } as Filters;
      if (preset === "rental") return { ...current, service: "Noleggio" } as Filters;
      if (preset === "starter") return { ...current, neopatentati: true, maxPrice: 20000 } as Filters;
      return { ...current, minPrice: 30000, finance: true } as Filters;
    });
  }

  const totalValue = results.reduce((sum, vehicle) => sum + vehicle.price, 0);
  const financeCount = results.filter((vehicle) => vehicle.finance).length;
  const rentalCount = results.filter((vehicle) => vehicle.service !== "Vendita").length;
  const availableCount = results.filter((vehicle) => vehicle.status === "Disponibile").length;

  const activeFilters: Array<{ label: string; key: keyof Filters }> = [
    filters.query ? { label: `Testo: ${filters.query}`, key: "query" } : null,
    filters.brand !== "Qualsiasi" ? { label: filters.brand, key: "brand" } : null,
    filters.model !== "Qualsiasi" ? { label: filters.model, key: "model" } : null,
    filters.service !== "Qualsiasi" ? { label: filters.service, key: "service" } : null,
    filters.status !== "Qualsiasi" ? { label: filters.status, key: "status" } : null,
    filters.body !== "Qualsiasi" ? { label: filters.body, key: "body" } : null,
    filters.fuel !== "Qualsiasi" ? { label: filters.fuel, key: "fuel" } : null,
    filters.gearbox !== "Qualsiasi" ? { label: filters.gearbox, key: "gearbox" } : null,
    filters.minPrice !== initialFilters.minPrice ? { label: `da ${formatCurrency(filters.minPrice)}`, key: "minPrice" } : null,
    filters.maxPrice !== initialFilters.maxPrice ? { label: `fino a ${formatCurrency(filters.maxPrice)}`, key: "maxPrice" } : null,
    filters.minKm !== initialFilters.minKm ? { label: `da ${formatNumber(filters.minKm)} km`, key: "minKm" } : null,
    filters.maxKm !== initialFilters.maxKm ? { label: `max ${formatNumber(filters.maxKm)} km`, key: "maxKm" } : null,
    filters.minYear !== initialFilters.minYear ? { label: `dal ${filters.minYear}`, key: "minYear" } : null,
    filters.maxYear !== initialFilters.maxYear ? { label: `fino al ${filters.maxYear}`, key: "maxYear" } : null,
    filters.finance ? { label: "Finanziabile", key: "finance" } : null,
    filters.iva ? { label: "IVA esposta", key: "iva" } : null,
    filters.neopatentati ? { label: "Neopatentati", key: "neopatentati" } : null,
    filters.warranty ? { label: "Garanzia", key: "warranty" } : null
  ].filter(Boolean) as Array<{ label: string; key: keyof Filters }>;

  const filtersPanel = (
    <div className="search-card-clean">
      <div className="search-main-row">
        <label>
          <span>Cerca</span>
          <input value={filters.query} onChange={(event) => update("query", event.target.value)} placeholder="Modello, optional, categoria..." />
        </label>
        <SelectField label="Marca" value={filters.brand} onChange={(value) => update("brand", value)} options={brandOptions} />
        <SelectField label="Modello" value={filters.model} onChange={(value) => update("model", value)} options={modelOptions} />
        <SelectField label="Servizio" value={filters.service} onChange={(value) => update("service", value)} options={serviceOptions} />
      </div>

      <details className="advanced-filters" open>
        <summary>Filtri avanzati</summary>
        <div className="advanced-grid">
          <SelectField label="Prezzo da" value={filters.minPrice} onChange={(value) => update("minPrice", Number(value))} options={priceSteps} />
          <SelectField label="Prezzo a" value={filters.maxPrice} onChange={(value) => update("maxPrice", Number(value))} options={priceSteps.filter((value) => value > 0)} />
          <SelectField label="Km da" value={filters.minKm} onChange={(value) => update("minKm", Number(value))} options={kmSteps} />
          <SelectField label="Km a" value={filters.maxKm} onChange={(value) => update("maxKm", Number(value))} options={kmSteps.filter((value) => value > 0)} />
          <SelectField label="Anno da" value={filters.minYear} onChange={(value) => update("minYear", Number(value))} options={yearSteps} />
          <SelectField label="Anno a" value={filters.maxYear} onChange={(value) => update("maxYear", Number(value))} options={yearSteps} />
          <SelectField label="Stato" value={filters.status} onChange={(value) => update("status", value)} options={statusOptions} />
          <SelectField label="Carrozzeria" value={filters.body} onChange={(value) => update("body", value)} options={["Qualsiasi", ...bodies]} />
          <SelectField label="Alimentazione" value={filters.fuel} onChange={(value) => update("fuel", value)} options={["Qualsiasi", ...fuels]} />
          <SelectField label="Cambio" value={filters.gearbox} onChange={(value) => update("gearbox", value)} options={["Qualsiasi", ...gearboxes]} />
        </div>
        <div className="toggle-row">
          <label><input type="checkbox" checked={filters.finance} onChange={(event) => update("finance", event.target.checked)} /> Finanziabile</label>
          <label><input type="checkbox" checked={filters.iva} onChange={(event) => update("iva", event.target.checked)} /> IVA esposta</label>
          <label><input type="checkbox" checked={filters.neopatentati} onChange={(event) => update("neopatentati", event.target.checked)} /> Neopatentati</label>
          <label><input type="checkbox" checked={filters.warranty} onChange={(event) => update("warranty", event.target.checked)} /> Garanzia</label>
        </div>
      </details>

      <div className="active-filters">
        {activeFilters.length ? activeFilters.map((filter) => (
          <button type="button" key={`${filter.key}-${filter.label}`} onClick={() => resetFilter(filter.key)}>{filter.label}<span aria-hidden="true">×</span></button>
        )) : <span>Nessun filtro attivo</span>}
      </div>

      <button className="btn btn-primary filter-apply" type="button" onClick={() => setDrawerOpen(false)}>Mostra risultati</button>
    </div>
  );

  return (
    <section className="catalog-app">
      <div className="wrap">
        <div className="catalog-toolbar">
          <div>
            <span className="panel-kicker">Showroom operativo</span>
            <h1>Trova il veicolo giusto.</h1>
            <p>Filtri essenziali, risultati leggibili e schede pensate per decidere senza rumore.</p>
          </div>
          <div className="catalog-actions">
            <button className="btn btn-secondary filter-drawer-toggle" type="button" onClick={() => setDrawerOpen(true)}>Filtri</button>
            <Link className="btn btn-secondary" href="/preferiti">Preferiti</Link>
            <Link className="btn btn-secondary" href="/confronto">Confronto</Link>
            <label>
              <span>Ordina</span>
              <select value={filters.order} onChange={(event) => update("order", event.target.value)}>
                {orderOptions.map((option) => <option key={option}>{option}</option>)}
              </select>
            </label>
            <button className="btn btn-secondary" type="button" onClick={() => setFilters(initialFilters)}>Reset</button>
          </div>
        </div>

        <div className="catalog-presets" aria-label="Scorciatoie ricerca">
          <button type="button" onClick={() => applyPreset("ready")}>Disponibili subito</button>
          <button type="button" onClick={() => applyPreset("finance")}>Finanziabili</button>
          <button type="button" onClick={() => applyPreset("rental")}>Noleggio</button>
          <button type="button" onClick={() => applyPreset("starter")}>Neopatentati / budget</button>
          <button type="button" onClick={() => applyPreset("premium")}>Premium</button>
        </div>

        <div className="desktop-filters">{filtersPanel}</div>
        <div className={drawerOpen ? "filter-drawer is-open" : "filter-drawer"} aria-hidden={!drawerOpen}>
          <div className="filter-drawer-backdrop" onClick={() => setDrawerOpen(false)} />
          <div className="filter-drawer-panel">
            <div className="filter-drawer-head">
              <b>Filtri catalogo</b>
              <button type="button" onClick={() => setDrawerOpen(false)} aria-label="Chiudi filtri">×</button>
            </div>
            {filtersPanel}
          </div>
        </div>

        <CatalogTrustBar total={results.length} available={availableCount} finance={financeCount} rental={rentalCount} />

        <div className="catalog-kpis compact-kpis">
          <div><b>{formatCurrency(totalValue)}</b><span>valore stock filtrato</span></div>
        </div>

        <div className="results-header">
          <div>
            <b>{results.length}</b>
            <span>risultati disponibili</span>
          </div>
          <p>Foto illustrative. Prezzi e condizioni da confermare.</p>
        </div>

        {results.length ? (
          <div className="results-grid">
            {results.map((vehicle) => <VehicleCard key={vehicle.id} vehicle={vehicle} />)}
          </div>
        ) : (
          <div className="empty-state">
            <h3>Nessun veicolo corrisponde ai filtri.</h3>
            <p>Trasforma il limite in contatto: invia una ricerca su misura.</p>
            <a className="btn btn-primary" href="/ricerca-su-richiesta">Avvia ricerca su misura</a>
          </div>
        )}
      </div>
    </section>
  );
}
