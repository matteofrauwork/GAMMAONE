import Link from "next/link";
import type { Vehicle } from "@/lib/types";
import { formatCurrency, formatNumber } from "@/lib/data";
import { estimateFinance, nextBestActionForVehicle, vehicleFitScore } from "@/lib/commercial";
import { buildFinanceWhatsApp, buildVehicleWhatsApp, hasCompanyWhatsApp } from "@/lib/whatsapp";

export function VehicleConversionPanel({ vehicle }: { vehicle: Vehicle }) {
  const finance = estimateFinance(vehicle);
  const fit = vehicleFitScore(vehicle);
  const action = nextBestActionForVehicle(vehicle);

  return (
    <section className="conversion-panel-section">
      <div className="wrap conversion-grid">
        <article className="conversion-card hero-conversion-card">
          <span className="panel-kicker">Decisione rapida</span>
          <h2>{fit.label}: {fit.score}/100</h2>
          <p>Questa sezione serve a trasformare la scheda da semplice annuncio a percorso commerciale chiaro.</p>
          <div className="conversion-chips">
            {fit.reasons.length ? fit.reasons.map((reason) => <span key={reason}>{reason}</span>) : <span>Dati da completare</span>}
          </div>
          <div className="notice"><b>Mossa migliore:</b> {action}</div>
        </article>

        <article className="conversion-card">
          <span className="panel-kicker">Rata indicativa</span>
          <h3>{formatCurrency(vehicle.monthlyFrom || finance.monthly)}/mese</h3>
          <div className="summary">
            <div className="summary-row"><span>Prezzo</span><b>{formatCurrency(vehicle.price)}</b></div>
            <div className="summary-row"><span>Anticipo stimato</span><b>{formatCurrency(finance.downPayment)}</b></div>
            <div className="summary-row"><span>Importo stimato</span><b>{formatCurrency(finance.financedAmount)}</b></div>
            <div className="summary-row"><span>Durata esempio</span><b>{finance.months} mesi</b></div>
          </div>
          <p className="micro">Stima non vincolante. TAN/TAEG, istruttoria e condizioni vanno confermati dal partner finanziario.</p>
          <Link className="btn btn-primary" href={buildFinanceWhatsApp(vehicle)}>Chiedi simulazione reale</Link>
        </article>

        <article className="conversion-card">
          <span className="panel-kicker">Contatto veloce</span>
          <h3>Non perdere tempo con richieste generiche.</h3>
          <p>Il messaggio WhatsApp contiene gia veicolo, prezzo e richiesta di disponibilita.</p>
          <div className="row-actions stacked">
            <Link className="btn btn-primary" href={buildVehicleWhatsApp(vehicle)}>{hasCompanyWhatsApp() ? "Apri WhatsApp" : "Richiedi info"}</Link>
            <Link className="btn btn-secondary" href="/#calendario">Prenota visione</Link>
          </div>
        </article>
      </div>
    </section>
  );
}

export function CatalogTrustBar({ total, available, finance, rental }: { total: number; available: number; finance: number; rental: number }) {
  return (
    <div className="catalog-trust-bar">
      <div><b>{total}</b><span>veicoli filtrati</span></div>
      <div><b>{available}</b><span>disponibili</span></div>
      <div><b>{finance}</b><span>finanziabili</span></div>
      <div><b>{rental}</b><span>vendita/noleggio</span></div>
    </div>
  );
}

export function VehicleMicroFacts({ vehicle }: { vehicle: Vehicle }) {
  const finance = estimateFinance(vehicle);

  return (
    <div className="micro-fact-strip">
      <div><span>Prezzo</span><b>{formatCurrency(vehicle.price)}</b></div>
      <div><span>Km</span><b>{formatNumber(vehicle.km)}</b></div>
      <div><span>Anno</span><b>{vehicle.year}</b></div>
      <div><span>Stima rata</span><b>{formatCurrency(vehicle.monthlyFrom || finance.monthly)}</b></div>
    </div>
  );
}
