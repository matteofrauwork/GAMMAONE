"use client";

import Image from "next/image";
import { useState } from "react";

type VehicleGalleryProps = {
  title: string;
  images: string[];
};

export function VehicleGallery({ title, images }: VehicleGalleryProps) {
  const galleryImages = images.filter(Boolean);
  const [activeImage, setActiveImage] = useState(galleryImages[0] || "");
  const [fullscreen, setFullscreen] = useState(false);

  if (!activeImage) {
    return (
      <div className="vehicle-gallery vehicle-gallery-empty">
        <span>Immagine in preparazione</span>
      </div>
    );
  }

  return (
    <div className="vehicle-gallery">
      <button className="vehicle-gallery-main" type="button" onClick={() => setFullscreen(true)} aria-label="Apri galleria a schermo intero">
        <Image
          src={activeImage}
          alt={`${title} - immagine illustrativa`}
          fill
          priority
          sizes="(max-width: 960px) 100vw, 58vw"
        />
        <span className="image-disclaimer">Immagine illustrativa</span>
      </button>

      {galleryImages.length > 1 ? (
        <div className="gallery-thumbs" aria-label="Immagini veicolo">
          {galleryImages.map((image, index) => (
            <button
              className={image === activeImage ? "is-active" : ""}
              key={`${image}-${index}`}
              type="button"
              onClick={() => setActiveImage(image)}
              aria-label={`Mostra immagine ${index + 1}`}
            >
              <Image src={image} alt="" fill sizes="92px" />
            </button>
          ))}
        </div>
      ) : null}

      {fullscreen ? (
        <div className="gallery-fullscreen" role="dialog" aria-modal="true" aria-label={`Galleria ${title}`}>
          <button className="gallery-close" type="button" onClick={() => setFullscreen(false)} aria-label="Chiudi galleria">×</button>
          <div className="gallery-fullscreen-image">
            <Image src={activeImage} alt={`${title} - immagine illustrativa`} fill sizes="100vw" />
            <span className="image-disclaimer">Immagine illustrativa</span>
          </div>
          {galleryImages.length > 1 ? (
            <div className="gallery-fullscreen-thumbs">
              {galleryImages.map((image, index) => (
                <button
                  className={image === activeImage ? "is-active" : ""}
                  key={`${image}-full-${index}`}
                  type="button"
                  onClick={() => setActiveImage(image)}
                  aria-label={`Mostra immagine ${index + 1}`}
                >
                  <Image src={image} alt="" fill sizes="84px" />
                </button>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
