import Image from "next/image";
import type { SVGProps } from "react";

export function GammaOneMark({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg className={className} viewBox="0 0 96 48" fill="none" aria-hidden="true" {...props}>
      <defs>
        <linearGradient id="g1-gold" x1="10" y1="8" x2="86" y2="40" gradientUnits="userSpaceOnUse">
          <stop stopColor="#F6E5B6" />
          <stop offset="0.52" stopColor="#D6B56D" />
          <stop offset="1" stopColor="#9A7137" />
        </linearGradient>
      </defs>
      <path
        d="M70 10H32C19.85 10 10 19.85 10 32C10 37.52 14.48 42 20 42H48"
        stroke="url(#g1-gold)"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M47 31L69 18L86 42"
        stroke="url(#g1-gold)"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M29 31H55" stroke="url(#g1-gold)" strokeWidth="2.5" strokeLinecap="round" opacity=".62" />
    </svg>
  );
}

export function GammaOneLogo({ compact = false }: { compact?: boolean }) {
  return (
    <span className={compact ? "brand-lockup compact" : "brand-lockup"}>
      <Image
        className="brand-logo-image"
        src="/media/brand/gamma-one-logo.png"
        alt="Gamma One Automotive Excellence"
        width={420}
        height={240}
        priority
      />
    </span>
  );
}

export function ServiceIcon({ type }: { type: "vehicles" | "rental" | "trade" | "search" | "finance" | "booking" }) {
  const common = {
    className: "service-svg",
    viewBox: "0 0 96 96",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    "aria-hidden": true
  };

  if (type === "vehicles") {
    return (
      <svg {...common}>
        <path d="M20 46L29 30H67L76 46" />
        <path d="M24 46H72C76.4 46 80 49.6 80 54V68H70L67 62H29L26 68H16V54C16 49.6 19.6 46 24 46Z" />
        <path d="M30 54H38M58 54H66" />
        <path d="M28 26H68L78 36" opacity=".45" />
      </svg>
    );
  }

  if (type === "rental") {
    return (
      <svg {...common}>
        <rect x="18" y="22" width="42" height="44" rx="8" />
        <path d="M28 16V28M50 16V28M18 36H60M30 48H34M42 48H46M30 58H34M42 58H46" />
        <path d="M63 58L78 73M74 55L81 62L69 74L62 67L74 55Z" />
      </svg>
    );
  }

  if (type === "trade") {
    return (
      <svg {...common}>
        <path d="M29 38C35 25 54 22 65 32L72 39" />
        <path d="M72 39H58M72 39V25" />
        <path d="M67 58C61 71 42 74 31 64L24 57" />
        <path d="M24 57H38M24 57V71" />
        <path d="M32 50L39 38H57L64 50" />
        <path d="M30 50H66V60H30V50Z" />
      </svg>
    );
  }

  if (type === "search") {
    return (
      <svg {...common}>
        <circle cx="41" cy="41" r="22" />
        <path d="M57 57L76 76" />
        <path d="M29 43L35 34H48L54 43" />
        <path d="M28 43H55V51H28V43Z" />
        <path d="M70 31H78M66 43H80" opacity=".55" />
      </svg>
    );
  }

  if (type === "finance") {
    return (
      <svg {...common}>
        <path d="M48 14L74 25V42C74 61 61 74 48 82C35 74 22 61 22 42V25L48 14Z" />
        <rect x="34" y="37" width="28" height="18" rx="4" />
        <path d="M38 45H52M38 51H46" />
        <path d="M62 61C67 61 72 63 72 67C72 71 67 73 62 73C57 73 52 71 52 67C52 63 57 61 62 61Z" />
      </svg>
    );
  }

  return (
    <svg {...common}>
      <rect x="20" y="22" width="50" height="46" rx="9" />
      <path d="M31 16V28M59 16V28M20 36H70M34 49H38M46 49H50M58 49H62" />
      <circle cx="67" cy="66" r="14" />
      <path d="M67 58V67L73 71" />
    </svg>
  );
}
