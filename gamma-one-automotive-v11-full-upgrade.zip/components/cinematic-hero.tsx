"use client";

import Image from "next/image";
import type { PointerEvent } from "react";
import { useRef } from "react";

export function CinematicHero() {
  const heroRef = useRef<HTMLDivElement>(null);

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    const element = heroRef.current;
    if (!element) return;

    const rect = element.getBoundingClientRect();
    const x = Math.min(Math.max((event.clientX - rect.left) / rect.width, 0), 1);
    const y = Math.min(Math.max((event.clientY - rect.top) / rect.height, 0), 1);

    element.style.setProperty("--hero-x", `${x * 100}%`);
    element.style.setProperty("--hero-y", `${y * 100}%`);
    element.style.setProperty("--hero-shift-x", `${(x - .5) * 26}px`);
    element.style.setProperty("--hero-shift-y", `${(y - .5) * 16}px`);
    element.style.setProperty("--hero-platform-x", `${(.5 - x) * 10}px`);
    element.style.setProperty("--hero-platform-y", `${(.5 - y) * 6}px`);
    element.style.setProperty("--hero-rotate-x", `${(.5 - y) * 5}deg`);
    element.style.setProperty("--hero-rotate-y", `${(x - .5) * 9}deg`);
  }

  function handlePointerLeave() {
    const element = heroRef.current;
    if (!element) return;

    element.style.setProperty("--hero-x", "66%");
    element.style.setProperty("--hero-y", "42%");
    element.style.setProperty("--hero-shift-x", "0px");
    element.style.setProperty("--hero-shift-y", "0px");
    element.style.setProperty("--hero-platform-x", "0px");
    element.style.setProperty("--hero-platform-y", "0px");
    element.style.setProperty("--hero-rotate-x", "0deg");
    element.style.setProperty("--hero-rotate-y", "0deg");
  }

  return (
    <div
      ref={heroRef}
      className="configurator-hero"
      aria-hidden="true"
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
    >
      <div className="configurator-halo" />
      <div className="configurator-platform">
        <span />
        <span />
        <span />
      </div>
      <Image
        className="configurator-car"
        src="/media/vehicles/porsche-911-3d.svg"
        alt=""
        fill
        priority
        sizes="100vw"
      />
      <div className="configurator-light configurator-light-left" />
      <div className="configurator-light configurator-light-right" />
      <div className="configurator-vignette" />
      <div className="configurator-grain" />
    </div>
  );
}
