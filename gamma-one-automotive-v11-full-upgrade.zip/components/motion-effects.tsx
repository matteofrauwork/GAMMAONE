"use client";

import { useEffect, useRef } from "react";

const REVEAL_SELECTOR = [
  ".section-head",
  ".featured-vehicle",
  ".featured-side .vehicle-card",
  ".service-tile",
  ".method-steps article",
  ".premium-form",
  ".cta-inner",
  ".vehicle-card",
  ".search-card-clean",
  ".rental-card",
  ".panel",
  ".detail-card",
  ".trust-tile"
].join(",");

export function MotionEffects() {
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      return;
    }

    const root = document.documentElement;
    const progress = document.querySelector<HTMLElement>(".scroll-progress-bar");
    const adminRoot = document.querySelector(".admin-layout");

    const updateScroll = () => {
      const max = document.body.scrollHeight - window.innerHeight;
      const current = max > 0 ? window.scrollY / max : 0;
      root.style.setProperty("--scroll-y", String(window.scrollY));
      root.style.setProperty("--scroll-progress", String(current));
      if (progress) {
        progress.style.transform = `scaleX(${current})`;
      }
      rafRef.current = null;
    };

    const requestScroll = () => {
      if (rafRef.current === null) {
        rafRef.current = window.requestAnimationFrame(updateScroll);
      }
    };

    const revealItems = adminRoot ? [] : Array.from(document.querySelectorAll<HTMLElement>(REVEAL_SELECTOR));
    revealItems.forEach((item, index) => {
      item.classList.add("reveal-item");
      item.style.setProperty("--reveal-delay", `${Math.min(index % 6, 5) * 70}ms`);
    });

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("reveal-in");
            observer.unobserve(entry.target);
          }
        }
      },
      {
        threshold: 0.14,
        rootMargin: "0px 0px -8% 0px"
      }
    );

    revealItems.forEach((item) => observer.observe(item));

    const handlePointer = (event: PointerEvent) => {
      root.style.setProperty("--pointer-x", `${event.clientX}px`);
      root.style.setProperty("--pointer-y", `${event.clientY}px`);
    };

    updateScroll();
    window.addEventListener("scroll", requestScroll, { passive: true });
    window.addEventListener("resize", requestScroll);
    window.addEventListener("pointermove", handlePointer, { passive: true });

    return () => {
      window.removeEventListener("scroll", requestScroll);
      window.removeEventListener("resize", requestScroll);
      window.removeEventListener("pointermove", handlePointer);
      observer.disconnect();
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  return (
    <>
      <div className="scroll-progress" aria-hidden="true">
        <div className="scroll-progress-bar" />
      </div>
      <div className="ambient-spotlight" aria-hidden="true" />
    </>
  );
}
