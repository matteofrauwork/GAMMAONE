"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { company } from "@/lib/company";
import type { Appointment, Lead, Vehicle } from "@/lib/types";
import { formatCurrency, formatNumber } from "@/lib/data";
import { GammaOneLogo, ServiceIcon } from "@/components/brand";
import { buildVehicleWhatsApp, hasCompanyWhatsApp } from "@/lib/whatsapp";
import { vehicleCommercialBadges, vehicleCompleteness, leadPriority } from "@/lib/vehicle-scoring";

const favoritesKey = "gamma-one:favorites";
const compareKey = "gamma-one:compare";

function readStoredSlugs(key: string) {
  if (typeof window === "undefined") return [];

  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) as string[] : [];
  } catch {
    return [];
  }
}

function savedKindFromKey(key: string) {
  return key === compareKey ? "compare" : "favorite";
}

function useStoredVehicleFlag(key: string, slug: string, maxItems?: number) {
  const [active, setActive] = useState(false);

  useEffect(() => {
    setActive(readStoredSlugs(key).includes(slug));
  }, [key, slug]);

  function toggle() {
    const current = readStoredSlugs(key);
    const nextActive = !current.includes(slug);
    const next = current.includes(slug)
      ? current.filter((item) => item !== slug)
      : [slug, ...current].slice(0, maxItems || 99);

    try {
      window.localStorage.setItem(key, JSON.stringify(next));
      setActive(next.includes(slug));
    } catch {
      setActive(false);
    }

    fetch("/api/saved-vehicles", {
      method: nextActive ? "POST" : "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug, kind: savedKindFromKey(key) })
    }).catch(() => undefined);
  }

  return { active, toggle };
}

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="topbar">
      <div className="wrap nav">
        <Link className="brand" href="/" aria-label="Gamma One home">
          <GammaOneLogo />
        </Link>

        <nav className="navlinks" aria-label="Navigazione principale">
          <Link href="/veicoli">Veicoli</Link>
          <Link href="/in-arrivo">In arrivo</Link>
          <Link href="/noleggio">Noleggio</Link>
          <Link href="/permuta">Permuta</Link>
          <Link href="/ricerca-su-richiesta">Su misura</Link>
          <Link href="/contatti">Contatti</Link>
        </nav>

        <div className="actions">
          <Link className="btn btn-secondary" href="/#calendario">Prenota visione</Link>
          <Link className="btn btn-primary" href="/veicoli">Showroom</Link>
          <button
            className={menuOpen ? "menu-toggle is-open" : "menu-toggle"}
            type="button"
            aria-label={menuOpen ? "Chiudi menu" : "Apri menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span />
            <span />
          </button>
        </div>

        <nav className={menuOpen ? "mobile-nav is-open" : "mobile-nav"} aria-label="Navigazione mobile">
          <Link href="/veicoli" onClick={() => setMenuOpen(false)}>Veicoli</Link>
          <Link href="/in-arrivo" onClick={() => setMenuOpen(false)}>In arrivo</Link>
          <Link href="/consegnati" onClick={() => setMenuOpen(false)}>Consegnati</Link>
          <Link href="/noleggio" onClick={() => setMenuOpen(false)}>Noleggio</Link>
          <Link href="/permuta" onClick={() => setMenuOpen(false)}>Permuta</Link>
          <Link href="/ricerca-su-richiesta" onClick={() => setMenuOpen(false)}>Su misura</Link>
          <Link href="/preferiti" onClick={() => setMenuOpen(false)}>Preferiti</Link>
          <Link href="/confronto" onClick={() => setMenuOpen(false)}>Confronto</Link>
          <Link href="/contatti" onClick={() => setMenuOpen(false)}>Contatti</Link>
          <Link href="/#calendario" onClick={() => setMenuOpen(false)}>Prenota visione</Link>
        </nav>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-top">
          <GammaOneLogo />
          <p>Vendita, noleggio, permuta e ricerca veicolo su richiesta in Sardegna. Un’esperienza ordinata, diretta e costruita per arrivare alla scelta giusta.</p>
        </div>

        <div className="footer-grid">
          <div>
            <h4>Servizi</h4>
            <Link href="/veicoli">Veicoli</Link>
            <Link href="/in-arrivo">In arrivo</Link>
            <Link href="/consegnati">Consegnati</Link>
            <Link href="/preferiti">Preferiti</Link>
            <Link href="/confronto">Confronto</Link>
            <Link href="/noleggio">Noleggio</Link>
            <Link href="/permuta">Permuta</Link>
            <Link href="/ricerca-su-richiesta">Ricerca su misura</Link>
          </div>

          <div>
            <h4>Informazioni</h4>
            <Link href="/chi-siamo">Chi siamo</Link>
            <Link href="/garanzia">Garanzia</Link>
            <Link href="/finanziamento">Finanziamento</Link>
            <Link href="/recensioni">Recensioni</Link>
            <Link href="/contatti">Contatti</Link>
          </div>

          <div>
            <h4>Area riservata</h4>
            <Link href="/login">Accesso proprietario</Link>
            <Link href="/admin/veicoli">Gestione veicoli</Link>
            <Link href="/admin/lead">Richieste clienti</Link>
            <Link href="/admin/clienti">Clienti</Link>
            <Link href="/admin/follow-up">Follow-up</Link>
            <Link href="/admin/calendario">Calendario</Link>
          </div>

          <div>
            <h4>Legal</h4>
            <Link href="/privacy">Privacy</Link>
            <Link href="/cookie-policy">Cookie</Link>
            <Link href="/condizioni-vendita">Condizioni vendita</Link>
            <Link href="/condizioni-noleggio">Condizioni noleggio</Link>
          </div>
        </div>

        <div className="company-legal">
          <b>{company.legalName}</b>
          <span>{company.vatNumber}</span>
          <span>Sede legale: {company.registeredOffice}</span>
        </div>

        <p className="footnote">Foto illustrative, prezzi e condizioni vanno sempre confermati prima della trattativa.</p>
      </div>
    </footer>
  );
}

export function VehicleCard({ vehicle, quiet = false }: { vehicle: Vehicle; quiet?: boolean }) {
  const href = `/veicoli/${vehicle.slug}`;
  const favorite = useStoredVehicleFlag(favoritesKey, vehicle.slug);
  const compare = useStoredVehicleFlag(compareKey, vehicle.slug, 3);
  const price = vehicle.service === "Noleggio" && vehicle.rentDailyFrom
    ? `da ${formatCurrency(vehicle.rentDailyFrom)}/giorno`
    : formatCurrency(vehicle.price);
  const badges = vehicleCommercialBadges(vehicle);
  const quality = vehicleCompleteness(vehicle);

  return (
    <article className={quiet ? "vehicle-card is-quiet" : "vehicle-card"}>
      <Link className="vehicle-media" href={href} aria-label={`Dettagli ${vehicle.title}`}>
        <Image
          src={vehicle.heroImage}
          alt={`${vehicle.title} - immagine illustrativa`}
          fill
          sizes={quiet ? "(max-width: 900px) 100vw, 24vw" : "(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 33vw"}
        />
        <div className="vehicle-badge-row">
          <span>{vehicle.status}</span>
          <span>{quality.score}% scheda</span>
        </div>
        <span className="image-disclaimer">Immagine illustrativa</span>
      </Link>

      <div className="vehicle-body">
        <div className="vehicle-kicker">{vehicle.brand} · {vehicle.service}</div>
        <h3><Link href={href}>{vehicle.title}</Link></h3>
        <div className="vehicle-specs">
          <span>{vehicle.year}</span>
          <span>{formatNumber(vehicle.km)} km</span>
          <span>{vehicle.fuel}</span>
          <span>{vehicle.gearbox}</span>
        </div>
        <div className="card-badges">
          {badges.slice(0, 4).map((badge) => <span key={badge}>{badge}</span>)}
        </div>
        {!quiet ? (
          <div className="card-utility-actions">
            <button type="button" onClick={favorite.toggle}>{favorite.active ? "Salvato" : "Salva"}</button>
            <button type="button" onClick={compare.toggle}>{compare.active ? "Nel confronto" : "Confronta"}</button>
          </div>
        ) : null}
        <div className="vehicle-bottom">
          <p className="price">{price}</p>
          {!quiet ? (
            <div className="vehicle-actions">
              <Link className="btn btn-secondary btn-mini" href={href} data-track="vehicle_details_click">Scheda</Link>
              <a className="btn btn-primary btn-mini" href={buildVehicleWhatsApp(vehicle)} data-track="vehicle_contact_click">{hasCompanyWhatsApp() ? "Verifica ora" : "Richiedi info"}</a>
            </div>
          ) : null}
        </div>
      </div>
    </article>
  );
}

export function ServiceTile({ icon, title, text, href }: { icon: "vehicles" | "rental" | "trade" | "search" | "finance" | "booking"; title: string; text: string; href: string }) {
  return (
    <Link href={href} className="service-tile">
      <ServiceIcon type={icon} />
      <span>{title}</span>
      <p>{text}</p>
    </Link>
  );
}

export function AdminNav() {
  const items = [
    ["/admin", "Dashboard"],
    ["/admin/veicoli", "Veicoli"],
    ["/admin/lead", "Richieste"],
    ["/admin/clienti", "Clienti"],
    ["/admin/follow-up", "Follow-up"],
    ["/admin/calendario", "Calendario"],
    ["/admin/staff", "Staff"],
    ["/admin/report", "Report"],
    ["/admin/configurazione", "Configurazione"],
    ["/", "Sito pubblico"]
  ];

  return (
    <aside className="admin-sidebar">
      {items.map(([href, label]) => (
        <Link key={href} href={href}>{label}</Link>
      ))}
    </aside>
  );
}

export function KpiCard({ label, value, note }: { label: string; value: string | number; note?: string }) {
  return (
    <div className="dashboard-card kpi">
      <b>{value}</b>
      <span>{label}</span>
      {note ? <p>{note}</p> : null}
    </div>
  );
}

export function LeadTable({ leads }: { leads: Lead[] }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Cliente</th>
          <th>Tipo</th>
          <th>Messaggio</th>
          <th>Score</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {leads.map((lead) => (
          <tr key={lead.id}>
            <td>{lead.name}<br /><span className="micro">{lead.phone}</span></td>
            <td>{lead.type}</td>
            <td>{lead.message}</td>
            <td><b>{leadPriority(lead).label}</b><br /><span className="micro">{leadPriority(lead).nextAction}</span></td>
            <td>{lead.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function AppointmentTable({ appointments }: { appointments: Appointment[] }) {
  return (
    <table className="table">
      <thead>
        <tr>
          <th>Data</th>
          <th>Cliente</th>
          <th>Motivo</th>
          <th>Veicolo</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {appointments.map((appointment) => (
          <tr key={appointment.id}>
            <td>{appointment.date} · {appointment.slot}</td>
            <td>{appointment.name}<br /><span className="micro">{appointment.phone}</span></td>
            <td>{appointment.reason}</td>
            <td>{appointment.vehicle || "—"}</td>
            <td>{appointment.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
