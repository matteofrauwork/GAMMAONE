import { Footer, Header } from "@/components/ui";

type LocalSeoPageProps = {
  title: string;
  subtitle: string;
  primaryHref: string;
  primaryLabel: string;
  points: string[];
};

export function LocalSeoPage({ title, subtitle, primaryHref, primaryLabel, points }: LocalSeoPageProps) {
  return (
    <div className="page">
      <Header />
      <main>
        <section className="subhero">
          <div className="wrap">
            <h1>{title}</h1>
            <p className="lead">{subtitle}</p>
            <div className="hero-cta" style={{ marginTop: 26 }}>
              <a className="btn btn-primary" href={primaryHref}>{primaryLabel}</a>
              <a className="btn btn-secondary" href="/contatti">Contatti</a>
            </div>
          </div>
        </section>

        <section>
          <div className="wrap trust-grid">
            {points.map((point) => (
              <div className="trust-tile" key={point}><span className="check" aria-hidden="true">✓</span><b>{point}</b></div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
