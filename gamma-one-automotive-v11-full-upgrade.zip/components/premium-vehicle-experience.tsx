import Link from "next/link";
import type { Vehicle } from "@/lib/types";
import { formatCurrency, formatNumber } from "@/lib/data";
import { vehicleCommercialBadges, vehicleCompleteness } from "@/lib/vehicle-scoring";
import { buildFinanceWhatsApp, buildVehicleWhatsApp, hasCompanyWhatsApp } from "@/lib/whatsapp";

export function VehicleTrustStrip({ vehicle }: { vehicle: Vehicle }) {
  const badges = vehicleCommercialBadges(vehicle);
  return (
    <div className="trust-strip" aria-label="Punti chiave veicolo">
      {badges.map((badge) => <span key={badge}>{badge}</span>)}
    </div>
  );
}

export function VehicleDecisionPanel({ vehicle }: { vehicle: Vehicle }) {
  const financeEnabled = vehicle.finance && vehicle.service !== "Noleggio";
  const checks = [
    ["Prezzo", vehicle.service === "Noleggio" && vehicle.rentDailyFrom ? `da ${formatCurrency(vehicle.rentDailyFrom)}/giorno` : formatCurrency(vehicle.price)],
    ["Rata indicativa", vehicle.monthlyFrom && financeEnabled ? `da ${formatCurrency(vehicle.monthlyFrom)}/mese` : "Da calcolare"],
    ["Uso", vehicle.service],
    ["Disponibilità", vehicle.status],
    ["Garanzia", vehicle.warrantyMonths ? `${vehicle.warrantyMonths} mesi` : "Da confermare"],
    ["Posizione", vehicle.location]
  ];

  return (
    <aside className="decision-panel" aria-label="Azioni rapide">
      <div>
        <span className="panel-kicker">Decisione rapida</span>
        <h3>{vehicle.title}</h3>
        <p>Prima blocca disponibilità, poi verifica documenti, permuta e condizioni economiche. Niente trattativa alla cieca.</p>
      </div>
      <div className="decision-list">
        {checks.map(([label, value]) => (
          <div key={label}><span>{label}</span><b>{value}</b></div>
        ))}
      </div>
      <div className="decision-actions">
        <Link className="btn btn-primary" href={buildVehicleWhatsApp(vehicle)}>{hasCompanyWhatsApp() ? "Verifica su WhatsApp" : "Richiedi informazioni"}</Link>
        <Link className="btn btn-secondary" href="/#calendario">Prenota visione</Link>
        {financeEnabled ? <Link className="btn btn-secondary" href={buildFinanceWhatsApp(vehicle)}>Simula finanziamento</Link> : null}
      </div>
    </aside>
  );
}

export function VehicleTransparencyBlock({ vehicle }: { vehicle: Vehicle }) {
  const completeness = vehicleCompleteness(vehicle);
  return (
    <section className="transparency-section">
      <div className="wrap transparency-grid">
        <div className="panel transparency-score">
          <span className="panel-kicker">Qualità annuncio</span>
          <b>{completeness.score}%</b>
          <p>{completeness.level}. Più i dati sono completi, meno tempo si perde in chat e più la scheda converte.</p>
        </div>
        <div className="panel">
          <h3>Prima della conferma</h3>
          <div className="audit-list">
            <span>Foto reali e dettagli carrozzeria</span>
            <span>Storico manutenzione e documenti</span>
            <span>Garanzia, revisione e gomme</span>
            <span>Costi accessori, passaggio e consegna</span>
          </div>
        </div>
        <div className="panel">
          <h3>Dati mancanti da chiudere</h3>
          {completeness.missing.length ? (
            <div className="audit-list is-warning">
              {completeness.missing.slice(0, 6).map((item) => <span key={item}>{item}</span>)}
            </div>
          ) : <p className="notice">Scheda completa: pronta per campagna, SEO e contatto commerciale.</p>}
        </div>
      </div>
    </section>
  );
}

export function VehicleSpecNarrative({ vehicle }: { vehicle: Vehicle }) {
  return (
    <section className="spec-narrative">
      <div className="wrap split">
        <div className="panel">
          <span className="panel-kicker">Perché valutarla</span>
          <h3>Scelta sensata se cerchi {vehicle.body.toLowerCase()} {vehicle.fuel.toLowerCase()} con cambio {vehicle.gearbox.toLowerCase()}.</h3>
          <p>{vehicle.description}</p>
          <div className="chips narrative-chips">
            {vehicle.highlights.map((item) => <span key={item}>{item}</span>)}
          </div>
        </div>
        <div className="panel">
          <span className="panel-kicker">Numeri veri</span>
          <div className="metric-wall">
            <div><b>{vehicle.year}</b><span>Anno</span></div>
            <div><b>{formatNumber(vehicle.km)}</b><span>Km</span></div>
            <div><b>{vehicle.powerHp}</b><span>CV</span></div>
            <div><b>{vehicle.seats}/{vehicle.doors}</b><span>Posti/porte</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}
