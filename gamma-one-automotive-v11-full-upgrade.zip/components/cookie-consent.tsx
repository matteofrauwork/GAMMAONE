"use client";

import { useEffect, useState } from "react";

const CONSENT_KEY = "gamma_one_cookie_consent";
type ConsentType = "essential" | "all";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  async function saveConsent(type: ConsentType) {
    const categories = {
      essential: true,
      preferences: type === "all",
      analytics: type === "all",
      marketing: type === "all",
      maps: type === "all"
    };

    const payload = {
      type,
      categories,
      version: process.env.NEXT_PUBLIC_COOKIE_CONSENT_VERSION || "2026-05-v1",
      timestamp: new Date().toISOString()
    };

    localStorage.setItem(CONSENT_KEY, JSON.stringify(payload));
    setVisible(false);

    try {
      await fetch("/api/privacy/consent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
    } catch {
      // Consent saved locally even if server endpoint is unavailable.
    }
  }

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-panel">
      <div>
        <b>Gestione cookie</b>
        <p>Usiamo cookie tecnici per far funzionare il sito. Preferenze, analytics, marketing e mappe vanno attivati solo dopo consenso e configurazione reale.</p>
      </div>
      <div className="cookie-actions">
        <button className="btn btn-secondary btn-mini" onClick={() => saveConsent("essential")}>Solo essenziali</button>
        <button className="btn btn-primary btn-mini" onClick={() => saveConsent("all")}>Accetta tutto</button>
      </div>
    </div>
  );
}
