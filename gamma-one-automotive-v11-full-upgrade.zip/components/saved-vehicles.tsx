"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { VehicleCard } from "@/components/ui";
import { formatCurrency, formatNumber, vehicles as seedVehicles } from "@/lib/data";
import type { Vehicle } from "@/lib/types";

const favoritesKey = "gamma-one:favorites";
const compareKey = "gamma-one:compare";

function readSlugs(key: string) {
  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) as string[] : [];
  } catch {
    return [];
  }
}

function useStoredVehicles(key: string) {
  const [slugs, setSlugs] = useState<string[]>([]);
  const [catalog, setCatalog] = useState<Vehicle[]>(seedVehicles);

  useEffect(() => {
    setSlugs(readSlugs(key));

    fetch("/api/vehicles")
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (Array.isArray(payload?.vehicles)) {
          setCatalog(payload.vehicles);
        }
      })
      .catch(() => undefined);

    const kind = key === compareKey ? "compare" : "favorite";
    fetch(`/api/saved-vehicles?kind=${kind}`)
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (Array.isArray(payload?.slugs) && payload.slugs.length) {
          setSlugs(payload.slugs);
          window.localStorage.setItem(key, JSON.stringify(payload.slugs));
        }
      })
      .catch(() => undefined);
  }, [key]);

  const items = useMemo(() => (
    slugs
      .map((slug) => catalog.find((vehicle) => vehicle.slug === slug))
      .filter(Boolean) as Vehicle[]
  ), [catalog, slugs]);

  function clear() {
    window.localStorage.removeItem(key);
    setSlugs([]);
  }

  return { items, clear };
}

export function FavoriteVehicles() {
  const { items, clear } = useStoredVehicles(favoritesKey);

  return (
    <section className="catalog-app">
      <div className="wrap">
        <div className="catalog-toolbar">
          <div>
            <h1>Veicoli salvati.</h1>
            <p>Una selezione locale sul tuo dispositivo. Per bloccare davvero un veicolo serve sempre conferma dello staff.</p>
          </div>
          <div className="catalog-actions">
            <Link className="btn btn-secondary" href="/veicoli">Catalogo</Link>
            {items.length ? <button className="btn btn-secondary" type="button" onClick={clear}>Svuota</button> : null}
          </div>
        </div>

        {items.length ? (
          <div className="results-grid">
            {items.map((vehicle) => <VehicleCard key={vehicle.id} vehicle={vehicle} />)}
          </div>
        ) : (
          <div className="empty-state">
            <h3>Nessun veicolo salvato.</h3>
            <p>Usa il pulsante Salva nelle card del catalogo per creare una shortlist.</p>
            <Link className="btn btn-primary" href="/veicoli">Vai al catalogo</Link>
          </div>
        )}
      </div>
    </section>
  );
}

export function CompareVehicles() {
  const { items, clear } = useStoredVehicles(compareKey);
  const rows = [
    ["Prezzo", (vehicle: Vehicle) => formatCurrency(vehicle.price)],
    ["Anno", (vehicle: Vehicle) => String(vehicle.year)],
    ["Km", (vehicle: Vehicle) => `${formatNumber(vehicle.km)} km`],
    ["Alimentazione", (vehicle: Vehicle) => vehicle.fuel],
    ["Cambio", (vehicle: Vehicle) => vehicle.gearbox],
    ["Potenza", (vehicle: Vehicle) => `${vehicle.powerHp} CV`],
    ["Garanzia", (vehicle: Vehicle) => vehicle.warrantyMonths ? `${vehicle.warrantyMonths} mesi` : "Da confermare"],
    ["Servizio", (vehicle: Vehicle) => vehicle.service]
  ] as const;

  return (
    <section className="catalog-app">
      <div className="wrap">
        <div className="catalog-toolbar">
          <div>
            <h1>Confronta fino a tre veicoli.</h1>
            <p>Una vista rapida per scegliere cosa approfondire. Disponibilita, foto reali e condizioni restano da confermare.</p>
          </div>
          <div className="catalog-actions">
            <Link className="btn btn-secondary" href="/veicoli">Catalogo</Link>
            {items.length ? <button className="btn btn-secondary" type="button" onClick={clear}>Svuota</button> : null}
          </div>
        </div>

        {items.length ? (
          <div className="compare-panel">
            <table className="compare-table">
              <thead>
                <tr>
                  <th>Dato</th>
                  {items.map((vehicle) => <th key={vehicle.id}><Link href={`/veicoli/${vehicle.slug}`}>{vehicle.title}</Link></th>)}
                </tr>
              </thead>
              <tbody>
                {rows.map(([label, render]) => (
                  <tr key={label}>
                    <td>{label}</td>
                    {items.map((vehicle) => <td key={`${vehicle.id}-${label}`}>{render(vehicle)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">
            <h3>Nessun veicolo in confronto.</h3>
            <p>Usa il pulsante Confronta nelle card del catalogo. La lista resta salvata solo sul tuo dispositivo.</p>
            <Link className="btn btn-primary" href="/veicoli">Vai al catalogo</Link>
          </div>
        )}
      </div>
    </section>
  );
}
