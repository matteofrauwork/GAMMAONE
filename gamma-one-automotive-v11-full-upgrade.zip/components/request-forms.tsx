"use client";

import type { FormEvent } from "react";
import { useState } from "react";

type LeadKind = "contact" | "vehicle" | "trade" | "custom-search" | "finance" | "rental";

type LeadRequestFormProps = {
  kind: LeadKind;
  vehicleTitle?: string;
  vehicleSlug?: string;
};

type LeadState = {
  name: string;
  phone: string;
  email: string;
  vehicle: string;
  brand: string;
  model: string;
  year: string;
  km: string;
  budget: string;
  monthly: string;
  downPayment: string;
  duration: string;
  fuel: string;
  gearbox: string;
  condition: string;
  message: string;
  companyWebsite: string;
};

const initialLeadState: LeadState = {
  name: "",
  phone: "",
  email: "",
  vehicle: "",
  brand: "",
  model: "",
  year: "",
  km: "",
  budget: "",
  monthly: "",
  downPayment: "",
  duration: "",
  fuel: "",
  gearbox: "",
  condition: "",
  message: "",
  companyWebsite: ""
};

const kindLabel: Record<LeadKind, string> = {
  contact: "Richiesta contatto",
  vehicle: "Richiesta veicolo",
  trade: "Valutazione permuta",
  "custom-search": "Ricerca su richiesta",
  finance: "Finanziamento",
  rental: "Noleggio"
};

function lines(values: Array<[string, string | undefined]>) {
  return values
    .filter(([, value]) => value && value.trim())
    .map(([label, value]) => `${label}: ${value}`)
    .join("\n");
}

function buildLeadMessage(kind: LeadKind, state: LeadState, vehicleTitle?: string) {
  const base = lines([
    ["Veicolo", vehicleTitle || state.vehicle],
    ["Marca", state.brand],
    ["Modello", state.model],
    ["Anno", state.year],
    ["Km", state.km],
    ["Budget massimo", state.budget],
    ["Rata massima", state.monthly],
    ["Anticipo", state.downPayment],
    ["Durata", state.duration],
    ["Alimentazione", state.fuel],
    ["Cambio", state.gearbox],
    [kind === "rental" ? "Uso previsto" : "Stato veicolo", state.condition],
    ["Note", state.message]
  ]);

  if (base) return base;

  if (kind === "vehicle" && vehicleTitle) {
    return `Vorrei informazioni su ${vehicleTitle}.`;
  }

  return "Vorrei essere ricontattato per una richiesta Gamma One.";
}

export function LeadRequestForm({ kind, vehicleTitle, vehicleSlug }: LeadRequestFormProps) {
  const [state, setState] = useState<LeadState>(() => ({
    ...initialLeadState,
    vehicle: vehicleTitle || ""
  }));
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  function update(key: keyof LeadState, value: string) {
    setState((current) => ({ ...current, [key]: value }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setMessage("");

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: state.name,
          phone: state.phone,
          email: state.email,
          type: kindLabel[kind],
          vehicleSlug,
          message: buildLeadMessage(kind, state, vehicleTitle),
          companyWebsite: state.companyWebsite
        })
      });

      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error || "Richiesta non inviata.");
      }

      setStatus("success");
      setMessage("Richiesta inviata. Lo staff potra ricontattarti dopo la verifica.");
      setState({ ...initialLeadState, vehicle: vehicleTitle || "" });
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Errore durante l'invio.");
    }
  }

  return (
    <form className="panel request-form" onSubmit={submit}>
      <h3>{kindLabel[kind]}</h3>
      <div className="form-grid">
        <div className="field hp-field" aria-hidden="true">
          <label>Sito web</label>
          <input tabIndex={-1} autoComplete="off" value={state.companyWebsite} onChange={(event) => update("companyWebsite", event.target.value)} />
        </div>

        <div className="field"><label>Nome</label><input required autoComplete="name" value={state.name} onChange={(event) => update("name", event.target.value)} placeholder="Nome e cognome" /></div>
        <div className="field"><label>Telefono</label><input required type="tel" autoComplete="tel" value={state.phone} onChange={(event) => update("phone", event.target.value)} placeholder="+39..." /></div>
        <div className="field full"><label>Email</label><input type="email" autoComplete="email" value={state.email} onChange={(event) => update("email", event.target.value)} placeholder="email per conferma, opzionale" /></div>

        {kind === "vehicle" || kind === "finance" ? (
          <div className="field full"><label>Veicolo</label><input value={state.vehicle} onChange={(event) => update("vehicle", event.target.value)} placeholder="Veicolo di interesse" /></div>
        ) : null}

        {kind === "trade" || kind === "custom-search" ? (
          <>
            <div className="field"><label>Marca</label><input value={state.brand} onChange={(event) => update("brand", event.target.value)} placeholder="BMW, Audi, Toyota..." /></div>
            <div className="field"><label>Modello</label><input value={state.model} onChange={(event) => update("model", event.target.value)} placeholder="Serie 3, A3, Yaris..." /></div>
            <div className="field"><label>Anno</label><input value={state.year} onChange={(event) => update("year", event.target.value)} placeholder="2020" /></div>
            <div className="field"><label>Km</label><input value={state.km} onChange={(event) => update("km", event.target.value)} placeholder="80.000" /></div>
            <div className="field"><label>Alimentazione</label><input value={state.fuel} onChange={(event) => update("fuel", event.target.value)} placeholder="Diesel, benzina, ibrida..." /></div>
            <div className="field"><label>Cambio</label><input value={state.gearbox} onChange={(event) => update("gearbox", event.target.value)} placeholder="Automatico / manuale" /></div>
          </>
        ) : null}

        {kind === "custom-search" || kind === "finance" ? (
          <>
            <div className="field"><label>Budget massimo</label><input value={state.budget} onChange={(event) => update("budget", event.target.value)} placeholder="35.000 euro" /></div>
            <div className="field"><label>Rata massima</label><input value={state.monthly} onChange={(event) => update("monthly", event.target.value)} placeholder="350 euro/mese" /></div>
          </>
        ) : null}

        {kind === "rental" ? (
          <>
            <div className="field"><label>Categoria desiderata</label><input value={state.vehicle} onChange={(event) => update("vehicle", event.target.value)} placeholder="Citycar, SUV, moto..." /></div>
            <div className="field"><label>Periodo</label><input value={state.duration} onChange={(event) => update("duration", event.target.value)} placeholder="Weekend, 7 giorni, mese..." /></div>
            <div className="field full"><label>Uso previsto</label><textarea value={state.condition} onChange={(event) => update("condition", event.target.value)} placeholder="Date indicative, conducenti, km previsti, consegna o ritiro..." /></div>
          </>
        ) : null}

        {kind === "finance" ? (
          <>
            <div className="field"><label>Anticipo</label><input value={state.downPayment} onChange={(event) => update("downPayment", event.target.value)} placeholder="5.000 euro" /></div>
            <div className="field"><label>Durata</label><input value={state.duration} onChange={(event) => update("duration", event.target.value)} placeholder="60 / 72 / 84 mesi" /></div>
          </>
        ) : null}

        {kind === "trade" ? (
          <div className="field full"><label>Stato e prezzo desiderato</label><textarea value={state.condition} onChange={(event) => update("condition", event.target.value)} placeholder="Carrozzeria, meccanica, tagliandi, gomme, revisione, difetti, prezzo desiderato..." /></div>
        ) : null}

        <div className="field full"><label>Messaggio</label><textarea value={state.message} onChange={(event) => update("message", event.target.value)} placeholder="Aggiungi dettagli utili per preparare una risposta precisa." /></div>
        <div className="field full"><button className="btn btn-primary" type="submit" disabled={status === "loading"}>{status === "loading" ? "Invio..." : "Invia richiesta"}</button></div>
      </div>
      {message ? <p className={status === "error" ? "form-status is-error" : "form-status"} aria-live="polite">{message}</p> : null}
    </form>
  );
}

type AppointmentState = {
  reason: string;
  date: string;
  slot: string;
  name: string;
  phone: string;
  email: string;
  companyWebsite: string;
};

export function AppointmentRequestForm({ vehicleTitle }: { vehicleTitle?: string }) {
  const [state, setState] = useState<AppointmentState>({
    reason: vehicleTitle ? "Visione veicolo" : "Appuntamento",
    date: "",
    slot: "",
    name: "",
    phone: "",
    email: "",
    companyWebsite: ""
  });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  function update(key: keyof AppointmentState, value: string) {
    setState((current) => ({ ...current, [key]: value }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setMessage("");

    try {
      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...state,
          vehicle: vehicleTitle
        })
      });
      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error || "Appuntamento non inviato.");
      }

      setStatus("success");
      setMessage("Richiesta appuntamento inviata. Lo staff confermera disponibilita e orario.");
      setState({ reason: "Appuntamento", date: "", slot: "", name: "", phone: "", email: "", companyWebsite: "" });
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Errore durante l'invio.");
    }
  }

  return (
    <form className="premium-form request-form" onSubmit={submit}>
      <label className="hp-field" aria-hidden="true"><span>Sito web</span><input tabIndex={-1} autoComplete="off" value={state.companyWebsite} onChange={(event) => update("companyWebsite", event.target.value)} /></label>
      <label><span>Motivo</span><select value={state.reason} onChange={(event) => update("reason", event.target.value)}><option>Visione veicolo</option><option>Test drive</option><option>Noleggio</option><option>Valutazione permuta</option><option>Ricerca su richiesta</option></select></label>
      <label><span>Data</span><input required type="date" value={state.date} onChange={(event) => update("date", event.target.value)} /></label>
      <label><span>Orario preferito</span><select required value={state.slot} onChange={(event) => update("slot", event.target.value)}><option value="">Seleziona</option><option>09:00</option><option>10:00</option><option>11:00</option><option>12:00</option><option>15:00</option><option>16:00</option><option>17:00</option><option>18:00</option></select></label>
      <label><span>Nome</span><input required autoComplete="name" value={state.name} onChange={(event) => update("name", event.target.value)} placeholder="Nome e cognome" /></label>
      <label><span>Telefono</span><input required type="tel" autoComplete="tel" value={state.phone} onChange={(event) => update("phone", event.target.value)} placeholder="+39..." /></label>
      <label><span>Email</span><input type="email" autoComplete="email" value={state.email} onChange={(event) => update("email", event.target.value)} placeholder="opzionale" /></label>
      <button className="btn btn-primary" type="submit" disabled={status === "loading"}>{status === "loading" ? "Invio..." : "Invia richiesta appuntamento"}</button>
      {message ? <p className={status === "error" ? "form-status is-error" : "form-status"} aria-live="polite">{message}</p> : null}
    </form>
  );
}
