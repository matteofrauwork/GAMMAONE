"use client";

import { useEffect } from "react";

const CONSENT_KEY = "gamma_one_cookie_consent";

function hasAnalyticsConsent() {
  try {
    const stored = window.localStorage.getItem(CONSENT_KEY);
    if (!stored) return false;
    const parsed = JSON.parse(stored);
    return parsed.type === "all" || parsed.categories?.analytics === true;
  } catch {
    return false;
  }
}

function sendEvent(name: string, metadata: Record<string, unknown> = {}) {
  if (!hasAnalyticsConsent()) return;

  fetch("/api/analytics/events", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name,
      path: window.location.pathname,
      metadata
    })
  }).catch(() => undefined);
}

export function AnalyticsEvents() {
  useEffect(() => {
    sendEvent("page_view");

    function onClick(event: MouseEvent) {
      const target = event.target instanceof Element ? event.target.closest("[data-track]") : null;
      if (!target) return;

      sendEvent(String(target.getAttribute("data-track") || "click"), {
        label: target.textContent?.trim().slice(0, 120) || "",
        href: target.getAttribute("href") || ""
      });
    }

    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  return null;
}
