import Link from "next/link";
import type { ReactNode } from "react";
import { Footer, Header } from "@/components/ui";

type PageProps = {
  title: string;
  subtitle: string;
  primaryHref?: string;
  primaryLabel?: string;
  secondaryHref?: string;
  secondaryLabel?: string;
  children: ReactNode;
};

export function PublicLandingPage({
  title,
  subtitle,
  primaryHref = "/veicoli",
  primaryLabel = "Vedi veicoli",
  secondaryHref = "/#calendario",
  secondaryLabel = "Richiedi appuntamento",
  children
}: PageProps) {
  return (
    <div className="page">
      <Header />
      <main>
        <section className="subhero">
          <div className="wrap">
            <h1>{title}</h1>
            <p className="lead">{subtitle}</p>
            <div className="hero-cta">
              <Link className="btn btn-primary" href={primaryHref}>{primaryLabel}</Link>
              <Link className="btn btn-secondary" href={secondaryHref}>{secondaryLabel}</Link>
            </div>
          </div>
        </section>
        {children}
      </main>
      <Footer />
    </div>
  );
}

export function MethodSection() {
  return (
    <section>
      <div className="wrap">
        <div className="section-head">
          <h2>Metodo Gamma One.</h2>
          <p>Un percorso semplice: capire l’esigenza, proporre opzioni concrete, fissare una visione e decidere senza passaggi confusi.</p>
        </div>
        <div className="method-grid">
          <article className="panel"><span className="step-number">01</span><h3>Racconti cosa cerchi</h3><p>Budget, uso, modello, tempi, eventuale permuta, preferenze e contatto.</p></article>
          <article className="panel"><span className="step-number">02</span><h3>Ricevi una proposta chiara</h3><p>Disponibilità, condizioni, costi, garanzia, cauzione o alternative compatibili.</p></article>
          <article className="panel"><span className="step-number">03</span><h3>Vedi, provi, decidi</h3><p>Appuntamento, visione del mezzo, noleggio, acquisto o ricerca su richiesta.</p></article>
        </div>
      </div>
    </section>
  );
}

export function TrustSection() {
  return (
    <section>
      <div className="wrap">
        <div className="section-head">
          <h2>Prima della conferma, tutto chiaro.</h2>
          <p>Il cliente deve sapere cosa sta guardando: prezzo, disponibilità, garanzia, passaggio, cauzione, franchigia, documenti e tempi.</p>
        </div>
        <div className="trust-grid">
          {["Prezzo e disponibilità", "Garanzia e passaggio", "Permuta e finanziamento", "Cauzione e franchigia", "Documenti richiesti", "Appuntamento su richiesta"].map((item) => (
              <div className="trust-tile" key={item}><span className="check" aria-hidden="true">✓</span><b>{item}</b></div>
          ))}
        </div>
      </div>
    </section>
  );
}
