# Image sources — v8.1

Le immagini veicolo sono **illustrative** e servono solo per rendere il prototipo più coerente modello-per-modello.
Non sono foto dei veicoli reali in stock Gamma One.

Per una pubblicazione reale servono:
- foto originali dei veicoli realmente disponibili;
- verifica licenze e attribuzioni;
- eventuale sostituzione degli URL remoti con asset locali ottimizzati.

## Wikimedia Commons file pages

- Porsche 911 Carrera S — https://commons.wikimedia.org/wiki/File:2021_Porsche_911_Carrera_S_Silver.jpg
- Mercedes-AMG GT 43 4MATIC+ — https://commons.wikimedia.org/wiki/File:Mercedes-AMG_GT_43_4Matic%2B_Coupe_4-Tuerer,_Paris_Motor_Show_2018,_IMG_0553.jpg
- Range Rover Sport HSE — https://commons.wikimedia.org/wiki/File:Range_Rover_Sport_HSE_(2016)_(52722433368).jpg
- Audi A7 Sportback — https://commons.wikimedia.org/wiki/File:Audi_A7_Sportback.jpg
- BMW 320d M Sport — https://commons.wikimedia.org/wiki/File:BMW_320d_M_sport.jpg
- Toyota Yaris Hybrid — https://commons.wikimedia.org/wiki/File:Toyota_Yaris_Hybrid.jpg
- Fiat 500 Hybrid Dolcevita — https://commons.wikimedia.org/wiki/File:Fiat_500_Hybrid_Dolcevita_Edition_(2020)_(53986750753).jpg
- Ducati Panigale V4 R — https://commons.wikimedia.org/wiki/File:Ducati_Panigale_V4_R_(4).jpg
- Harley-Davidson Fat Boy — https://commons.wikimedia.org/wiki/File:Harley-davidson_%22Fat_Boy%22.jpg
- Yamaha YZF-R1 — https://commons.wikimedia.org/wiki/File:2009_Yamaha_YZF-R1.jpg
