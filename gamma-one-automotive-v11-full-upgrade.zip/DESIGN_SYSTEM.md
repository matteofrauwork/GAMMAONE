# Gamma One — Luxury Automotive Design System

## Direzione

Stile B: luxury automotive / Awwwards.

Non clone SIXT, non marketplace rumoroso.  
Sopra: showroom premium.  
Sotto: sistema operativo con ricerca, admin, lead e calendario.

## Token principali

```css
--bg: #050505;
--surface: #111214;
--card: #141519;
--text: #f5f5f7;
--muted: #a1a1a6;
--accent: #d6b56d;
--accent2: #f3dfad;
--radius: 28px;
--shadow: 0 36px 100px rgba(0,0,0,.38);
```

## Regole UI

- Hero con immagine cinematografica, non illustrazioni finte.
- Max 1 CTA primaria per blocco.
- Card grandi, foto dominanti, copy corto.
- Ricerca avanzata sì, ma ordinata.
- Admin funzionale: meno estetica, più controllo.
- Mobile sticky actions.

## Componenti

- `Header`
- `Footer`
- `VehicleCard`
- `AdminNav`
- `KpiCard`
- `LeadTable`
- `AppointmentTable`
- `CookieConsent`

## Pagine

- `/` pubblico luxury search OS
- `/veicoli/[slug]` scheda dinamica
- `/login` accesso dealer
- `/admin` dashboard
- `/admin/veicoli` CRUD catalogo
- `/admin/lead` pipeline lead
- `/admin/calendario` gestione appuntamenti
- `/privacy`
- `/cookie-policy`
- `/condizioni-vendita`
- `/condizioni-noleggio`

## Figma / FigJam

Diagramma architettura creato in FigJam per spiegare il sistema: frontend, ricerca, schede, lead, admin, database, calendario, email, WhatsApp e upload.
