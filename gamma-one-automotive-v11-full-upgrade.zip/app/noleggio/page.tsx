import type { Metadata } from "next";
import { MethodSection, PublicLandingPage, TrustSection } from "@/components/public-sections";
import { LeadRequestForm } from "@/components/request-forms";
import { buildRentalWhatsApp } from "@/lib/whatsapp";

export const metadata: Metadata = {
  title: "Noleggio auto e moto in Sardegna",
  description: "Noleggio auto e moto in Sardegna con disponibilita, cauzione, franchigia, documenti e condizioni da confermare prima della prenotazione.",
  alternates: { canonical: "/noleggio" }
};

export default function RentalPage() {
  return (
    <PublicLandingPage
      title="Noleggio auto e moto in Sardegna."
      subtitle="Giornaliero, weekend, settimanale o mensile. Prima della conferma: cauzione, franchigia, coperture, km, documenti e ritiro sono spiegati con chiarezza."
      primaryHref={buildRentalWhatsApp()}
      primaryLabel="Richiedi disponibilità"
      secondaryHref="/#calendario"
      secondaryLabel="Richiedi ritiro"
    >
      <section>
        <div className="wrap rental-grid">
          {[
            ["Giornaliero", "Per sostituzione veicolo, appuntamenti, lavoro o necessità rapide.", "da confermare"],
            ["Weekend", "Per spostamenti brevi, eventi o esigenze temporanee.", "preventivo"],
            ["Settimanale", "Per turismo, trasferte o mobilità provvisoria.", "su disponibilità"],
            ["Mensile", "Per professionisti, aziende o periodi più lunghi.", "su richiesta"],
            ["Moto / Scooter", "Soluzioni leggere per città, estate o tragitti rapidi.", "categoria dedicata"],
            ["Premium", "Veicoli immagine per eventi, business o occasioni speciali.", "su preventivo"]
          ].map(([title, text, price]) => (
            <article className="rental-card" key={title}>
              <h3>{title}</h3>
              <div className="from">{price}</div>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>
      <section>
        <div className="wrap">
          <div className="section-head compact">
            <h2>Prima del ritiro, nessuna sorpresa.</h2>
            <p>Il noleggio deve essere chiaro prima del contatto finale: così il cliente sa cosa preparare e lo staff riceve richieste più pulite.</p>
          </div>
          <div className="trust-grid">
            {["Cauzione", "Franchigia", "Km inclusi", "Documenti richiesti", "Ritiro e riconsegna", "Coperture assicurative"].map((item) => (
              <div className="trust-tile" key={item}><span className="check" aria-hidden="true">✓</span><b>{item}</b></div>
            ))}
          </div>
        </div>
      </section>
      <TrustSection />
      <section>
        <div className="wrap split">
          <LeadRequestForm kind="rental" />
          <div className="panel">
            <h3>Informazioni utili</h3>
            <p>Indica date, durata, categoria desiderata, numero conducenti e uso previsto. Lo staff potrà confermare disponibilità, cauzione, franchigia e documenti richiesti.</p>
          </div>
        </div>
      </section>
      <MethodSection />
    </PublicLandingPage>
  );
}
