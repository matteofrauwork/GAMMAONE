import type { Metadata } from "next";
import { signInAction } from "@/lib/supabase/actions";
import { Header } from "@/components/ui";

export const metadata: Metadata = {
  title: "Accesso area riservata",
  robots: {
    index: false,
    follow: false
  }
};

export default function LoginPage({ searchParams }: { searchParams?: { error?: string } }) {
  return (
    <div className="page">
      <Header />
      <main className="wrap" style={{ padding: "90px 0" }}>
        <div className="split">
          <section className="panel">
            <h1 style={{ fontSize: 72, marginTop: 18 }}>Accesso area riservata</h1>
            <p className="lead">Area per proprietario e staff, pensata per gestire catalogo, richieste e appuntamenti.</p>
            <div className="features">
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Account proprietario e staff.</span></div>
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Sessione protetta lato server.</span></div>
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Accesso separato dal sito pubblico.</span></div>
            </div>
          </section>

          <form className="panel" action={signInAction}>
            <h3>Entra</h3>
            {searchParams?.error ? <p className="notice">{searchParams.error}</p> : null}
            <div className="field">
              <label>Email</label>
            <input name="email" type="email" placeholder="email area riservata" required />
            </div>
            <div className="field" style={{ marginTop: 14 }}>
              <label>Password</label>
              <input name="password" type="password" placeholder="••••••••" required />
            </div>
            <button className="btn btn-primary" style={{ marginTop: 18 }} type="submit">Accedi</button>
            <p className="micro" style={{ marginTop: 14 }}>Gli utenti autorizzati vengono configurati dal pannello amministrativo.</p>
          </form>
        </div>
      </main>
    </div>
  );
}
