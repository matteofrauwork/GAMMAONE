import { Footer, Header } from "@/components/ui";
import { company } from "@/lib/company";

export default function CookiePolicyPage() {
  return (
    <div className="page">
      <Header />
      <main className="wrap" style={{ padding: "90px 0" }}>
        <section className="panel legal-page">
          <h1 style={{ fontSize: 68, marginTop: 18 }}>Cookie Policy</h1>
          <div className="legal-copy">
            <h2>Cookie Policy</h2>
            <p>Titolare del sito: {company.legalName}, {company.vatNumber}, sede legale {company.registeredOffice}.</p>
            <p>Il sito usa cookie tecnici essenziali per navigazione, sicurezza, preferenze e consenso. Analytics, marketing, mappe, pixel o widget terzi devono restare inattivi finche non sono configurati e accettati dall&apos;utente.</p>
            <h3>Categorie</h3>
            <p><b>Tecnici essenziali:</b> necessari per funzionamento, sicurezza, sessione e salvataggio preferenze.</p>
            <p><b>Preferenze:</b> eventuali impostazioni non essenziali dell&apos;interfaccia.</p>
            <p><b>Statistiche:</b> misurazioni aggregate, solo se viene configurato uno strumento analytics conforme.</p>
            <p><b>Marketing e mappe:</b> strumenti esterni o contenuti incorporati, solo dopo consenso preventivo.</p>
            <h3>Consenso</h3>
            <p>Il consenso viene salvato localmente e puo essere registrato dai sistemi interni con versione, timestamp, categorie scelte e informazioni tecniche minime. Il testo finale deve essere validato con consulente privacy prima del deploy.</p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
