import type { Metadata } from "next";
import { MethodSection, PublicLandingPage } from "@/components/public-sections";
import { LeadRequestForm } from "@/components/request-forms";
import { buildTradeInWhatsApp } from "@/lib/whatsapp";

export const metadata: Metadata = {
  title: "Permuta e valutazione usato",
  description: "Valutazione usato e permuta auto o moto in Sardegna con raccolta dati, foto, condizioni e appuntamento.",
  alternates: { canonical: "/permuta" }
};

export default function TradeInPage() {
  return (
    <PublicLandingPage
      title="Valuta il tuo usato."
      subtitle="Invia marca, modello, anno, km, stato generale e foto. La valutazione diventa parte della trattativa per acquisto, noleggio o ricerca su richiesta."
      primaryHref={buildTradeInWhatsApp()}
      primaryLabel="Richiedi valutazione"
      secondaryHref="/#calendario"
      secondaryLabel="Richiedi valutazione"
    >
      <section>
        <div className="wrap split">
          <LeadRequestForm kind="trade" />
          <div className="panel">
            <h3>Cosa serve per una valutazione seria</h3>
            <div className="features">
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Foto esterni, interni, km e documenti.</span></div>
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Stato meccanico e carrozzeria dichiarato.</span></div>
              <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Obiettivo: vendita diretta o permuta.</span></div>
            </div>
          </div>
        </div>
      </section>
      <MethodSection />
    </PublicLandingPage>
  );
}
