import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/lib/api/security";
import { cleanSupabaseRow, normalizeVehicle, vehicleToSupabaseRow } from "@/lib/vehicle-repository";
import type { Vehicle } from "@/lib/types";

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<Vehicle>;
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("vehicles").update(cleanSupabaseRow(vehicleToSupabaseRow(body))).eq("id", params.id).select("*").single();
    if (!error) return NextResponse.json({ vehicle: normalizeVehicle(data), source: "supabase" });
  }

  const db = await readDb();
  db.vehicles = db.vehicles.map((vehicle) => vehicle.id === params.id ? { ...vehicle, ...body } : vehicle);
  await writeDb(db);
  return NextResponse.json({ ok: true, source: "mock" });
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  const unauthorized = await requireAdmin(request, ["owner", "staff"]);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { error } = await supabase.from("vehicles").delete().eq("id", params.id);
    if (!error) return NextResponse.json({ ok: true, source: "supabase" });
  }

  const db = await readDb();
  db.vehicles = db.vehicles.filter((vehicle) => vehicle.id !== params.id);
  await writeDb(db);
  return NextResponse.json({ ok: true, source: "mock" });
}
