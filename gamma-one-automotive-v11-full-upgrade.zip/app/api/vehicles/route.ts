import { NextResponse } from "next/server";
import { boolValue, getAdminRole, numberValue, requireAdmin, text } from "@/lib/api/security";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { Vehicle } from "@/lib/types";
import { cleanSupabaseRow, normalizeVehicle, vehicleToSupabaseRow } from "@/lib/vehicle-repository";

export async function GET() {
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const role = await getAdminRole();
    let query = supabase.from("vehicles").select("*").order("created_at", { ascending: false });

    if (!role) {
      query = query.eq("visibility", "public").in("status", ["Disponibile", "In arrivo", "Prenotato"]);
    }

    const { data, error } = await query;
    if (!error && data) {
      return NextResponse.json({ vehicles: data.map(normalizeVehicle), source: "supabase" });
    }
  }

  const db = await readDb();
  return NextResponse.json({ vehicles: db.vehicles, source: "mock" });
}

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<Vehicle>;

  if (!body.title || !body.brand || !body.model) {
    return NextResponse.json({ error: "title, brand e model sono obbligatori" }, { status: 400 });
  }

  const slug = `${body.brand}-${body.model}-${body.year || new Date().getFullYear()}-${Date.now()}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

  const vehicle: Vehicle = {
    id: `v-${Date.now()}`,
    slug,
    title: text(body.title, 140),
    brand: text(body.brand, 80),
    model: text(body.model, 100),
    version: text(body.version, 120),
    year: numberValue(body.year, new Date().getFullYear()),
    registrationMonth: text(body.registrationMonth, 40) || "Da inserire",
    km: numberValue(body.km),
    price: numberValue(body.price),
    monthlyFrom: body.monthlyFrom,
    rentDailyFrom: body.rentDailyFrom,
    location: text(body.location, 120) || "Sardegna",
    distanceKm: numberValue(body.distanceKm),
    body: text(body.body, 80) || "Berlina",
    fuel: body.fuel || "Benzina",
    gearbox: body.gearbox || "Manuale",
    powerHp: numberValue(body.powerHp),
    displacement: text(body.displacement, 80) || undefined,
    doors: numberValue(body.doors, 5),
    seats: numberValue(body.seats, 5),
    color: text(body.color, 60) || "Da inserire",
    seller: body.seller || "Gamma One",
    service: body.service || "Vendita",
    status: body.status || "Disponibile",
    visibility: body.visibility || "draft",
    warrantyMonths: body.warrantyMonths,
    finance: boolValue(body.finance),
    iva: boolValue(body.iva),
    neopatentati: boolValue(body.neopatentati),
    equipment: body.equipment || [],
    images: body.images || [body.heroImage || "/media/vehicles/supercar-coupe.svg"],
    heroImage: body.heroImage || "/media/vehicles/supercar-coupe.svg",
    videoUrl: text(body.videoUrl, 400) || undefined,
    description: text(body.description, 1800) || "Descrizione da completare.",
    highlights: body.highlights || [],
    inspection: body.inspection || {
      serviceHistory: "Da verificare",
      tyres: "Da verificare",
      brakes: "Da verificare",
      revision: "Da verificare",
      owners: "Da verificare"
    }
  };

  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("vehicles")
      .insert(cleanSupabaseRow(vehicleToSupabaseRow(vehicle)))
      .select("*")
      .single();

    if (!error) {
      return NextResponse.json({ vehicle: normalizeVehicle(data), source: "supabase" }, { status: 201 });
    }
  }

  const db = await readDb();
  db.vehicles.unshift(vehicle);
  await writeDb(db);

  return NextResponse.json({ vehicle, source: "mock" }, { status: 201 });
}
