import { NextResponse } from "next/server";
import { escapeHtml, rateLimit, requireAdmin, text } from "@/lib/api/security";
import { sendLeadEmail } from "@/lib/integrations/services";

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff"]);
  if (unauthorized) return unauthorized;

  const limited = rateLimit(request, "integration-email", 10, 60_000);
  if (limited) return limited;

  const body = await request.json();
  const name = text(body.name, 120) || "N/D";
  const phone = text(body.phone, 80) || "N/D";
  const email = text(body.email, 160);
  const type = text(body.type, 120) || "Richiesta";
  const message = text(body.message, 2400);

  const html = `
    <h2>Nuova richiesta Gamma One</h2>
    <p><strong>Nome:</strong> ${escapeHtml(name)}</p>
    <p><strong>Telefono:</strong> ${escapeHtml(phone)}</p>
    <p><strong>Email:</strong> ${escapeHtml(email || "N/D")}</p>
    <p><strong>Tipo:</strong> ${escapeHtml(type)}</p>
    <p><strong>Messaggio:</strong></p>
    <p>${escapeHtml(message)}</p>
  `;

  const result = await sendLeadEmail({
    subject: `Nuova richiesta Gamma One - ${type}`,
    html,
    replyTo: email || undefined
  });

  return NextResponse.json({ result });
}
