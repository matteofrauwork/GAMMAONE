import { NextResponse } from "next/server";
import { rateLimit, requireAdmin, text } from "@/lib/api/security";
import { createGoogleCalendarEvent } from "@/lib/integrations/services";

function addMinutes(dateTime: string, minutes: number) {
  return new Date(new Date(dateTime).getTime() + minutes * 60_000).toISOString();
}

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff"]);
  if (unauthorized) return unauthorized;

  const limited = rateLimit(request, "integration-calendar", 10, 60_000);
  if (limited) return limited;

  const body = await request.json();
  const date = text(body.date, 20);
  const slot = text(body.slot, 12);
  const name = text(body.name, 120);

  if (!date || !slot || !name) {
    return NextResponse.json({ error: "date, slot e name sono obbligatori" }, { status: 400 });
  }

  const startDateTime = `${date}T${slot}:00+02:00`;
  const endDateTime = addMinutes(startDateTime, 45);

  const result = await createGoogleCalendarEvent({
    summary: `Gamma One - ${text(body.reason, 120) || "Appuntamento"} - ${name}`,
    description: [
      `Telefono: ${text(body.phone, 80) || "N/D"}`,
      `Veicolo: ${text(body.vehicle, 180) || "N/D"}`,
      `Note: ${text(body.message, 1200)}`
    ].join("\n"),
    startDateTime,
    endDateTime,
    attendeeEmail: text(body.email, 160) || undefined
  });

  return NextResponse.json({ result });
}
