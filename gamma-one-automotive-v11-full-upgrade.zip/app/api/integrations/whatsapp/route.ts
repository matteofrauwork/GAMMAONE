import { NextResponse } from "next/server";
import { rateLimit, requireAdmin, text } from "@/lib/api/security";
import { buildWhatsAppLink, sendWhatsAppTemplate } from "@/lib/integrations/services";

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff"]);
  if (unauthorized) return unauthorized;

  const limited = rateLimit(request, "integration-whatsapp", 20, 60_000);
  if (limited) return limited;

  const body = await request.json();
  const message = text(body.message, 1200) || "Ciao, vorrei informazioni.";

  if (body.mode === "api") {
    const to = text(body.to, 80);
    if (!to) {
      return NextResponse.json({ error: "to obbligatorio" }, { status: 400 });
    }

    const result = await sendWhatsAppTemplate({
      to,
      body: message
    });
    return NextResponse.json({ result });
  }

  const link = buildWhatsAppLink({
    phone: text(body.phone, 80),
    name: text(body.name, 120),
    vehicle: text(body.vehicle, 180),
    message
  });

  return NextResponse.json({ link });
}
