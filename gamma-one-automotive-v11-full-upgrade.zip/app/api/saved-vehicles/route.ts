import { NextResponse } from "next/server";
import { rateLimit, text } from "@/lib/api/security";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient, hasSupabaseEnv } from "@/lib/supabase/server";

type SavedKind = "favorite" | "compare";

async function getUserId() {
  if (!hasSupabaseEnv()) return "";
  const supabase = createSupabaseServerClient();
  const { data } = supabase ? await supabase.auth.getUser() : { data: { user: null } };
  return data.user?.id || "";
}

function kindValue(value: unknown): SavedKind {
  return text(value, 20) === "compare" ? "compare" : "favorite";
}

export async function GET(request: Request) {
  const userId = await getUserId();
  if (!userId) {
    return NextResponse.json({ items: [], authenticated: false });
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ error: "Supabase non configurato" }, { status: 503 });
  }

  const { searchParams } = new URL(request.url);
  const kind = kindValue(searchParams.get("kind"));
  const { data, error } = await supabase
    .from("user_vehicle_lists")
    .select("kind, vehicles(slug)")
    .eq("user_id", userId)
    .eq("kind", kind)
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  const slugs = (data || []).map((item: any) => item.vehicles?.slug).filter(Boolean);
  return NextResponse.json({ slugs, authenticated: true });
}

export async function POST(request: Request) {
  const limited = rateLimit(request, "saved-vehicles", 30, 60_000);
  if (limited) return limited;

  const userId = await getUserId();
  if (!userId) {
    return NextResponse.json({ error: "Login richiesto" }, { status: 401 });
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ error: "Supabase non configurato" }, { status: 503 });
  }

  const body = await request.json();
  const slug = text(body.slug, 180);
  const kind = kindValue(body.kind);

  const { data: vehicle } = await supabase.from("vehicles").select("id").eq("slug", slug).maybeSingle();
  if (!vehicle?.id) {
    return NextResponse.json({ error: "Veicolo non trovato" }, { status: 404 });
  }

  const { error } = await supabase.from("user_vehicle_lists").upsert({
    user_id: userId,
    vehicle_id: vehicle.id,
    kind
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request) {
  const userId = await getUserId();
  if (!userId) {
    return NextResponse.json({ error: "Login richiesto" }, { status: 401 });
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ error: "Supabase non configurato" }, { status: 503 });
  }

  const body = await request.json();
  const slug = text(body.slug, 180);
  const kind = kindValue(body.kind);

  const { data: vehicle } = await supabase.from("vehicles").select("id").eq("slug", slug).maybeSingle();
  if (!vehicle?.id) {
    return NextResponse.json({ ok: true });
  }

  await supabase
    .from("user_vehicle_lists")
    .delete()
    .eq("user_id", userId)
    .eq("vehicle_id", vehicle.id)
    .eq("kind", kind);

  return NextResponse.json({ ok: true });
}
