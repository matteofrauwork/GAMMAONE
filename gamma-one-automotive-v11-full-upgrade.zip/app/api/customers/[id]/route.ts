import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/api/security";
import { customerToSupabaseRow, normalizeCustomer } from "@/lib/crm-repository";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { Customer } from "@/lib/types";

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<Customer>;
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("customers")
      .update(customerToSupabaseRow(body))
      .eq("id", params.id)
      .select("*")
      .single();

    if (!error && data) {
      return NextResponse.json({ customer: normalizeCustomer(data), source: "supabase" });
    }
  }

  const db = await readDb();
  db.customers = (db.customers || []).map((customer) => customer.id === params.id ? { ...customer, ...body } : customer);
  await writeDb(db);
  return NextResponse.json({ ok: true, source: "mock" });
}
