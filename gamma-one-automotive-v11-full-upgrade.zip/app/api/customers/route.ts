import { NextResponse } from "next/server";
import { requireAdmin, text } from "@/lib/api/security";
import { normalizeCustomer, customerToSupabaseRow } from "@/lib/crm-repository";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { Customer } from "@/lib/types";

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();
  if (supabase) {
    const { data, error } = await supabase.from("customers").select("*").order("created_at", { ascending: false });
    if (!error && data) {
      return NextResponse.json({ customers: data.map(normalizeCustomer), source: "supabase" });
    }
  }

  const db = await readDb();
  return NextResponse.json({ customers: db.customers || [], source: "mock" });
}

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<Customer>;
  if (!body.name || !body.phone) {
    return NextResponse.json({ error: "nome e telefono sono obbligatori" }, { status: 400 });
  }

  const customer: Customer = {
    id: `customer-${Date.now()}`,
    createdAt: new Date().toISOString(),
    name: text(body.name, 120),
    phone: text(body.phone, 80),
    email: text(body.email, 160) || undefined,
    source: text(body.source, 120) || "Manuale",
    interest: text(body.interest, 180) || "Da qualificare",
    status: body.status || "Nuovo",
    assignedTo: text(body.assignedTo, 120) || undefined,
    notes: text(body.notes, 2000) || undefined
  };

  const supabase = createSupabaseAdminClient();
  if (supabase) {
    const { data, error } = await supabase
      .from("customers")
      .insert(customerToSupabaseRow(customer))
      .select("*")
      .single();

    if (!error && data) {
      return NextResponse.json({ customer: normalizeCustomer(data), source: "supabase" }, { status: 201 });
    }
  }

  const db = await readDb();
  db.customers = [customer, ...(db.customers || [])];
  await writeDb(db);
  return NextResponse.json({ customer, source: "mock" }, { status: 201 });
}
