import { NextResponse } from "next/server";
import { rateLimit, text } from "@/lib/api/security";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function POST(request: Request) {
  const limited = rateLimit(request, "analytics-events", 60, 60_000);
  if (limited) return limited;

  const body = await request.json();
  const event = {
    id: `event-${Date.now()}`,
    createdAt: new Date().toISOString(),
    name: text(body.name, 120),
    path: text(body.path, 300),
    vehicleSlug: text(body.vehicleSlug, 180),
    metadata: typeof body.metadata === "object" && body.metadata ? body.metadata : {}
  };

  if (!event.name) {
    return NextResponse.json({ error: "name obbligatorio" }, { status: 400 });
  }

  const supabase = createSupabaseAdminClient();
  if (supabase) {
    const { error } = await supabase.from("analytics_events").insert({
      name: event.name,
      path: event.path,
      vehicle_slug: event.vehicleSlug,
      metadata: event.metadata
    });

    if (!error) {
      return NextResponse.json({ ok: true, source: "supabase" }, { status: 201 });
    }
  }

  const db = await readDb();
  const nextDb = {
    ...db,
    analyticsEvents: [...(db.analyticsEvents || []), event]
  };
  await writeDb(nextDb);

  return NextResponse.json({ ok: true, source: "mock" }, { status: 201 });
}
