import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    privacyVersion: process.env.PRIVACY_POLICY_VERSION || "2026-05-v1",
    cookieVersion: process.env.COOKIE_CONSENT_VERSION || "2026-05-v1",
    saleTerms: "/condizioni-vendita",
    rentalTerms: "/condizioni-noleggio",
    privacy: "/privacy",
    cookie: "/cookie-policy"
  });
}
