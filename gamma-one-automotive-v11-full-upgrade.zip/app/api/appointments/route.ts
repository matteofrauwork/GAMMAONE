import { NextResponse } from "next/server";
import { createGoogleCalendarEvent, sendLeadEmail } from "@/lib/integrations/services";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { escapeHtml, isHoneypotFilled, rateLimit, requireAdmin } from "@/lib/api/security";
import type { Appointment } from "@/lib/types";
import { validateAppointmentInput } from "@/lib/validation";

function addMinutes(dateTime: string, minutes: number) {
  return new Date(new Date(dateTime).getTime() + minutes * 60_000).toISOString();
}

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("appointments").select("*").order("date", { ascending: true });
    if (!error && data) {
      return NextResponse.json({ appointments: data, source: "supabase" });
    }
  }

  const db = await readDb();
  return NextResponse.json({ appointments: db.appointments, source: "mock" });
}

export async function POST(request: Request) {
  const limited = rateLimit(request, "appointment", 6, 60_000);
  if (limited) return limited;

  let body: Record<string, unknown>;

  try {
    body = await request.json() as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Payload JSON non valido." }, { status: 400 });
  }

  if (isHoneypotFilled(body)) {
    return NextResponse.json({ ok: true }, { status: 202 });
  }

  const parsed = validateAppointmentInput(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  const appointment: Appointment = {
    id: `appt-${Date.now()}`,
    createdAt: new Date().toISOString(),
    ...parsed.value,
    status: "Richiesto"
  };

  const supabase = createSupabaseAdminClient();
  let saved: unknown = appointment;

  if (supabase) {
    const { data, error } = await supabase.from("appointments").insert({
      date: appointment.date,
      slot: appointment.slot,
      reason: appointment.reason,
      name: appointment.name,
      phone: appointment.phone,
      email: appointment.email,
      vehicle: appointment.vehicle,
      status: appointment.status
    }).select("*").single();

    if (!error) {
      saved = data;
    }
  } else {
    const db = await readDb();
    db.appointments.unshift(appointment);
    await writeDb(db);
  }

  const startDateTime = `${appointment.date}T${appointment.slot}:00+02:00`;
  await createGoogleCalendarEvent({
    summary: `Gamma One - ${appointment.reason} - ${appointment.name}`,
    description: `Telefono: ${appointment.phone}\nVeicolo: ${appointment.vehicle || "N/D"}`,
    startDateTime,
    endDateTime: addMinutes(startDateTime, 45),
    attendeeEmail: appointment.email
  });

  await sendLeadEmail({
    subject: `Nuovo appuntamento Gamma One - ${appointment.date} ${appointment.slot}`,
    html: `<h2>Nuovo appuntamento</h2><p><b>${escapeHtml(appointment.name)}</b> - ${escapeHtml(appointment.phone)}</p><p>${escapeHtml(appointment.reason)} - ${escapeHtml(appointment.vehicle || "")}</p>`,
    replyTo: appointment.email
  });

  return NextResponse.json({ appointment: saved, source: supabase ? "supabase" : "mock" }, { status: 201 });
}
