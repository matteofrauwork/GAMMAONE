import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/lib/api/security";

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json();
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("appointments").update(body).eq("id", params.id).select("*").single();
    if (!error) return NextResponse.json({ appointment: data, source: "supabase" });
  }

  const db = await readDb();
  db.appointments = db.appointments.map((appointment) => appointment.id === params.id ? { ...appointment, ...body } : appointment);
  await writeDb(db);
  return NextResponse.json({ ok: true, source: "mock" });
}
