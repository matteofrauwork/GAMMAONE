import { NextResponse } from "next/server";
import { sendLeadEmail } from "@/lib/integrations/services";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { escapeHtml, isHoneypotFilled, rateLimit, requireAdmin } from "@/lib/api/security";
import type { Lead } from "@/lib/types";
import { validateLeadInput } from "@/lib/validation";

function scoreLead(message: string, type: string) {
  let score = 35;
  const text = `${message} ${type}`.toLowerCase();
  if (text.includes("entro") || text.includes("subito") || text.includes("appena")) score += 20;
  if (text.includes("budget") || text.includes("€")) score += 15;
  if (text.includes("permuta")) score += 10;
  if (text.includes("finanziamento") || text.includes("rata")) score += 10;
  if (text.includes("noleggio")) score += 10;
  return Math.min(score, 100);
}

function followUpDueAt() {
  const dueAt = new Date();
  dueAt.setDate(dueAt.getDate() + 1);
  dueAt.setHours(10, 0, 0, 0);
  return dueAt.toISOString();
}

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("leads").select("*").order("created_at", { ascending: false });
    if (!error && data) {
      return NextResponse.json({ leads: data, source: "supabase" });
    }
  }

  const db = await readDb();
  return NextResponse.json({ leads: db.leads, source: "mock" });
}

export async function POST(request: Request) {
  const limited = rateLimit(request, "lead", 8, 60_000);
  if (limited) return limited;

  let body: Record<string, unknown>;

  try {
    body = await request.json() as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Payload JSON non valido." }, { status: 400 });
  }

  if (isHoneypotFilled(body)) {
    return NextResponse.json({ ok: true }, { status: 202 });
  }

  const parsed = validateLeadInput(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  const { name, phone, email, type, message, vehicleSlug } = parsed.value;

  const lead: Lead = {
    id: `lead-${Date.now()}`,
    createdAt: new Date().toISOString(),
    name,
    phone,
    email,
    type,
    message,
    vehicleSlug,
    status: "Nuovo",
    score: scoreLead(message, type)
  };

  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("leads").insert({
      name: lead.name,
      phone: lead.phone,
      email: lead.email,
      type: lead.type,
      message: lead.message,
      vehicle_slug: lead.vehicleSlug,
      status: lead.status,
      score: lead.score
    }).select("*").single();

    if (!error) {
      const { data: existingCustomer } = await supabase
        .from("customers")
        .select("id")
        .eq("phone", lead.phone)
        .maybeSingle();

      let customerId = existingCustomer?.id as string | undefined;
      if (!customerId) {
        const { data: newCustomer } = await supabase
          .from("customers")
          .insert({
            name: lead.name,
            phone: lead.phone,
            email: lead.email,
            source: "Sito",
            interest: lead.vehicleSlug || lead.type,
            status: "Nuovo",
            notes: lead.message
          })
          .select("id")
          .single();
        customerId = newCustomer?.id;
      }

      await supabase.from("follow_ups").insert({
        due_at: followUpDueAt(),
        customer_id: customerId,
        lead_id: data.id,
        title: `Ricontattare ${lead.name}`,
        channel: "Telefono",
        status: "Da fare",
        notes: `${lead.type}: ${lead.message}`
      });

      await sendLeadEmail({
        subject: `Nuova richiesta Gamma One - ${lead.type}`,
        html: `<h2>Nuova richiesta</h2><p><b>${escapeHtml(lead.name)}</b> - ${escapeHtml(lead.phone)}</p><p>${escapeHtml(lead.message)}</p>`,
        replyTo: lead.email
      });
      return NextResponse.json({ lead: data, source: "supabase" }, { status: 201 });
    }
  }

  const db = await readDb();
  db.leads.unshift(lead);
  const existingCustomer = (db.customers || []).find((customer) => customer.phone === lead.phone);
  const customerId = existingCustomer?.id || `customer-${Date.now()}`;
  db.customers = existingCustomer
    ? db.customers
    : [{
      id: customerId,
      createdAt: new Date().toISOString(),
      name: lead.name,
      phone: lead.phone,
      email: lead.email,
      source: "Sito",
      interest: lead.vehicleSlug || lead.type,
      status: "Nuovo",
      notes: lead.message
    }, ...(db.customers || [])];
  db.followUps = [{
    id: `follow-up-${Date.now()}`,
    createdAt: new Date().toISOString(),
    dueAt: followUpDueAt(),
    customerId,
    leadId: lead.id,
    title: `Ricontattare ${lead.name}`,
    channel: "Telefono",
    status: "Da fare",
    notes: `${lead.type}: ${lead.message}`
  }, ...(db.followUps || [])];
  await writeDb(db);

  await sendLeadEmail({
    subject: `Nuova richiesta Gamma One - ${lead.type}`,
    html: `<h2>Nuova richiesta</h2><p><b>${escapeHtml(lead.name)}</b> - ${escapeHtml(lead.phone)}</p><p>${escapeHtml(lead.message)}</p>`,
    replyTo: lead.email
  });

  return NextResponse.json({ lead, source: "mock" }, { status: 201 });
}
