import { NextResponse } from "next/server";
import { requireAdmin, text } from "@/lib/api/security";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { AdminRole } from "@/lib/types";

const allowedRoles: AdminRole[] = ["owner", "staff", "editor", "viewer"];

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner"]);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ profiles: [], source: "not-configured", message: "Configura Supabase per leggere ruoli reali." });
  }

  const { data, error } = await supabase
    .from("admin_profiles")
    .select("id, full_name, role, active, created_at, updated_at")
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: "Profili admin non leggibili." }, { status: 500 });
  }

  return NextResponse.json({ profiles: data || [], source: "supabase" });
}

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner"]);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ error: "Supabase non configurato: impossibile assegnare ruoli reali." }, { status: 503 });
  }

  const body = await request.json() as { email?: string; fullName?: string; role?: AdminRole };
  const email = text(body.email, 180).toLowerCase();
  const role = body.role && allowedRoles.includes(body.role) ? body.role : "viewer";

  if (!email) {
    return NextResponse.json({ error: "email obbligatoria" }, { status: 400 });
  }

  const { data: usersData, error: usersError } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
  if (usersError) {
    return NextResponse.json({ error: "Utenti Auth non leggibili." }, { status: 500 });
  }

  const user = usersData.users.find((item) => item.email?.toLowerCase() === email);
  if (!user) {
    return NextResponse.json({ error: "Utente non trovato. Crea prima l'utente in Supabase Auth." }, { status: 404 });
  }

  const { data, error } = await supabase
    .from("admin_profiles")
    .upsert({
      id: user.id,
      full_name: text(body.fullName, 160) || user.email,
      role,
      active: true
    })
    .select("*")
    .single();

  if (error) {
    return NextResponse.json({ error: "Ruolo non salvato." }, { status: 500 });
  }

  return NextResponse.json({ profile: data, source: "supabase" }, { status: 201 });
}

export async function PATCH(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner"]);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return NextResponse.json({ error: "Supabase non configurato." }, { status: 503 });
  }

  const body = await request.json() as { id?: string; fullName?: string; role?: AdminRole; active?: boolean };
  if (!body.id) {
    return NextResponse.json({ error: "id obbligatorio" }, { status: 400 });
  }

  const updates: Record<string, unknown> = {};
  if (body.fullName !== undefined) updates.full_name = text(body.fullName, 160);
  if (body.role && allowedRoles.includes(body.role)) updates.role = body.role;
  if (body.active !== undefined) updates.active = Boolean(body.active);

  const { data, error } = await supabase
    .from("admin_profiles")
    .update(updates)
    .eq("id", body.id)
    .select("*")
    .single();

  if (error) {
    return NextResponse.json({ error: "Profilo non aggiornato." }, { status: 500 });
  }

  return NextResponse.json({ profile: data, source: "supabase" });
}
