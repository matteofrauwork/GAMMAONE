import { NextResponse } from "next/server";
import { uploadImageToStorage } from "@/lib/integrations/services";
import { rateLimit, requireAdmin, validateImageFile } from "@/lib/api/security";

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const limited = rateLimit(request, "upload", 20, 60_000);
  if (limited) return limited;

  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "file mancante" }, { status: 400 });
  }

  const fileError = validateImageFile(file);
  if (fileError) {
    return NextResponse.json({ error: fileError }, { status: 400 });
  }

  try {
    const result = await uploadImageToStorage(file);

    if ((result as { skipped?: boolean }).skipped) {
      return NextResponse.json({
        message: "Upload non completato: archivio immagini non configurato.",
        result,
        file: {
          name: file.name,
          size: file.size,
          type: file.type
        }
      });
    }

    return NextResponse.json({ result }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Errore upload" }, { status: 500 });
  }
}
