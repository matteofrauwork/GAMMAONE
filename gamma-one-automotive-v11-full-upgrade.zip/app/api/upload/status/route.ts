import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/api/security";

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const cloudinary = Boolean(
    process.env.CLOUDINARY_URL ||
    (process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)
  );

  const s3 = Boolean(
    process.env.S3_BUCKET &&
    process.env.S3_REGION &&
    process.env.S3_ACCESS_KEY_ID &&
    process.env.S3_SECRET_ACCESS_KEY
  );

  return NextResponse.json({
    configured: cloudinary || s3,
    providers: {
      cloudinary,
      s3
    },
    maxFileMb: 8,
    allowed: ["image/jpeg", "image/png", "image/webp", "image/avif"]
  });
}
