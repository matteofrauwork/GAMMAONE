import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/api/security";
import { followUpToSupabaseRow, normalizeFollowUp } from "@/lib/crm-repository";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { FollowUp } from "@/lib/types";

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<FollowUp>;
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("follow_ups")
      .update(followUpToSupabaseRow(body))
      .eq("id", params.id)
      .select("*")
      .single();

    if (!error && data) {
      return NextResponse.json({ followUp: normalizeFollowUp(data), source: "supabase" });
    }
  }

  const db = await readDb();
  db.followUps = (db.followUps || []).map((followUp) => followUp.id === params.id ? { ...followUp, ...body } : followUp);
  await writeDb(db);
  return NextResponse.json({ ok: true, source: "mock" });
}
