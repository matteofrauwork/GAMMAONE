import { NextResponse } from "next/server";
import { requireAdmin, text } from "@/lib/api/security";
import { followUpToSupabaseRow, normalizeFollowUp } from "@/lib/crm-repository";
import { readDb, writeDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { FollowUp } from "@/lib/types";

export async function GET(request: Request) {
  const unauthorized = await requireAdmin(request);
  if (unauthorized) return unauthorized;

  const supabase = createSupabaseAdminClient();
  if (supabase) {
    const { data, error } = await supabase.from("follow_ups").select("*").order("due_at", { ascending: true });
    if (!error && data) {
      return NextResponse.json({ followUps: data.map(normalizeFollowUp), source: "supabase" });
    }
  }

  const db = await readDb();
  return NextResponse.json({ followUps: db.followUps || [], source: "mock" });
}

export async function POST(request: Request) {
  const unauthorized = await requireAdmin(request, ["owner", "staff", "editor"]);
  if (unauthorized) return unauthorized;

  const body = await request.json() as Partial<FollowUp>;
  if (!body.title || !body.dueAt) {
    return NextResponse.json({ error: "titolo e data sono obbligatori" }, { status: 400 });
  }

  const followUp: FollowUp = {
    id: `follow-up-${Date.now()}`,
    createdAt: new Date().toISOString(),
    dueAt: text(body.dueAt, 80),
    customerId: text(body.customerId, 120) || undefined,
    leadId: text(body.leadId, 120) || undefined,
    title: text(body.title, 180),
    channel: body.channel || "Telefono",
    status: body.status || "Da fare",
    notes: text(body.notes, 2000) || undefined
  };

  const supabase = createSupabaseAdminClient();
  if (supabase) {
    const { data, error } = await supabase
      .from("follow_ups")
      .insert(followUpToSupabaseRow(followUp))
      .select("*")
      .single();

    if (!error && data) {
      return NextResponse.json({ followUp: normalizeFollowUp(data), source: "supabase" }, { status: 201 });
    }
  }

  const db = await readDb();
  db.followUps = [followUp, ...(db.followUps || [])];
  await writeDb(db);
  return NextResponse.json({ followUp, source: "mock" }, { status: 201 });
}
