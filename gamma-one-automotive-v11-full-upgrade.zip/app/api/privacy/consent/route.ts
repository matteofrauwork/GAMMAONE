import { NextResponse } from "next/server";
import { getClientIp, rateLimit, text } from "@/lib/api/security";
import { readDb, writeDb } from "@/lib/store";

export async function POST(request: Request) {
  const limited = rateLimit(request, "privacy-consent", 30, 60_000);
  if (limited) return limited;

  const body = await request.json();
  const db = await readDb();

  const consent = {
    id: `consent-${Date.now()}`,
    createdAt: new Date().toISOString(),
    type: text(body.type, 40) || "essential",
    version: text(body.version, 80) || process.env.COOKIE_CONSENT_VERSION || "2026-05-v1",
    categories: typeof body.categories === "object" && body.categories ? body.categories : { essential: true },
    userAgent: text(request.headers.get("user-agent"), 300),
    ip: getClientIp(request)
  };

  const nextDb = {
    ...db,
    consents: [...(db.consents || []), consent]
  };

  await writeDb(nextDb);

  return NextResponse.json({ consent });
}
