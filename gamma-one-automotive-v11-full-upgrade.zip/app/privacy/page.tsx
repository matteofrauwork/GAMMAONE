import { Footer, Header } from "@/components/ui";
import { company } from "@/lib/company";

export default function PrivacyPage() {
  return (
    <div className="page">
      <Header />
      <main className="wrap" style={{ padding: "90px 0" }}>
        <section className="panel legal-page">
          <h1 style={{ fontSize: 68, marginTop: 18 }}>Privacy e trattamento dati</h1>
          <div className="legal-copy">
            <h2>Privacy Policy</h2>
            <p>Titolare del trattamento: {company.legalName}, {company.vatNumber}, sede legale {company.registeredOffice}. Questa pagina e una struttura pronta per revisione professionale: finalita, basi giuridiche, tempi di conservazione, fornitori e diritti vanno validati prima del deploy.</p>
            <h3>Dati raccolti</h3>
            <p>Nome, telefono, email, messaggio, veicolo richiesto, dati appuntamento, preferenze di ricerca, eventuali dati relativi alla permuta, informazioni tecniche minime di consenso e sicurezza.</p>
            <h3>Finalita</h3>
            <p>Gestione richieste commerciali, preventivi, appuntamenti, noleggio, vendita, valutazione permuta, ricerca su richiesta, assistenza e obblighi amministrativi.</p>
            <h3>Basi giuridiche</h3>
            <p>Esecuzione di misure precontrattuali richieste dall&apos;utente, obblighi di legge, legittimo interesse per sicurezza e gestione operativa, consenso quando richiesto per comunicazioni o strumenti non essenziali.</p>
            <h3>Conservazione</h3>
            <p>I tempi devono essere definiti con il consulente: richieste commerciali, appuntamenti, contratti, consensi e documentazione amministrativa possono avere durate diverse.</p>
            <h3>Fornitori e strumenti</h3>
            <p>I dati possono essere trattati tramite servizi esterni per archiviazione, gestione immagini, invio email, calendario appuntamenti e contatto diretto, solo se configurati e necessari al servizio richiesto.</p>
            <h3>Diritti</h3>
            <p>L&apos;interessato puo richiedere accesso, rettifica, cancellazione, limitazione, opposizione e portabilita ove applicabile, usando i contatti ufficiali indicati dall&apos;azienda.</p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
