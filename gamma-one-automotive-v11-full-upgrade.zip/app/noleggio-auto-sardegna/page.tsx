import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Noleggio auto Sardegna",
  description: "Noleggio auto in Sardegna con disponibilita, cauzione, franchigia, documenti e ritiro da confermare.",
  alternates: { canonical: "/noleggio-auto-sardegna" }
};

export default function CarRentalSardiniaPage() {
  return (
    <LocalSeoPage
      title="Noleggio auto in Sardegna."
      subtitle="Richieste pulite per giornaliero, weekend, settimanale o mensile. Condizioni sempre da confermare prima della prenotazione."
      primaryHref="/noleggio"
      primaryLabel="Richiedi disponibilita"
      points={["Giornaliero", "Weekend", "Mensile", "Cauzione chiara", "Franchigia da confermare", "Ritiro su appuntamento"]}
    />
  );
}
