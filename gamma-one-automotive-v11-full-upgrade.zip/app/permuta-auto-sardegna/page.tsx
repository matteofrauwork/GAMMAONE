import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Permuta auto Sardegna",
  description: "Permuta e valutazione usato in Sardegna con raccolta dati, foto, documenti e appuntamento.",
  alternates: { canonical: "/permuta-auto-sardegna" }
};

export default function TradeInSardiniaPage() {
  return (
    <LocalSeoPage
      title="Permuta il tuo usato in Sardegna."
      subtitle="Marca, modello, anno, km, foto e condizioni raccolti in modo ordinato per preparare una valutazione seria."
      primaryHref="/permuta"
      primaryLabel="Richiedi valutazione"
      points={["Valutazione usato", "Foto e documenti", "Stato carrozzeria", "Tagliandi", "Permuta", "Appuntamento"]}
    />
  );
}
