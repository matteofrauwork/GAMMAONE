"use client";

import { useEffect, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import type { AdminRole } from "@/lib/types";

type AdminProfile = {
  id: string;
  full_name?: string;
  role: AdminRole;
  active: boolean;
  created_at?: string;
};

export default function AdminStaffPage() {
  const [profiles, setProfiles] = useState<AdminProfile[]>([]);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<AdminRole>("viewer");
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/admin/profiles")
      .then((response) => response.json())
      .then((payload) => {
        if (Array.isArray(payload.profiles)) setProfiles(payload.profiles);
        if (payload.message) setMessage(payload.message);
      })
      .catch(() => undefined);
  }, []);

  async function addProfile() {
    const response = await fetch("/api/admin/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, fullName, role })
    });
    const payload = await response.json();

    if (payload.profile) {
      setProfiles((current) => [payload.profile, ...current.filter((profile) => profile.id !== payload.profile.id)]);
      setEmail("");
      setFullName("");
      setRole("viewer");
      setMessage("Ruolo assegnato.");
    } else {
      setMessage(payload.error || "Ruolo non assegnato.");
    }
  }

  async function patchProfile(id: string, updates: Partial<AdminProfile>) {
    const response = await fetch("/api/admin/profiles", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...updates })
    });
    const payload = await response.json();

    if (payload.profile) {
      setProfiles((current) => current.map((profile) => profile.id === id ? payload.profile : profile));
      setMessage("Profilo aggiornato.");
    } else {
      setMessage(payload.error || "Profilo non aggiornato.");
    }
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Staff e ruoli</h2>
            <p>Gestione ruoli owner, staff, editor e viewer collegata a Supabase Auth. Solo owner puo assegnare o disattivare accessi.</p>
          </div>

          <div className="split">
            <div className="dashboard-card">
              <h3>Assegna ruolo</h3>
              <div className="form-grid">
                <div className="field full"><label>Email utente Auth</label><input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="utente@gammaone.it" /></div>
                <div className="field"><label>Nome</label><input value={fullName} onChange={(event) => setFullName(event.target.value)} /></div>
                <div className="field"><label>Ruolo</label><select value={role} onChange={(event) => setRole(event.target.value as AdminRole)}><option value="owner">Owner</option><option value="staff">Staff</option><option value="editor">Editor</option><option value="viewer">Viewer</option></select></div>
                <div className="field full"><button type="button" className="btn btn-primary" onClick={addProfile}>Salva ruolo</button></div>
              </div>
              {message ? <p className="notice" style={{ marginTop: 14 }}>{message}</p> : null}
            </div>

            <div className="dashboard-card">
              <h3>Permessi</h3>
              <div className="summary">
                <div className="summary-row"><span>Owner</span><b>Tutto</b></div>
                <div className="summary-row"><span>Staff</span><b>Operativo</b></div>
                <div className="summary-row"><span>Editor</span><b>Contenuti</b></div>
                <div className="summary-row"><span>Viewer</span><b>Lettura</b></div>
              </div>
              <p className="notice">La creazione dell&apos;utente resta in Supabase Auth; qui si assegna il profilo operativo.</p>
            </div>
          </div>

          <div className="dashboard-card">
            <h3>Profili attivi</h3>
            <table className="table">
              <thead><tr><th>Utente</th><th>Ruolo</th><th>Accesso</th><th>Azioni</th></tr></thead>
              <tbody>
                {profiles.map((profile) => (
                  <tr key={profile.id}>
                    <td>{profile.full_name || profile.id}<br /><span className="micro">{profile.id}</span></td>
                    <td><select defaultValue={profile.role} onChange={(event) => patchProfile(profile.id, { role: event.target.value as AdminRole })}><option value="owner">Owner</option><option value="staff">Staff</option><option value="editor">Editor</option><option value="viewer">Viewer</option></select></td>
                    <td>{profile.active ? "Attivo" : "Disattivato"}</td>
                    <td><button type="button" className="btn btn-secondary btn-mini" onClick={() => patchProfile(profile.id, { active: !profile.active })}>{profile.active ? "Disattiva" : "Riattiva"}</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
