import { AdminNav, AppointmentTable, Header, KpiCard, LeadTable } from "@/components/ui";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { readDb } from "@/lib/store";
import type { Appointment, Lead } from "@/lib/types";
import { getAllVehicles } from "@/lib/vehicle-repository";
import { vehicleCompleteness, leadPriority } from "@/lib/vehicle-scoring";

export const dynamic = "force-dynamic";

async function getDashboardData() {
  const db = await readDb();
  const vehicles = await getAllVehicles();
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const [leads, appointments, customers, followUps] = await Promise.all([
      supabase.from("leads").select("*").order("created_at", { ascending: false }).limit(6),
      supabase.from("appointments").select("*").order("date", { ascending: true }).limit(6),
      supabase.from("customers").select("id", { count: "exact", head: true }),
      supabase.from("follow_ups").select("id", { count: "exact", head: true }).eq("status", "Da fare")
    ]);

    return {
      vehicles,
      leads: (leads.data as Lead[] | null) || db.leads.slice(0, 6),
      appointments: (appointments.data as Appointment[] | null) || db.appointments.slice(0, 6),
      customers: customers.count || 0,
      followUps: followUps.count || 0,
      source: "Supabase"
    };
  }

  return {
    vehicles,
    leads: db.leads.slice(0, 6),
    appointments: db.appointments.slice(0, 6),
    customers: db.customers?.length || 0,
    followUps: db.followUps?.filter((item) => item.status === "Da fare").length || 0,
    source: "Mock locale"
  };
}

export default async function AdminPage() {
  const data = await getDashboardData();
  const available = data.vehicles.filter((vehicle) => vehicle.status === "Disponibile").length;
  const finance = data.vehicles.filter((vehicle) => vehicle.finance).length;
  const rental = data.vehicles.filter((vehicle) => vehicle.service !== "Vendita").length;
  const weakVehicles = data.vehicles
    .map((vehicle) => ({ vehicle, quality: vehicleCompleteness(vehicle) }))
    .filter((item) => item.quality.score < 75)
    .sort((a, b) => a.quality.score - b.quality.score)
    .slice(0, 5);
  const hotLeads = data.leads
    .map((lead) => ({ lead, priority: leadPriority(lead) }))
    .sort((a, b) => b.priority.score - a.priority.score)
    .slice(0, 4);

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Area dealer</h2>
            <p>Pannello operativo per gestire veicoli, richieste, appuntamenti e priorità commerciali senza toccare il sito pubblico.</p>
          </div>

          <div className="dashboard-grid">
            <KpiCard label="Veicoli totali" value={data.vehicles.length} note={data.source} />
            <KpiCard label="Disponibili" value={available} />
            <KpiCard label="Finanziabili" value={finance} />
            <KpiCard label="Noleggio" value={rental} />
            <KpiCard label="Clienti CRM" value={data.customers} />
            <KpiCard label="Follow-up aperti" value={data.followUps} />
          </div>

          <div className="split">
            <div className="dashboard-card">
              <h3>Priorità commerciali</h3>
              <div className="ops-list">
                {hotLeads.length ? hotLeads.map(({ lead, priority }) => (
                  <div key={lead.id}>
                    <b>{priority.label}: {lead.name}</b>
                    <span>{priority.nextAction}</span>
                  </div>
                )) : <p className="micro">Nessuna richiesta calda nei dati attuali.</p>}
              </div>
            </div>
            <div className="dashboard-card">
              <h3>Schede da sistemare</h3>
              <div className="ops-list">
                {weakVehicles.length ? weakVehicles.map(({ vehicle, quality }) => (
                  <div key={vehicle.id}>
                    <b>{vehicle.title} · {quality.score}%</b>
                    <span>Mancano: {quality.missing.slice(0, 3).join(", ")}</span>
                  </div>
                )) : <p className="micro">Inventario completo: pronto per campagne e SEO.</p>}
              </div>
            </div>
          </div>

          <div className="split">
            <div className="dashboard-card">
            <h3>Richieste recenti</h3>
              <LeadTable leads={data.leads} />
            </div>
            <div className="dashboard-card">
              <h3>Appuntamenti</h3>
              <AppointmentTable appointments={data.appointments} />
            </div>
          </div>

          <div className="dashboard-card">
            <h3>Roadmap produzione</h3>
            <div className="features">
              <div className="feature"><span className="check">1</span><span>Auth proprietario/staff con ruoli e permessi.</span></div>
              <div className="feature"><span className="check">2</span><span>Supabase reale con regole di accesso e dati definitivi.</span></div>
              <div className="feature"><span className="check">3</span><span>Upload foto multiplo con storage configurato.</span></div>
              <div className="feature"><span className="check">4</span><span>Email, calendario e WhatsApp verificati con account aziendali.</span></div>
              <div className="feature"><span className="check">5</span><span>SEO dinamica e dati strutturati completati sui veicoli reali.</span></div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
