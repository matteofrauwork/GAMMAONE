import { AdminNav, Header } from "@/components/ui";
import { getEnvReport, getMissingRequiredEnv } from "@/lib/env";

export const dynamic = "force-dynamic";

export default function AdminConfigurationPage() {
  const report = getEnvReport();
  const missingRequired = getMissingRequiredEnv();

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Configurazione produzione</h2>
            <p>Controllo rapido delle variabili necessarie per pubblicare il sito con dati, upload, email, calendario e contatti reali.</p>
          </div>

          {missingRequired.length ? (
            <div className="notice">Mancano {missingRequired.length} variabili obbligatorie prima del deploy.</div>
          ) : (
            <div className="notice">Le variabili obbligatorie risultano configurate. Verifica comunque i servizi reali prima della pubblicazione.</div>
          )}

          <div className="admin-config-grid">
            {report.map((group) => (
              <article className="dashboard-card" key={group.name}>
                <h3>{group.name}</h3>
                <div className="summary">
                  {group.items.map((item) => (
                    <div className="summary-row" key={item.key}>
                      <span>{item.label}</span>
                      <b className={item.configured ? "config-ok" : item.requiredForDeploy ? "config-missing" : ""}>
                        {item.configured ? item.valuePreview : item.requiredForDeploy ? "Manca" : "Opzionale"}
                      </b>
                    </div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
