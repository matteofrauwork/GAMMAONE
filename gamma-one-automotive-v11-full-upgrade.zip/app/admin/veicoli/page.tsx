"use client";

import { useEffect, useMemo, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import { bodies, fuels, gearboxes, vehicles as seedVehicles, formatCurrency, formatNumber } from "@/lib/data";
import type { Vehicle } from "@/lib/types";
import { missingVehicleFields, vehicleQualityScore } from "@/lib/quality";

type Draft = {
  title: string;
  brand: string;
  model: string;
  year: number;
  km: number;
  price: number;
  body: string;
  fuel: string;
  gearbox: string;
  powerHp: number;
  status: string;
  service: string;
  visibility: "public" | "draft" | "hidden";
  heroImage: string;
  imagesText: string;
  videoUrl: string;
};

const initialDraft: Draft = {
  title: "",
  brand: "Porsche",
  model: "",
  year: 2024,
  km: 0,
  price: 0,
  body: "Coupé",
  fuel: "Benzina",
  gearbox: "Automatico",
  powerHp: 0,
  status: "Disponibile",
  service: "Vendita",
  visibility: "draft",
  heroImage: "/media/vehicles/supercar-coupe.svg",
  imagesText: "/media/vehicles/supercar-coupe.svg",
  videoUrl: ""
};

export default function AdminVehiclesPage() {
  const [draft, setDraft] = useState<Draft>(initialDraft);
  const [localVehicles, setLocalVehicles] = useState<Vehicle[]>(seedVehicles);
  const [message, setMessage] = useState("");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetch("/api/vehicles")
      .then((response) => response.json())
      .then((payload) => {
        if (Array.isArray(payload.vehicles) && payload.vehicles.every((vehicle: Partial<Vehicle>) => vehicle.title && vehicle.heroImage)) {
          setLocalVehicles(payload.vehicles);
        }
      })
      .catch(() => undefined);
  }, []);

  const sorted = useMemo(() => [...localVehicles].sort((a, b) => b.year - a.year), [localVehicles]);

  function update<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function uploadPhoto(file: File) {
    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/upload", { method: "POST", body: formData });
      const payload = await response.json();
      const url = payload?.result?.secure_url || payload?.result?.url || payload?.url;
      if (url) {
        setDraft((current) => {
          const urls = Array.from(new Set([url, ...current.imagesText.split(/[\n,]/).map((item) => item.trim()).filter(Boolean)]));
          return { ...current, heroImage: url, imagesText: urls.join("\n") };
        });
        setMessage("Foto caricata/collegata correttamente.");
      } else {
        setMessage("Upload non completato: configura Cloudinary o S3 per ottenere un URL reale.");
      }
    } catch {
      setMessage("Errore upload. Controlla configurazione Cloudinary/S3.");
    } finally {
      setUploading(false);
    }
  }

  async function addVehicle() {
    if (!draft.title || !draft.model || !draft.price) {
      setMessage("Compila almeno titolo, modello e prezzo.");
      return;
    }

    const imageUrls = Array.from(new Set([
      draft.heroImage,
      ...draft.imagesText.split(/[\n,]/).map((item) => item.trim())
    ].filter(Boolean)));

    const response = await fetch("/api/vehicles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...draft,
        images: imageUrls,
        heroImage: draft.heroImage || imageUrls[0],
        monthlyFrom: Math.max(79, Math.round(draft.price / 75)),
        location: "Senorbì, Sardegna",
        warrantyMonths: 12,
        finance: true,
        iva: false,
        neopatentati: false,
        equipment: ["Apple CarPlay", "Fari LED"],
        highlights: ["Inserito da admin"],
        description: "Veicolo inserito da pannello proprietario. Completare descrizione, controlli, condizioni e documenti."
      })
    });

    const payload = await response.json();
    if (payload.vehicle?.title && payload.vehicle?.heroImage) {
      setLocalVehicles((current) => [payload.vehicle, ...current]);
      setDraft(initialDraft);
      setMessage("Veicolo salvato correttamente.");
    } else {
      setMessage(payload.error || "Veicolo salvato, ma mapping dati da verificare.");
    }
  }

  async function patchVehicle(id: string, body: Partial<Vehicle>) {
    const response = await fetch(`/api/vehicles/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const payload = await response.json();

    if (payload.vehicle?.title && payload.vehicle?.heroImage) {
      setLocalVehicles((current) => current.map((vehicle) => vehicle.id === id ? payload.vehicle : vehicle));
    } else {
      setLocalVehicles((current) => current.map((vehicle) => vehicle.id === id ? { ...vehicle, ...body } : vehicle));
    }
  }

  async function deleteVehicle(id: string) {
    await fetch(`/api/vehicles/${id}`, { method: "DELETE" });
    setLocalVehicles((current) => current.filter((vehicle) => vehicle.id !== id));
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Gestione catalogo</h2>
            <p>Aggiungi veicoli, carica foto, modifica prezzo e stato, rimuovi mezzi non più disponibili.</p>
          </div>

          <div className="admin-tools">
            <div className="admin-tool"><b>Catalogo</b><span>Creazione, modifica e rimozione veicoli.</span></div>
            <div className="admin-tool"><b>Foto</b><span>Cloudinary o S3 configurabili.</span></div>
            <div className="admin-tool"><b>Status</b><span>Disponibile, venduto, prenotato, noleggiato.</span></div>
            <div className="admin-tool"><b>Dati</b><span>Archivio collegabile a Supabase.</span></div>
          </div>

          <div className="split">
            <div className="dashboard-card">
              <h3>Nuovo veicolo</h3>
              <div className="form-grid">
                <div className="field full"><label>Titolo scheda</label><input value={draft.title} onChange={(e) => update("title", e.target.value)} placeholder="Porsche 911 Carrera S" /></div>
                <div className="field"><label>Marca</label><input value={draft.brand} onChange={(e) => update("brand", e.target.value)} /></div>
                <div className="field"><label>Modello</label><input value={draft.model} onChange={(e) => update("model", e.target.value)} placeholder="911" /></div>
                <div className="field"><label>Anno</label><input type="number" value={draft.year} onChange={(e) => update("year", Number(e.target.value))} /></div>
                <div className="field"><label>Km</label><input type="number" value={draft.km} onChange={(e) => update("km", Number(e.target.value))} /></div>
                <div className="field"><label>Prezzo</label><input type="number" value={draft.price} onChange={(e) => update("price", Number(e.target.value))} /></div>
                <div className="field"><label>Potenza CV</label><input type="number" value={draft.powerHp} onChange={(e) => update("powerHp", Number(e.target.value))} /></div>
                <div className="field"><label>Carrozzeria</label><select value={draft.body} onChange={(e) => update("body", e.target.value)}>{bodies.map((body) => <option key={body}>{body}</option>)}</select></div>
                <div className="field"><label>Alimentazione</label><select value={draft.fuel} onChange={(e) => update("fuel", e.target.value)}>{fuels.map((fuel) => <option key={fuel}>{fuel}</option>)}</select></div>
                <div className="field"><label>Cambio</label><select value={draft.gearbox} onChange={(e) => update("gearbox", e.target.value)}>{gearboxes.map((gearbox) => <option key={gearbox}>{gearbox}</option>)}</select></div>
                <div className="field"><label>Servizio</label><select value={draft.service} onChange={(e) => update("service", e.target.value)}><option>Vendita</option><option>Noleggio</option><option>Vendita/Noleggio</option></select></div>
                <div className="field"><label>Stato</label><select value={draft.status} onChange={(e) => update("status", e.target.value)}><option>Disponibile</option><option>Venduto</option><option>Prenotato</option><option>In arrivo</option><option>Noleggiato</option></select></div>
                <div className="field"><label>Visibilita</label><select value={draft.visibility} onChange={(e) => update("visibility", e.target.value as Draft["visibility"])}><option value="draft">Bozza</option><option value="public">Pubblico</option><option value="hidden">Nascosto</option></select></div>
                <div className="field full"><label>Immagine URL</label><input value={draft.heroImage} onChange={(e) => update("heroImage", e.target.value)} /></div>
                <div className="field full"><label>Galleria immagini URL</label><textarea value={draft.imagesText} onChange={(e) => update("imagesText", e.target.value)} rows={4} placeholder="Un URL per riga. La prima immagine resta la copertina." /></div>
                <div className="field full"><label>Video walkaround URL</label><input value={draft.videoUrl} onChange={(e) => update("videoUrl", e.target.value)} placeholder="Link YouTube, Vimeo o video verificato" /></div>
                <div className="field full file-upload"><label>Foto veicolo</label><input type="file" accept="image/*" onChange={(event) => event.target.files?.[0] && uploadPhoto(event.target.files[0])} /><p className="micro">{uploading ? "Caricamento..." : "Disponibile quando l'archivio immagini è configurato."}</p></div>
                <div className="field full"><button type="button" className="btn btn-primary" onClick={addVehicle}>Aggiungi al catalogo</button></div>
              </div>
              {message ? <p className="notice" style={{ marginTop: 14 }}>{message}</p> : null}
            </div>

            <div className="dashboard-card">
              <h3>Anteprima immagine</h3>
              <div className="luxury-frame" style={{ minHeight: 380 }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={draft.heroImage} alt="Anteprima veicolo" />
                <div className="luxury-caption"><h3>{draft.title || "Nuovo veicolo"}</h3><p>{draft.brand} · {draft.model} · {draft.year}</p></div>
              </div>
            </div>
          </div>

          <div className="dashboard-card">
            <h3>Veicoli nel catalogo</h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Veicolo</th>
                  <th>Anno / km</th>
                  <th>Prezzo</th>
                  <th>Status</th>
                  <th>Qualita</th>
                  <th>Azioni</th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((vehicle) => {
                  const score = vehicleQualityScore(vehicle);
                  const missing = missingVehicleFields(vehicle);

                  return (
                    <tr key={vehicle.id}>
                      <td>{vehicle.title}<br /><span className="micro">{vehicle.brand} · {vehicle.model} · {vehicle.service}</span></td>
                      <td>{vehicle.year}<br /><span className="micro">{formatNumber(vehicle.km)} km</span></td>
                      <td><input className="input-mini" type="number" defaultValue={vehicle.price} onBlur={(e) => patchVehicle(vehicle.id, { price: Number(e.target.value) })} /><br /><span className="micro">{formatCurrency(vehicle.price)}</span></td>
                      <td><select defaultValue={vehicle.status} onChange={(e) => patchVehicle(vehicle.id, { status: e.target.value as Vehicle["status"] })}><option>Disponibile</option><option>Venduto</option><option>Prenotato</option><option>In arrivo</option><option>Noleggiato</option></select><select defaultValue={vehicle.visibility || "public"} onChange={(e) => patchVehicle(vehicle.id, { visibility: e.target.value as Vehicle["visibility"] })} style={{ marginTop: 8 }}><option value="public">Pubblico</option><option value="draft">Bozza</option><option value="hidden">Nascosto</option></select></td>
                      <td><b>{score}%</b><br /><span className="micro">{missing.slice(0, 3).join(", ") || "Scheda completa"}</span></td>
                      <td><div className="crud-actions"><a className="btn btn-secondary btn-mini" href={`/veicoli/${vehicle.slug}`}>Apri</a><button type="button" className="btn btn-secondary btn-mini" onClick={() => deleteVehicle(vehicle.id)}>Elimina</button></div></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
