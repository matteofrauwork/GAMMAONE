"use client";

import { useEffect, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import { demoAppointments } from "@/lib/data";
import type { Appointment } from "@/lib/types";

export default function AdminCalendarPage() {
  const [appointments, setAppointments] = useState<Appointment[]>(demoAppointments);

  useEffect(() => {
    fetch("/api/appointments")
      .then((response) => response.json())
      .then((payload) => Array.isArray(payload.appointments) && setAppointments(payload.appointments))
      .catch(() => undefined);
  }, []);

  async function updateAppointment(id: string, status: Appointment["status"]) {
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    setAppointments((current) => current.map((appointment) => appointment.id === id ? { ...appointment, status } : appointment));
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Calendario dealer</h2>
            <p>Appuntamenti per visione veicolo, test drive, noleggio, permuta o ricerca su richiesta. Gestione stati dal pannello.</p>
          </div>

          <div className="dashboard-card">
            <h3>Appuntamenti</h3>
            <table className="table">
              <thead><tr><th>Data</th><th>Cliente</th><th>Motivo</th><th>Veicolo</th><th>Status</th></tr></thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id}>
                    <td>{appointment.date} · {appointment.slot}</td>
                    <td>{appointment.name}<br /><span className="micro">{appointment.phone}</span></td>
                    <td>{appointment.reason}</td>
                    <td>{appointment.vehicle || "—"}</td>
                    <td><select defaultValue={appointment.status} onChange={(e) => updateAppointment(appointment.id, e.target.value as Appointment["status"])}><option>Richiesto</option><option>Confermato</option><option>Completato</option><option>Annullato</option></select></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="dashboard-card">
            <h3>Slot operativi</h3>
            <div className="slot-grid">
              {["09:00", "10:00", "11:00", "12:00", "15:00", "16:00", "17:00", "18:00"].map((slot) => <span className="slot" key={slot}>{slot}</span>)}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
