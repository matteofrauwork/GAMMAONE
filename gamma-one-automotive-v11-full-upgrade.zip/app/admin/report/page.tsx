import { AdminNav, Header, KpiCard } from "@/components/ui";
import { readDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { getAllVehicles } from "@/lib/vehicle-repository";

export const dynamic = "force-dynamic";

async function getCounts() {
  const vehicles = await getAllVehicles();
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const [leads, appointments, customers, followUps, events] = await Promise.all([
      supabase.from("leads").select("id", { count: "exact", head: true }),
      supabase.from("appointments").select("id", { count: "exact", head: true }),
      supabase.from("customers").select("id", { count: "exact", head: true }),
      supabase.from("follow_ups").select("id", { count: "exact", head: true }).eq("status", "Da fare"),
      supabase.from("analytics_events").select("id", { count: "exact", head: true })
    ]);

    return {
      vehicles: vehicles.length,
      available: vehicles.filter((vehicle) => vehicle.status === "Disponibile").length,
      leads: leads.count || 0,
      appointments: appointments.count || 0,
      customers: customers.count || 0,
      followUps: followUps.count || 0,
      events: events.count || 0,
      source: "Supabase"
    };
  }

  const db = await readDb();
  return {
    vehicles: vehicles.length,
    available: vehicles.filter((vehicle) => vehicle.status === "Disponibile").length,
    leads: db.leads.length,
    appointments: db.appointments.length,
    customers: db.customers?.length || 0,
    followUps: db.followUps?.filter((item) => item.status === "Da fare").length || 0,
    events: db.analyticsEvents?.length || 0,
    source: "Mock locale"
  };
}

export default async function AdminReportPage() {
  const counts = await getCounts();

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Report mensile</h2>
            <p>Base operativa per leggere andamento catalogo, richieste, appuntamenti ed eventi. I dati diventano reali quando Supabase e analytics sono configurati.</p>
          </div>
          <div className="dashboard-grid">
            <KpiCard label="Veicoli" value={counts.vehicles} note={counts.source} />
            <KpiCard label="Disponibili" value={counts.available} />
            <KpiCard label="Richieste" value={counts.leads} />
            <KpiCard label="Appuntamenti" value={counts.appointments} />
            <KpiCard label="Clienti" value={counts.customers} />
            <KpiCard label="Follow-up aperti" value={counts.followUps} />
          </div>
          <div className="dashboard-card">
            <h3>Eventi tracciati</h3>
            <p className="lead small">{counts.events} eventi registrati con consenso analytics. Per report commerciali avanzati servono obiettivi, canali e regole di attribuzione reali.</p>
          </div>
        </section>
      </main>
    </div>
  );
}
