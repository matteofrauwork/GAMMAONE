"use client";

import { useEffect, useMemo, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import type { Customer, FollowUp } from "@/lib/types";

type Draft = {
  title: string;
  dueAt: string;
  customerId: string;
  channel: FollowUp["channel"];
  notes: string;
};

function nextBusinessSlot() {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  date.setHours(10, 0, 0, 0);
  return date.toISOString().slice(0, 16);
}

const initialDraft: Draft = {
  title: "",
  dueAt: nextBusinessSlot(),
  customerId: "",
  channel: "Telefono",
  notes: ""
};

export default function AdminFollowUpPage() {
  const [followUps, setFollowUps] = useState<FollowUp[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [draft, setDraft] = useState<Draft>(initialDraft);
  const [message, setMessage] = useState("");

  useEffect(() => {
    Promise.all([
      fetch("/api/follow-ups").then((response) => response.json()),
      fetch("/api/customers").then((response) => response.json())
    ])
      .then(([followUpPayload, customerPayload]) => {
        if (Array.isArray(followUpPayload.followUps)) setFollowUps(followUpPayload.followUps);
        if (Array.isArray(customerPayload.customers)) setCustomers(customerPayload.customers);
      })
      .catch(() => undefined);
  }, []);

  const customerById = useMemo(
    () => new Map(customers.map((customer) => [customer.id, customer])),
    [customers]
  );

  const openFollowUps = useMemo(
    () => followUps.filter((item) => item.status === "Da fare").sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime()),
    [followUps]
  );

  function update<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function addFollowUp() {
    if (!draft.title || !draft.dueAt) {
      setMessage("Inserisci titolo e scadenza.");
      return;
    }

    const response = await fetch("/api/follow-ups", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(draft)
    });
    const payload = await response.json();

    if (payload.followUp) {
      setFollowUps((current) => [payload.followUp, ...current]);
      setDraft(initialDraft);
      setMessage("Follow-up programmato.");
    } else {
      setMessage(payload.error || "Follow-up non salvato.");
    }
  }

  async function markDone(id: string, status: FollowUp["status"]) {
    await fetch(`/api/follow-ups/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    setFollowUps((current) => current.map((followUp) => followUp.id === id ? { ...followUp, status } : followUp));
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Follow-up</h2>
            <p>Lista delle prossime azioni commerciali: chiamate, WhatsApp, email e appuntamenti da non perdere.</p>
          </div>

          <div className="split">
            <div className="dashboard-card">
              <h3>Nuova attività</h3>
              <div className="form-grid">
                <div className="field full"><label>Titolo</label><input value={draft.title} onChange={(event) => update("title", event.target.value)} placeholder="Richiamare per conferma permuta" /></div>
                <div className="field"><label>Scadenza</label><input type="datetime-local" value={draft.dueAt} onChange={(event) => update("dueAt", event.target.value)} /></div>
                <div className="field"><label>Canale</label><select value={draft.channel} onChange={(event) => update("channel", event.target.value as FollowUp["channel"])}><option>Telefono</option><option>WhatsApp</option><option>Email</option><option>Appuntamento</option></select></div>
                <div className="field full"><label>Cliente</label><select value={draft.customerId} onChange={(event) => update("customerId", event.target.value)}><option value="">Non collegato</option>{customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name} · {customer.interest}</option>)}</select></div>
                <div className="field full"><label>Note</label><textarea value={draft.notes} onChange={(event) => update("notes", event.target.value)} rows={4} /></div>
                <div className="field full"><button type="button" className="btn btn-primary" onClick={addFollowUp}>Programma follow-up</button></div>
              </div>
              {message ? <p className="notice" style={{ marginTop: 14 }}>{message}</p> : null}
            </div>

            <div className="dashboard-card">
              <h3>Priorità</h3>
              <div className="summary">
                <div className="summary-row"><span>Da fare</span><b>{openFollowUps.length}</b></div>
                <div className="summary-row"><span>Completati</span><b>{followUps.filter((item) => item.status === "Completato").length}</b></div>
                <div className="summary-row"><span>Clienti collegabili</span><b>{customers.length}</b></div>
              </div>
              <p className="notice">Le notifiche automatiche WhatsApp o email vanno abilitate solo dopo consenso, template approvati e policy chiare.</p>
            </div>
          </div>

          <div className="dashboard-card">
            <h3>Prossime attività</h3>
            <table className="table">
              <thead><tr><th>Quando</th><th>Attività</th><th>Cliente</th><th>Canale</th><th>Status</th></tr></thead>
              <tbody>
                {followUps.map((followUp) => (
                  <tr key={followUp.id}>
                    <td>{new Date(followUp.dueAt).toLocaleString("it-IT")}</td>
                    <td>{followUp.title}<br /><span className="micro">{followUp.notes || "Nessuna nota"}</span></td>
                    <td>{followUp.customerId ? customerById.get(followUp.customerId)?.name || "Cliente collegato" : "—"}</td>
                    <td>{followUp.channel}</td>
                    <td><select defaultValue={followUp.status} onChange={(event) => markDone(followUp.id, event.target.value as FollowUp["status"])}><option>Da fare</option><option>Completato</option><option>Saltato</option></select></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
