"use client";

import { useEffect, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import { demoLeads } from "@/lib/data";
import type { Lead } from "@/lib/types";

export default function AdminLeadPage() {
  const [leads, setLeads] = useState<Lead[]>(demoLeads);

  useEffect(() => {
    fetch("/api/leads")
      .then((response) => response.json())
      .then((payload) => Array.isArray(payload.leads) && setLeads(payload.leads))
      .catch(() => undefined);
  }, []);

  async function updateLead(id: string, status: Lead["status"]) {
    await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    setLeads((current) => current.map((lead) => lead.id === id ? { ...lead, status } : lead));
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Richieste clienti</h2>
            <p>Il proprietario vede priorità, messaggi, telefono e stato commerciale in un flusso leggibile.</p>
          </div>

          <div className="dashboard-card">
            <h3>Richieste ricevute</h3>
            <table className="table">
              <thead><tr><th>Cliente</th><th>Tipo</th><th>Messaggio</th><th>Score</th><th>Status</th></tr></thead>
              <tbody>
                {leads.map((lead) => (
                  <tr key={lead.id}>
                    <td>{lead.name}<br /><span className="micro">{lead.phone}</span></td>
                    <td>{lead.type}</td>
                    <td>{lead.message}</td>
                    <td>{lead.score}</td>
                    <td><select defaultValue={lead.status} onChange={(e) => updateLead(lead.id, e.target.value as Lead["status"])}><option>Nuovo</option><option>Contattato</option><option>In trattativa</option><option>Chiuso</option><option>Perso</option></select></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
