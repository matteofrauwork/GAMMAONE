"use client";

import { useEffect, useMemo, useState } from "react";
import { AdminNav, Header } from "@/components/ui";
import type { Customer } from "@/lib/types";

type Draft = {
  name: string;
  phone: string;
  email: string;
  source: string;
  interest: string;
  notes: string;
};

const initialDraft: Draft = {
  name: "",
  phone: "",
  email: "",
  source: "Manuale",
  interest: "Acquisto veicolo",
  notes: ""
};

export default function AdminCustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [draft, setDraft] = useState<Draft>(initialDraft);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/customers")
      .then((response) => response.json())
      .then((payload) => Array.isArray(payload.customers) && setCustomers(payload.customers))
      .catch(() => undefined);
  }, []);

  const sortedCustomers = useMemo(
    () => [...customers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [customers]
  );

  function update<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function addCustomer() {
    if (!draft.name || !draft.phone) {
      setMessage("Inserisci almeno nome e telefono.");
      return;
    }

    const response = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(draft)
    });
    const payload = await response.json();

    if (payload.customer) {
      setCustomers((current) => [payload.customer, ...current]);
      setDraft(initialDraft);
      setMessage("Cliente aggiunto al CRM.");
    } else {
      setMessage(payload.error || "Cliente non salvato.");
    }
  }

  async function updateStatus(id: string, status: Customer["status"]) {
    await fetch(`/api/customers/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    setCustomers((current) => current.map((customer) => customer.id === id ? { ...customer, status } : customer));
  }

  return (
    <div className="page">
      <Header />
      <main className="wrap admin-layout">
        <AdminNav />
        <section className="admin-main" style={{ padding: 0 }}>
          <div className="section-head" style={{ marginBottom: 0 }}>
            <h2>Clienti</h2>
            <p>Archivio operativo per clienti, interessi e stato commerciale. Pensato per lavorare bene, non per fare scena.</p>
          </div>

          <div className="split">
            <div className="dashboard-card">
              <h3>Nuovo cliente</h3>
              <div className="form-grid">
                <div className="field"><label>Nome</label><input value={draft.name} onChange={(event) => update("name", event.target.value)} /></div>
                <div className="field"><label>Telefono</label><input value={draft.phone} onChange={(event) => update("phone", event.target.value)} /></div>
                <div className="field"><label>Email</label><input value={draft.email} onChange={(event) => update("email", event.target.value)} /></div>
                <div className="field"><label>Origine</label><select value={draft.source} onChange={(event) => update("source", event.target.value)}><option>Manuale</option><option>Sito</option><option>WhatsApp</option><option>Telefono</option><option>Referral</option></select></div>
                <div className="field full"><label>Interesse</label><input value={draft.interest} onChange={(event) => update("interest", event.target.value)} placeholder="Es. Porsche 911, noleggio SUV, permuta moto" /></div>
                <div className="field full"><label>Note</label><textarea value={draft.notes} onChange={(event) => update("notes", event.target.value)} rows={4} /></div>
                <div className="field full"><button type="button" className="btn btn-primary" onClick={addCustomer}>Salva cliente</button></div>
              </div>
              {message ? <p className="notice" style={{ marginTop: 14 }}>{message}</p> : null}
            </div>

            <div className="dashboard-card">
              <h3>Vista rapida</h3>
              <div className="summary">
                <div className="summary-row"><span>Clienti totali</span><b>{customers.length}</b></div>
                <div className="summary-row"><span>In follow-up</span><b>{customers.filter((customer) => customer.status === "In follow-up").length}</b></div>
                <div className="summary-row"><span>Clienti acquisiti</span><b>{customers.filter((customer) => customer.status === "Cliente").length}</b></div>
              </div>
              <p className="notice">Per notifiche automatiche, segmenti e report economici serve configurare Supabase reale e policy operative.</p>
            </div>
          </div>

          <div className="dashboard-card">
            <h3>Archivio clienti</h3>
            <table className="table">
              <thead><tr><th>Cliente</th><th>Interesse</th><th>Origine</th><th>Status</th><th>Note</th></tr></thead>
              <tbody>
                {sortedCustomers.map((customer) => (
                  <tr key={customer.id}>
                    <td>{customer.name}<br /><span className="micro">{customer.phone}{customer.email ? ` · ${customer.email}` : ""}</span></td>
                    <td>{customer.interest}</td>
                    <td>{customer.source}</td>
                    <td><select defaultValue={customer.status} onChange={(event) => updateStatus(customer.id, event.target.value as Customer["status"])}><option>Nuovo</option><option>Attivo</option><option>In follow-up</option><option>Cliente</option><option>Non interessato</option></select></td>
                    <td>{customer.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
