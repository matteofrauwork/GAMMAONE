import type { Metadata } from "next";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getAdminRole } from "@/lib/api/security";
import { hasSupabaseEnv } from "@/lib/supabase/server";

export const metadata: Metadata = {
  robots: {
    index: false,
    follow: false
  }
};

export default async function AdminLayout({ children }: { children: ReactNode }) {
  if (hasSupabaseEnv()) {
    const role = await getAdminRole();

    if (!role) {
      redirect("/login?error=Permessi area riservata non configurati.");
    }
  }

  return children;
}
