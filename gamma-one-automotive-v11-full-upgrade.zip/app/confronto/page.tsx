import type { Metadata } from "next";
import { CompareVehicles } from "@/components/saved-vehicles";
import { Footer, Header } from "@/components/ui";

export const metadata: Metadata = {
  title: "Confronto veicoli",
  robots: {
    index: false,
    follow: false
  }
};

export default function ComparePage() {
  return (
    <div className="page">
      <Header />
      <main>
        <CompareVehicles />
      </main>
      <Footer />
    </div>
  );
}
