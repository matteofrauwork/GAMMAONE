import type { Metadata } from "next";
import { MethodSection, PublicLandingPage } from "@/components/public-sections";
import { LeadRequestForm } from "@/components/request-forms";
import { buildCustomSearchWhatsApp } from "@/lib/whatsapp";

export const metadata: Metadata = {
  title: "Ricerca veicolo su richiesta",
  description: "Ricerca auto e moto su richiesta in Sardegna: budget, modello, rata, alimentazione, km e tempi raccolti in modo ordinato.",
  alternates: { canonical: "/ricerca-su-richiesta" }
};

export default function CustomSearchPage() {
  return (
    <PublicLandingPage
      title="Non trovi il veicolo giusto? Lo cerchiamo per te."
      subtitle="Indica budget, modello, rata, cambio, alimentazione, anno minimo, km massimi, optional e tempi. La richiesta arriva già ordinata."
      primaryHref={buildCustomSearchWhatsApp()}
      primaryLabel="Avvia ricerca"
      secondaryHref="/veicoli"
      secondaryLabel="Vedi catalogo"
    >
      <section>
        <div className="wrap split">
          <LeadRequestForm kind="custom-search" />
          <div className="panel">
            <h3>Perché funziona</h3>
            <p>Se il catalogo è piccolo, la ricerca su richiesta trasforma il limite in servizio. Gamma One non vende solo stock: aiuta a trovare il mezzo adatto.</p>
          </div>
        </div>
      </section>
      <MethodSection />
    </PublicLandingPage>
  );
}
