import type { Metadata } from "next";
import { Footer, Header, VehicleCard } from "@/components/ui";
import { getPublicVehiclesByStatus } from "@/lib/vehicle-repository";

export const metadata: Metadata = {
  title: "Veicoli in arrivo",
  description: "Auto e moto in arrivo da Gamma One in Sardegna. Disponibilita e condizioni da confermare con lo staff.",
  alternates: { canonical: "/in-arrivo" }
};

export default async function IncomingVehiclesPage() {
  const vehicles = await getPublicVehiclesByStatus(["In arrivo"]);

  return (
    <div className="page">
      <Header />
      <main>
        <section className="catalog-app">
          <div className="wrap">
            <div className="catalog-toolbar">
              <div>
                <h1>Veicoli in arrivo.</h1>
                <p>Una selezione da seguire prima della pubblicazione completa. Foto, dati e disponibilita vanno confermati.</p>
              </div>
            </div>

            {vehicles.length ? (
              <div className="results-grid">
                {vehicles.map((vehicle) => <VehicleCard key={vehicle.id} vehicle={vehicle} />)}
              </div>
            ) : (
              <div className="empty-state">
                <h3>Nessun veicolo in arrivo pubblicato.</h3>
                <p>Quando lo staff segna un veicolo come in arrivo e pubblico, comparira qui.</p>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
