import type { Metadata } from "next";
import { FavoriteVehicles } from "@/components/saved-vehicles";
import { Footer, Header } from "@/components/ui";

export const metadata: Metadata = {
  title: "Veicoli salvati",
  robots: {
    index: false,
    follow: false
  }
};

export default function FavoritesPage() {
  return (
    <div className="page">
      <Header />
      <main>
        <FavoriteVehicles />
      </main>
      <Footer />
    </div>
  );
}
