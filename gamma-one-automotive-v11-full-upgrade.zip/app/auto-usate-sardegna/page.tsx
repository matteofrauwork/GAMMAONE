import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Auto usate Sardegna",
  description: "Auto usate selezionate in Sardegna con catalogo ordinato, permuta, finanziamento e ricerca su richiesta.",
  alternates: { canonical: "/auto-usate-sardegna" }
};

export default function UsedCarsSardiniaPage() {
  return (
    <LocalSeoPage
      title="Auto usate selezionate in Sardegna."
      subtitle="Catalogo ordinato, dati chiari e appuntamento su richiesta. Le disponibilita reali vanno confermate dallo staff."
      primaryHref="/veicoli"
      primaryLabel="Vedi catalogo"
      points={["Vendita auto", "Permuta usato", "Finanziamento", "Ricerca su richiesta", "Appuntamento", "Foto reali da verificare"]}
    />
  );
}
