import { MethodSection, PublicLandingPage, TrustSection } from "@/components/public-sections";

export default function AboutPage() {
  return (
    <PublicLandingPage
      title="Un riferimento automotive diretto, non una vetrina anonima."
      subtitle="Gamma One lavora su vendita, noleggio, permuta e ricerca su richiesta con una cosa al centro: rendere la trattativa più chiara e meno dispersiva."
      primaryHref="/#calendario"
      primaryLabel="Richiedi una visita"
      secondaryHref="/contatti"
      secondaryLabel="Contatti"
    >
      <TrustSection />
      <MethodSection />
    </PublicLandingPage>
  );
}
