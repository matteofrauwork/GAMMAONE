import type { Metadata } from "next";
import { PublicLandingPage, TrustSection } from "@/components/public-sections";

export const metadata: Metadata = {
  title: "Garanzia e controlli",
  description: "Garanzia, controlli e condizioni veicolo dichiarate prima della firma. Dati da confermare sul singolo veicolo.",
  alternates: { canonical: "/garanzia" }
};

export default function WarrantyPage() {
  return (
    <PublicLandingPage
      title="Garanzia, controlli e condizioni dichiarate prima della firma."
      subtitle="Ogni veicolo deve indicare garanzia, passaggio, revisione, stato gomme, tagliandi e condizioni rilevanti. Niente promesse vaghe."
      primaryHref="/veicoli"
      primaryLabel="Vedi veicoli"
      secondaryHref="/contatti"
      secondaryLabel="Chiedi informazioni"
    >
      <TrustSection />
    </PublicLandingPage>
  );
}
