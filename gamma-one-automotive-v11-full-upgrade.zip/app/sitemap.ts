import type { MetadataRoute } from "next";
import { getPublicVehicles } from "@/lib/vehicle-repository";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://gammaone.it";
  const vehicles = await getPublicVehicles();

  const staticRoutes = [
    "",
    "/veicoli",
    "/in-arrivo",
    "/consegnati",
    "/noleggio",
    "/permuta",
    "/ricerca-su-richiesta",
    "/chi-siamo",
    "/contatti",
    "/garanzia",
    "/finanziamento",
    "/recensioni",
    "/privacy",
    "/cookie-policy",
    "/condizioni-vendita",
    "/condizioni-noleggio",
    "/auto-usate-sardegna",
    "/auto-usate-cagliari",
    "/noleggio-auto-sardegna",
    "/noleggio-moto-sardegna",
    "/permuta-auto-sardegna",
    "/ricerca-auto-su-richiesta-sardegna"
  ];

  return [
    ...staticRoutes.map((route) => ({
      url: `${baseUrl}${route}`,
      lastModified: new Date()
    })),
    ...vehicles.map((vehicle) => ({
      url: `${baseUrl}/veicoli/${vehicle.slug}`,
      lastModified: new Date()
    }))
  ];
}
