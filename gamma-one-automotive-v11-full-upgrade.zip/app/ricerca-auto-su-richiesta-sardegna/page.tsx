import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Ricerca auto su richiesta in Sardegna",
  description: "Servizio Gamma One per trovare auto e moto su richiesta in Sardegna, con budget, permuta e tempi condivisi prima della ricerca.",
  alternates: { canonical: "/ricerca-auto-su-richiesta-sardegna" }
};

export default function BespokeSearchSardiniaPage() {
  return (
    <LocalSeoPage
      title="Ricerca auto su richiesta in Sardegna."
      subtitle="Per chi vuole un veicolo preciso, Gamma One raccoglie preferenze, budget, tempi e vincoli prima di proporre alternative concrete."
      primaryHref="/ricerca-su-richiesta"
      primaryLabel="Avvia ricerca"
      points={[
        "Brief iniziale con budget, marca, modello e uso previsto",
        "Possibile valutazione permuta collegata alla ricerca",
        "Proposte filtrate prima dell'appuntamento",
        "Condizioni e disponibilità sempre da verificare prima della conferma"
      ]}
    />
  );
}
