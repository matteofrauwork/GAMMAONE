import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Auto usate Cagliari e Sud Sardegna",
  description: "Selezione premium di auto usate, km0 e veicoli su richiesta per Cagliari e Sud Sardegna con Gamma One.",
  alternates: { canonical: "/auto-usate-cagliari" }
};

export default function UsedCarsCagliariPage() {
  return (
    <LocalSeoPage
      title="Auto usate a Cagliari e Sud Sardegna."
      subtitle="Gamma One segue clienti nell'area di Cagliari e nel Sud Sardegna con veicoli disponibili, ricerca su richiesta, permuta e appuntamenti dedicati."
      primaryHref="/veicoli"
      primaryLabel="Vedi veicoli"
      points={[
        "Catalogo ordinato con disponibilità da confermare",
        "Ricerca su richiesta per budget, modello e uso reale",
        "Permuta valutata prima della trattativa finale",
        "Appuntamento su disponibilità dello staff"
      ]}
    />
  );
}
