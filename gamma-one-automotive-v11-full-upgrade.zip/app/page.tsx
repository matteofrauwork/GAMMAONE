import Image from "next/image";
import Link from "next/link";
import { Footer, Header, ServiceTile, VehicleCard } from "@/components/ui";
import { CinematicHero } from "@/components/cinematic-hero";
import { AppointmentRequestForm } from "@/components/request-forms";
import { formatCurrency, formatNumber } from "@/lib/data";
import { getPublicVehicles } from "@/lib/vehicle-repository";

export default async function HomePage() {
  const vehicles = await getPublicVehicles();
  const featured = vehicles.slice(0, 3);
  const premium = vehicles[0];

  if (!premium) {
    return null;
  }

  return (
    <div className="page">
      <Header />

      <main>
        <section className="hero-clean">
          <div className="hero-backdrop">
            <CinematicHero />
          </div>
          <div className="wrap hero-clean-inner">
            <div className="hero-copy">
              <h1>Trova il veicolo giusto. Prima degli altri.</h1>
              <p className="lead">Gamma One seleziona vendita, noleggio, permuta e ricerca su richiesta in Sardegna. Tu invii una richiesta chiara, lo staff conferma condizioni e prossimi passi.</p>
              <div className="hero-cta">
                <Link className="btn btn-primary" href="/veicoli">Vedi disponibilita ora</Link>
                <Link className="btn btn-secondary" href="/ricerca-su-richiesta">Richiesta prioritaria</Link>
              </div>
            </div>

            <form className="quick-search" action="/veicoli">
              <h2>Parti dal veicolo</h2>
              <div className="quick-search-grid">
                <label>
                  <span>Servizio</span>
                  <select name="service" defaultValue="">
                    <option value="">Qualsiasi</option>
                    <option value="Vendita">Acquisto</option>
                    <option value="Noleggio">Noleggio</option>
                    <option value="Vendita/Noleggio">Vendita e noleggio</option>
                  </select>
                </label>
                <label>
                  <span>Marca</span>
                  <select name="brand" defaultValue="">
                    <option value="">Qualsiasi</option>
                    <option>Porsche</option>
                    <option>Mercedes-Benz</option>
                    <option>Audi</option>
                    <option>BMW</option>
                    <option>Ducati</option>
                  </select>
                </label>
                <label>
                  <span>Budget</span>
                  <select name="maxPrice" defaultValue="">
                    <option value="">Da definire</option>
                    <option value="15000">Fino a 15.000 EUR</option>
                    <option value="30000">Fino a 30.000 EUR</option>
                    <option value="60000">Fino a 60.000 EUR</option>
                    <option value="150000">60.000 EUR+</option>
                  </select>
                </label>
              </div>
              <button className="btn btn-primary" type="submit">Mostra disponibilita</button>
            </form>
          </div>
        </section>

        <section className="showroom-section">
          <div className="wrap">
            <div className="section-head compact">
              <h2>Showroom selezionato.</h2>
              <p>Poche proposte, ordinate e leggibili. Foto dominanti, dati essenziali e percorsi rapidi verso contatto, visione e trattativa.</p>
            </div>

            <div className="featured-layout">
              <article className="featured-vehicle">
                <Image
                  src={premium.heroImage}
                  alt={`${premium.title} - immagine illustrativa`}
                  fill
                  sizes="(max-width: 900px) 100vw, 58vw"
                />
                <span className="image-disclaimer">Immagine illustrativa</span>
                <div>
                  <h3>{premium.title}</h3>
                  <p>{premium.year} / {formatNumber(premium.km)} km / {premium.fuel} / {premium.gearbox}</p>
                  <b>{formatCurrency(premium.price)}</b>
                  <Link className="btn btn-primary" href={`/veicoli/${premium.slug}`}>Richiedi questa auto</Link>
                </div>
              </article>

              <div className="featured-side">
                {featured.slice(1).map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} quiet />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section>
          <div className="wrap">
            <div className="section-head compact">
              <h2>Servizi chiari.</h2>
              <p>Ogni esigenza ha un percorso distinto: veicoli disponibili, noleggio, permuta, ricerca su misura, finanziamento e appuntamenti.</p>
            </div>
            <div className="services-grid">
              <ServiceTile icon="vehicles" title="Veicoli" text="Catalogo ordinato con schede e disponibilita." href="/veicoli" />
              <ServiceTile icon="rental" title="Noleggio" text="Giornaliero, settimanale, mensile e business." href="/noleggio" />
              <ServiceTile icon="trade" title="Permuta" text="Valutazione dell'usato come parte della trattativa." href="/permuta" />
              <ServiceTile icon="search" title="Su misura" text="Il veicolo non c'e? Lo cerchiamo con criteri chiari." href="/ricerca-su-richiesta" />
              <ServiceTile icon="finance" title="Finanziamento" text="Richiesta rata, anticipo e durata desiderata." href="/finanziamento" />
              <ServiceTile icon="booking" title="Appuntamento" text="Visione, test drive, noleggio o valutazione." href="#calendario" />
            </div>
          </div>
        </section>

        <section className="method-section">
          <div className="wrap method-strip">
            <div>
              <h2>Tre passaggi. Zero confusione.</h2>
            </div>
            <div className="method-steps">
              <article><b>01</b><h3>Racconti cosa cerchi</h3><p>Budget, uso, tempi, permuta e preferenze.</p></article>
              <article><b>02</b><h3>Ricevi una proposta chiara</h3><p>Disponibilita, condizioni, costi e appuntamento.</p></article>
              <article><b>03</b><h3>Vedi, provi, decidi</h3><p>Supporto fino alla consegna o al noleggio.</p></article>
            </div>
          </div>
        </section>

        <section id="calendario">
          <div className="wrap split-clean">
            <div>
              <h2>Richiedi una visione.</h2>
              <p className="lead small">Scegli il motivo dell&apos;incontro e lascia un contatto. Lo staff conferma disponibilita e orario prima della visita.</p>
            </div>
            <AppointmentRequestForm />
          </div>
        </section>

        <section className="cta-panel">
          <div className="wrap cta-inner">
            <h2>Vuoi saltare la ricerca infinita?</h2>
            <p>Invia budget, preferenze e tempi. Gamma One filtra le opzioni e ti richiama con una proposta concreta.</p>
            <Link className="btn btn-primary" href="/ricerca-su-richiesta">Apri richiesta prioritaria</Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
