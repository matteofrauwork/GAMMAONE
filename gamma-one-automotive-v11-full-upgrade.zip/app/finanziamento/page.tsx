import type { Metadata } from "next";
import { PublicLandingPage } from "@/components/public-sections";
import { LeadRequestForm } from "@/components/request-forms";

export const metadata: Metadata = {
  title: "Finanziamento veicoli",
  description: "Richiesta finanziamento per auto e moto: veicolo, anticipo, durata, rata desiderata e documenti da verificare.",
  alternates: { canonical: "/finanziamento" }
};

export default function FinancePage() {
  return (
    <PublicLandingPage
      title="Richiedi una proposta di finanziamento."
      subtitle="Indica veicolo, anticipo, durata desiderata e rata massima. La proposta va sempre confermata con condizioni reali e documentazione corretta."
      primaryHref="#richiesta"
      primaryLabel="Richiedi proposta"
      secondaryHref="/veicoli"
      secondaryLabel="Vedi veicoli"
    >
      <section id="richiesta">
        <div className="wrap split">
          <LeadRequestForm kind="finance" />
          <div className="panel">
            <h3>Nota corretta</h3>
            <p>Rate e condizioni non vanno inventate. Vanno calcolate e confermate con partner finanziario, TAN/TAEG e documenti reali.</p>
          </div>
        </div>
      </section>
    </PublicLandingPage>
  );
}
