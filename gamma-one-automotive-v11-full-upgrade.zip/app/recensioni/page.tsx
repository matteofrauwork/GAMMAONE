import type { Metadata } from "next";
import Link from "next/link";
import { Footer, Header } from "@/components/ui";
import { company } from "@/lib/company";

export const metadata: Metadata = {
  title: "Recensioni Gamma One",
  description: "Pagina pronta per collegare recensioni Google reali e testimonianze verificate Gamma One.",
  alternates: { canonical: "/recensioni" }
};

export default function ReviewsPage() {
  return (
    <div className="page">
      <Header />
      <main>
        <section className="subhero">
          <div className="wrap">
            <h1>Recensioni verificate, senza numeri inventati.</h1>
            <p>Questa sezione è pronta per ospitare recensioni Google reali e consegne documentate. Finché non sono collegati profili e prove verificabili, Gamma One non mostra valutazioni fittizie.</p>
            <div className="row-actions">
              {company.reviewsUrl ? <a className="btn btn-primary" href={company.reviewsUrl} target="_blank" rel="noreferrer">Apri recensioni Google</a> : null}
              <Link className="btn btn-secondary" href="/contatti">Parla con Gamma One</Link>
            </div>
          </div>
        </section>

        <section>
          <div className="wrap split">
            <div className="panel">
              <h3>Cosa verrà mostrato</h3>
              <div className="features">
                <div className="feature"><span className="check">1</span><span>Link diretto al profilo Google Business verificato.</span></div>
                <div className="feature"><span className="check">2</span><span>Recensioni reali, non copiate a mano senza fonte.</span></div>
                <div className="feature"><span className="check">3</span><span>Eventuali consegne pubblicate solo con immagini e consenso.</span></div>
              </div>
            </div>
            <div className="panel">
              <h3>Da completare</h3>
              <p className="notice">Serve il link ufficiale Google Reviews e una policy chiara su immagini, nomi e consenso dei clienti prima di pubblicare testimonianze o sezione consegnati con persone riconoscibili.</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
