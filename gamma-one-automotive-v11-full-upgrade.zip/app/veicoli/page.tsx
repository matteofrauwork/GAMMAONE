import type { Metadata } from "next";
import { Footer, Header } from "@/components/ui";
import { VehicleSearch } from "@/components/vehicle-search";
import { getPublicVehicles } from "@/lib/vehicle-repository";

export const metadata: Metadata = {
  title: "Catalogo veicoli",
  description: "Catalogo auto e moto Gamma One in Sardegna: vendita, noleggio, permuta e ricerca veicolo su richiesta.",
  alternates: { canonical: "/veicoli" }
};

type VehiclesPageProps = {
  searchParams?: Record<string, string | string[] | undefined>;
};

export default async function VehiclesPage({ searchParams = {} }: VehiclesPageProps) {
  const vehicles = await getPublicVehicles();

  return (
    <div className="page">
      <Header />
      <main>
        <VehicleSearch initialParams={searchParams} items={vehicles} />
      </main>
      <Footer />
    </div>
  );
}
