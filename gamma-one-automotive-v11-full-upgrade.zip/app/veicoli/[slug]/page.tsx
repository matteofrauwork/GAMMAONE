import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { LeadRequestForm } from "@/components/request-forms";
import { VehicleConversionPanel, VehicleMicroFacts } from "@/components/conversion-kit";
import { VehicleDecisionPanel, VehicleSpecNarrative, VehicleTransparencyBlock, VehicleTrustStrip } from "@/components/premium-vehicle-experience";
import { Footer, Header, VehicleCard } from "@/components/ui";
import { VehicleGallery } from "@/components/vehicle-gallery";
import { formatCurrency, formatNumber, vehicles as seedVehicles } from "@/lib/data";
import { getPublicVehicles, getVehicleBySlugFromRepository } from "@/lib/vehicle-repository";
import { buildFinanceWhatsApp, buildVehicleWhatsApp, hasCompanyWhatsApp } from "@/lib/whatsapp";

type Props = {
  params: { slug: string };
};

export function generateStaticParams() {
  return seedVehicles.map((vehicle) => ({ slug: vehicle.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const vehicle = await getVehicleBySlugFromRepository(params.slug);

  if (!vehicle) {
    return { title: "Veicolo non trovato" };
  }

  return {
    title: `${vehicle.title} ${vehicle.year}`,
    description: `${vehicle.title}, ${formatNumber(vehicle.km)} km, ${vehicle.fuel}, ${vehicle.gearbox}, prezzo ${formatCurrency(vehicle.price)}. Foto illustrative e disponibilita da confermare con Gamma One.`,
    alternates: { canonical: `/veicoli/${vehicle.slug}` },
    openGraph: {
      title: `${vehicle.title} ${vehicle.year}`,
      description: `${vehicle.brand} ${vehicle.model}, ${formatNumber(vehicle.km)} km, ${vehicle.status}. Dati e disponibilita da verificare con lo staff.`,
      images: [{ url: vehicle.heroImage }]
    }
  };
}

export default async function VehicleDetailPage({ params }: Props) {
  const vehicle = await getVehicleBySlugFromRepository(params.slug);

  if (!vehicle) {
    notFound();
  }

  if (vehicle.visibility && vehicle.visibility !== "public") {
    notFound();
  }

  const appointmentLabel = vehicle.service === "Noleggio" ? "Blocca richiesta noleggio" : "Prenota visione";
  const availabilityLabel = vehicle.service === "Noleggio" ? "Verifica date" : "Verifica subito";
  const directContactLabel = hasCompanyWhatsApp() ? availabilityLabel : "Richiedi info";
  const financeEnabled = vehicle.finance && vehicle.service !== "Noleggio";
  const galleryImages = vehicle.images?.length ? vehicle.images : [vehicle.heroImage];
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://gammaone.it";
  const publicVehicles = await getPublicVehicles();
  const similarVehicles = publicVehicles
    .filter((item) => item.slug !== vehicle.slug && (item.brand === vehicle.brand || item.body === vehicle.body || item.service === vehicle.service))
    .slice(0, 3);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: vehicle.title,
    brand: vehicle.brand,
    image: galleryImages,
    description: vehicle.description,
    offers: {
      "@type": "Offer",
      price: vehicle.price,
      priceCurrency: "EUR",
      availability: vehicle.status === "Disponibile" ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      seller: {
        "@type": "AutoDealer",
        name: "Gamma One"
      }
    }
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: siteUrl },
      { "@type": "ListItem", position: 2, name: "Veicoli", item: `${siteUrl}/veicoli` },
      { "@type": "ListItem", position: 3, name: vehicle.title, item: `${siteUrl}/veicoli/${vehicle.slug}` }
    ]
  };

  return (
    <div className="page">
      <Header />

      <main>
        <section className="detail-hero">
          <div className="wrap">
            <nav className="breadcrumb" aria-label="Percorso">
              <Link href="/">Home</Link>
              <span>/</span>
              <Link href="/veicoli">Veicoli</Link>
              <span>/</span>
              <span>{vehicle.title}</span>
            </nav>

            <div className="detail-grid">
              <VehicleGallery title={vehicle.title} images={galleryImages} />

              <aside className="detail-card detail-title">
                <VehicleTrustStrip vehicle={vehicle} />
                <h1>{vehicle.title}</h1>
                <p className="price">{vehicle.service === "Noleggio" && vehicle.rentDailyFrom ? `da ${formatCurrency(vehicle.rentDailyFrom)}/giorno` : formatCurrency(vehicle.price)}</p>
                <VehicleMicroFacts vehicle={vehicle} />
                {vehicle.monthlyFrom && financeEnabled ? <p className="micro">Rata indicativa da {formatCurrency(vehicle.monthlyFrom)}/mese, condizioni da confermare.</p> : null}
                <p>{vehicle.description}</p>

                <div className="detail-facts">
                  <div className="fact"><span>Anno</span><b>{vehicle.year}</b></div>
                  <div className="fact"><span>Immatricolazione</span><b>{vehicle.registrationMonth}</b></div>
                  <div className="fact"><span>Km</span><b>{formatNumber(vehicle.km)}</b></div>
                  <div className="fact"><span>Alimentazione</span><b>{vehicle.fuel}</b></div>
                  <div className="fact"><span>Cambio</span><b>{vehicle.gearbox}</b></div>
                  <div className="fact"><span>Potenza</span><b>{vehicle.powerHp} CV</b></div>
                  <div className="fact"><span>Cilindrata</span><b>{vehicle.displacement || "Da confermare"}</b></div>
                  <div className="fact"><span>Colore</span><b>{vehicle.color}</b></div>
                  <div className="fact"><span>Posti / porte</span><b>{vehicle.seats} / {vehicle.doors}</b></div>
                  <div className="fact"><span>Garanzia</span><b>{vehicle.warrantyMonths ? `${vehicle.warrantyMonths} mesi` : "Da confermare"}</b></div>
                  <div className="fact"><span>IVA</span><b>{vehicle.iva ? "Esposta" : "Da confermare"}</b></div>
                  <div className="fact"><span>Localita</span><b>{vehicle.location}</b></div>
                </div>

                <div className="row-actions" style={{ marginTop: 22 }}>
                  <Link className="btn btn-primary" href="/#calendario">{appointmentLabel}</Link>
                  <Link className="btn btn-secondary" href={buildVehicleWhatsApp(vehicle)}>{directContactLabel}</Link>
                  {financeEnabled ? <Link className="btn btn-secondary" href={buildFinanceWhatsApp(vehicle)}>Finanziamento</Link> : null}
                </div>

                {vehicle.videoUrl ? (
                  <div className="notice" style={{ marginTop: 18 }}>
                    <b>Video walkaround disponibile</b>
                    <p className="micro" style={{ marginTop: 6 }}>Il video deve essere verificato dallo staff insieme a foto, condizioni e disponibilita.</p>
                    <a className="btn btn-secondary btn-mini" href={vehicle.videoUrl} target="_blank" rel="noreferrer" style={{ marginTop: 12 }}>Apri video</a>
                  </div>
                ) : null}
              </aside>
            </div>
          </div>
        </section>

        <VehicleSpecNarrative vehicle={vehicle} />

        <VehicleConversionPanel vehicle={vehicle} />

        <section>
          <div className="wrap split">
            <div className="panel">
              <h3>Dotazioni</h3>
              <div className="chips" style={{ marginTop: 16 }}>
                {vehicle.equipment.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>
            </div>

            <div className="panel">
              <h3>Controlli e condizioni</h3>
              <div className="summary">
                <div className="summary-row"><span>Tagliandi</span><b>{vehicle.inspection.serviceHistory}</b></div>
                <div className="summary-row"><span>Gomme</span><b>{vehicle.inspection.tyres}</b></div>
                <div className="summary-row"><span>Freni</span><b>{vehicle.inspection.brakes}</b></div>
                <div className="summary-row"><span>Revisione</span><b>{vehicle.inspection.revision}</b></div>
                <div className="summary-row"><span>Proprietari</span><b>{vehicle.inspection.owners}</b></div>
              </div>
              <p className="notice">Da verificare prima della conferma: foto reali, documenti, garanzia, eventuali costi accessori, disponibilita, pagamento e consegna.</p>
            </div>
          </div>
        </section>

        <VehicleTransparencyBlock vehicle={vehicle} />

        <section>
          <div className="wrap">
            <VehicleDecisionPanel vehicle={vehicle} />
          </div>
        </section>

        {similarVehicles.length ? (
          <section>
            <div className="wrap">
              <div className="section-head compact">
                <div>
                  <h2>Alternative da valutare.</h2>
                </div>
                <p>Proposte vicine per categoria, servizio o posizionamento. Le disponibilita reali vanno confermate dallo staff.</p>
              </div>
              <div className="results-grid">
                {similarVehicles.map((item) => <VehicleCard key={item.id} vehicle={item} />)}
              </div>
            </div>
          </section>
        ) : null}

        <section>
          <div className="wrap split">
            <LeadRequestForm kind="vehicle" vehicleTitle={vehicle.title} vehicleSlug={vehicle.slug} />

            <div className="panel">
              <h3>Azioni commerciali</h3>
              <div className="features">
                <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Messaggio contestuale con veicolo gia incluso.</span></div>
                <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Richiesta visione collegata alla scheda e confermata dallo staff.</span></div>
                <div className="feature"><span className="check" aria-hidden="true">✓</span><span>Finanziamento, permuta o noleggio gestiti come richieste distinte.</span></div>
              </div>
            </div>
          </div>
        </section>

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify([jsonLd, breadcrumbJsonLd]) }}
        />
      </main>

      <div className="mobile-sticky-actions" aria-label="Azioni rapide veicolo">
        <Link className="btn btn-secondary btn-mini" href={buildVehicleWhatsApp(vehicle)}>{hasCompanyWhatsApp() ? "WhatsApp" : "Contatti"}</Link>
        <Link className="btn btn-primary btn-mini" href="/#calendario">{appointmentLabel}</Link>
        {financeEnabled ? <Link className="btn btn-secondary btn-mini" href={buildFinanceWhatsApp(vehicle)}>Finanzia</Link> : null}
      </div>

      <Footer />
    </div>
  );
}
