import { Footer, Header } from "@/components/ui";

export default function LegalPage() {
  return (
    <div className="page">
      <Header />
      <main className="wrap" style={{ padding: "90px 0" }}>
        <section className="panel legal-page">
          <h1 style={{ fontSize: 68, marginTop: 18 }}>Condizioni vendita</h1>
          <div className="legal-copy">
            <h2>Condizioni vendita veicoli</h2>
            <p>Bozza informativa generata per presentazione. Prima della pubblicazione definitiva va validata con le condizioni commerciali reali e con il consulente di riferimento.</p>
            <h3>Disponibilità e prezzo</h3>
            <p>La disponibilità del veicolo, il prezzo, eventuali promozioni, inclusioni ed esclusioni devono essere confermati prima della trattativa conclusiva. Eventuali errori materiali presenti nella scheda vengono corretti prima della conferma.</p>
            <h3>Documentazione del veicolo</h3>
            <p>Prima dell&apos;acquisto vengono verificati, quando applicabili, chilometraggio dichiarato, revisione, libretto, stato amministrativo, storico manutenzione disponibile, dotazioni e documentazione accessoria.</p>
            <h3>Garanzia, passaggio e IVA</h3>
            <p>Ogni proposta deve chiarire se garanzia, passaggio di proprietà, IVA, oneri amministrativi o servizi aggiuntivi sono inclusi o esclusi dal prezzo indicato.</p>
            <h3>Permuta e finanziamento</h3>
            <p>Eventuale permuta e finanziamento vengono valutati separatamente. La proposta finale dipende da stato del veicolo in permuta, documenti disponibili, anticipo, durata e approvazione dell&apos;ente finanziatore.</p>
            <h3>Conferma della vendita</h3>
            <p>La vendita si considera confermata solo dopo accettazione delle condizioni, verifica documentale e accordo scritto tra le parti.</p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
