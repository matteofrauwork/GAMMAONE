import type { Metadata } from "next";
import { PublicLandingPage } from "@/components/public-sections";
import { LeadRequestForm } from "@/components/request-forms";
import { company } from "@/lib/company";

export const metadata: Metadata = {
  title: "Contatti",
  description: "Contatta Gamma One per veicoli disponibili, noleggio, permuta, finanziamento o ricerca su richiesta in Sardegna.",
  alternates: { canonical: "/contatti" }
};

export default function ContactPage() {
  return (
    <PublicLandingPage
      title="Parla con chi segue davvero la trattativa."
      subtitle="Ricevimento su appuntamento. Per disponibilità veicoli, noleggio, permuta o ricerca su richiesta, il percorso migliore è lasciare una richiesta precisa e verificabile."
      primaryHref="/#calendario"
      primaryLabel="Richiedi appuntamento"
      secondaryHref="/veicoli"
      secondaryLabel="Vedi catalogo"
    >
      <section>
        <div className="wrap split">
          <div className="panel">
            <h3>Contatti</h3>
            <div className="summary">
              <div className="summary-row"><span>Telefono</span><b>{company.phone}</b></div>
              <div className="summary-row"><span>WhatsApp</span><b>{company.whatsapp}</b></div>
              <div className="summary-row"><span>Email</span><b>{company.email}</b></div>
              <div className="summary-row"><span>PEC</span><b>Da inserire</b></div>
              <div className="summary-row"><span>Ragione sociale</span><b>{company.legalName}</b></div>
              <div className="summary-row"><span>Partita IVA</span><b>{company.vatNumber.replace("P.IVA ", "")}</b></div>
              <div className="summary-row"><span>Sede legale</span><b>{company.registeredOffice}</b></div>
              <div className="summary-row"><span>Sede operativa</span><b>{company.operatingOffice}</b></div>
              <div className="summary-row"><span>Orari</span><b>{company.hours}</b></div>
            </div>
            {company.mapsUrl ? <a className="btn btn-secondary" href={company.mapsUrl} target="_blank" rel="noreferrer">Apri Google Maps</a> : null}
          </div>
          <LeadRequestForm kind="contact" />
        </div>
      </section>
    </PublicLandingPage>
  );
}
