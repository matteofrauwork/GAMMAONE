import type { Metadata } from "next";
import { Footer, Header, VehicleCard } from "@/components/ui";
import { getPublicVehiclesByStatus } from "@/lib/vehicle-repository";

export const metadata: Metadata = {
  title: "Veicoli consegnati",
  description: "Archivio veicoli consegnati Gamma One. Sezione premium da alimentare con foto e dati reali.",
  alternates: { canonical: "/consegnati" }
};

export default async function DeliveredVehiclesPage() {
  const vehicles = await getPublicVehiclesByStatus(["Venduto", "Noleggiato"]);

  return (
    <div className="page">
      <Header />
      <main>
        <section className="catalog-app">
          <div className="wrap">
            <div className="catalog-toolbar">
              <div>
                <h1>Veicoli consegnati.</h1>
                <p>Una sezione di fiducia da pubblicare solo con veicoli reali, consenso foto e informazioni verificabili.</p>
              </div>
            </div>

            {vehicles.length ? (
              <div className="results-grid">
                {vehicles.map((vehicle) => <VehicleCard key={vehicle.id} vehicle={vehicle} />)}
              </div>
            ) : (
              <div className="empty-state">
                <h3>Nessuna consegna pubblicata.</h3>
                <p>Quando ci saranno veicoli reali consegnati, questa pagina potra diventare una prova sociale elegante.</p>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
