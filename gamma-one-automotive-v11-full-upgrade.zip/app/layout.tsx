import type { Metadata } from "next";
import { Inter, Instrument_Serif, Space_Grotesk } from "next/font/google";
import type { ReactNode } from "react";
import { AnalyticsEvents } from "@/components/analytics-events";
import { CookieConsent } from "@/components/cookie-consent";
import { MotionEffects } from "@/components/motion-effects";
import { company } from "@/lib/company";
import "./globals.css";


const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap"
});

const instrument = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-serif",
  display: "swap"
});

const space = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-numeric",
  display: "swap"
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://gammaone.it";
const dealerJsonLd = {
  "@context": "https://schema.org",
  "@type": "AutoDealer",
  name: "Gamma One",
  legalName: company.legalName,
  vatID: company.vatNumber,
  url: siteUrl,
  address: {
    "@type": "PostalAddress",
    streetAddress: "Via Dei Fiori, 6",
    postalCode: "09040",
    addressLocality: "San Basilio",
    addressRegion: "SU",
    addressCountry: "IT"
  },
  areaServed: "Sardegna"
};

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  applicationName: "Gamma One",
  title: {
    default: "Gamma One | Auto e moto selezionate in Sardegna",
    template: "%s | Gamma One"
  },
  description: "Auto e moto selezionate in Sardegna: vendita, noleggio, permuta e ricerca veicolo su richiesta.",
  alternates: {
    canonical: "/"
  },
  openGraph: {
    title: "Gamma One | Auto e moto selezionate in Sardegna",
    description: "Auto e moto selezionate in Sardegna: vendita, noleggio, permuta e ricerca veicolo su richiesta.",
    type: "website",
    locale: "it_IT",
    siteName: "Gamma One"
  },
  twitter: {
    card: "summary_large_image",
    title: "Gamma One | Auto e moto selezionate in Sardegna",
    description: "Vendita, noleggio, permuta e ricerca veicolo su richiesta in Sardegna."
  },
  robots: {
    index: true,
    follow: true
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="it">
      <body className={`${inter.variable} ${instrument.variable} ${space.variable}`}>
        <MotionEffects />
        <AnalyticsEvents />
        {children}
        <CookieConsent />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(dealerJsonLd) }}
        />
      </body>
    </html>
  );
}
