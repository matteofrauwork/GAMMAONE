import { Footer, Header } from "@/components/ui";

export default function LegalPage() {
  return (
    <div className="page">
      <Header />
      <main className="wrap" style={{ padding: "90px 0" }}>
        <section className="panel legal-page">
          <h1 style={{ fontSize: 68, marginTop: 18 }}>Condizioni noleggio</h1>
          <div className="legal-copy">
            <h2>Condizioni noleggio</h2>
            <p>Bozza informativa generata per presentazione. Prima della pubblicazione definitiva va completata con tariffe, cauzioni, franchigie, coperture e regole operative reali.</p>
            <h3>Prenotazione e disponibilità</h3>
            <p>Disponibilità, categoria del veicolo, durata, luogo di ritiro e riconsegna devono essere confermati prima della prenotazione. La richiesta non costituisce conferma automatica del noleggio.</p>
            <h3>Documenti richiesti</h3>
            <p>Prima della consegna possono essere richiesti documento d&apos;identità, patente valida, codice fiscale, metodo di pagamento e ulteriori documenti in base al tipo di veicolo e durata.</p>
            <h3>Cauzione e coperture</h3>
            <p>L&apos;importo della cauzione, le modalità di blocco o restituzione, le coperture assicurative, le esclusioni e l&apos;eventuale franchigia devono essere comunicati prima della conferma.</p>
            <h3>Uso del veicolo</h3>
            <p>Il cliente deve ricevere condizioni chiare su chilometri inclusi, carburante, pulizia, danni, multe, ritardi, riconsegna, responsabilità e utilizzi non consentiti.</p>
            <h3>Ritiro e riconsegna</h3>
            <p>Il veicolo viene consegnato e riconsegnato secondo orari e luogo concordati. Eventuali danni o anomalie vengono annotati prima della partenza e al rientro.</p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
