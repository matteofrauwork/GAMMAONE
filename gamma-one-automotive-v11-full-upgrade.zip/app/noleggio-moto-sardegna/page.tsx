import type { Metadata } from "next";
import { LocalSeoPage } from "@/components/local-seo-page";

export const metadata: Metadata = {
  title: "Noleggio moto Sardegna",
  description: "Noleggio moto e scooter in Sardegna con richiesta disponibilita, documenti e condizioni da confermare.",
  alternates: { canonical: "/noleggio-moto-sardegna" }
};

export default function MotoRentalSardiniaPage() {
  return (
    <LocalSeoPage
      title="Noleggio moto e scooter in Sardegna."
      subtitle="Soluzioni leggere per spostamenti, estate e weekend. Disponibilita, cauzione e coperture devono essere confermate dallo staff."
      primaryHref="/noleggio"
      primaryLabel="Richiedi disponibilita"
      points={["Moto", "Scooter", "Weekend", "Documenti richiesti", "Coperture", "Ritiro concordato"]}
    />
  );
}
