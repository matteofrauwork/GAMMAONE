type EnvItem = {
  key: string;
  label: string;
  requiredForDeploy?: boolean;
  public?: boolean;
};

type EnvGroup = {
  name: string;
  items: EnvItem[];
};

export const envGroups: EnvGroup[] = [
  {
    name: "Sito e azienda",
    items: [
      { key: "NEXT_PUBLIC_SITE_URL", label: "URL pubblico", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_COMPANY_PHONE", label: "Telefono pubblico", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_COMPANY_WHATSAPP", label: "WhatsApp pubblico", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_COMPANY_EMAIL", label: "Email pubblica", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_COMPANY_MAPS_URL", label: "Google Maps", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_GOOGLE_REVIEWS_URL", label: "Recensioni Google", public: true },
      { key: "NEXT_PUBLIC_COMPANY_HOURS", label: "Orari", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_COMPANY_OPERATING_OFFICE", label: "Sede operativa", requiredForDeploy: true, public: true }
    ]
  },
  {
    name: "Supabase",
    items: [
      { key: "NEXT_PUBLIC_SUPABASE_URL", label: "Project URL", requiredForDeploy: true, public: true },
      { key: "NEXT_PUBLIC_SUPABASE_ANON_KEY", label: "Anon key", requiredForDeploy: true, public: true },
      { key: "SUPABASE_SERVICE_ROLE_KEY", label: "Service role key", requiredForDeploy: true }
    ]
  },
  {
    name: "Email",
    items: [
      { key: "RESEND_API_KEY", label: "Resend API key", requiredForDeploy: true },
      { key: "LEAD_NOTIFICATION_EMAIL", label: "Email ricezione richieste", requiredForDeploy: true },
      { key: "RESEND_FROM", label: "Mittente verificato", requiredForDeploy: true }
    ]
  },
  {
    name: "Calendario",
    items: [
      { key: "GOOGLE_CALENDAR_ID", label: "Calendario", requiredForDeploy: true },
      { key: "GOOGLE_CLIENT_EMAIL", label: "Service account email", requiredForDeploy: true },
      { key: "GOOGLE_PRIVATE_KEY", label: "Private key", requiredForDeploy: true }
    ]
  },
  {
    name: "WhatsApp",
    items: [
      { key: "WHATSAPP_PHONE_NUMBER_ID", label: "Cloud API phone ID" },
      { key: "WHATSAPP_ACCESS_TOKEN", label: "Cloud API token" }
    ]
  },
  {
    name: "Storage immagini",
    items: [
      { key: "CLOUDINARY_URL", label: "Cloudinary URL" },
      { key: "NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME", label: "Cloudinary cloud name", public: true },
      { key: "CLOUDINARY_API_KEY", label: "Cloudinary API key" },
      { key: "CLOUDINARY_API_SECRET", label: "Cloudinary secret" },
      { key: "S3_BUCKET", label: "S3 bucket" },
      { key: "S3_REGION", label: "S3 region" },
      { key: "S3_ACCESS_KEY_ID", label: "S3 access key" },
      { key: "S3_SECRET_ACCESS_KEY", label: "S3 secret" },
      { key: "S3_PUBLIC_BASE_URL", label: "S3 URL pubblico" }
    ]
  },
  {
    name: "Privacy",
    items: [
      { key: "COOKIE_CONSENT_VERSION", label: "Versione cookie", requiredForDeploy: true },
      { key: "NEXT_PUBLIC_COOKIE_CONSENT_VERSION", label: "Versione cookie pubblica", requiredForDeploy: true, public: true },
      { key: "PRIVACY_POLICY_VERSION", label: "Versione privacy", requiredForDeploy: true }
    ]
  }
];

export function getEnvReport() {
  return envGroups.map((group) => ({
    name: group.name,
    items: group.items.map((item) => ({
      ...item,
      configured: Boolean(process.env[item.key]),
      valuePreview: process.env[item.key] ? maskValue(process.env[item.key]!, item.public) : ""
    }))
  }));
}

export function getMissingRequiredEnv() {
  return getEnvReport().flatMap((group) => group.items.filter((item) => item.requiredForDeploy && !item.configured));
}

function maskValue(value: string, isPublic?: boolean) {
  if (isPublic) {
    return value;
  }

  if (value.length <= 8) {
    return "configurato";
  }

  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}
