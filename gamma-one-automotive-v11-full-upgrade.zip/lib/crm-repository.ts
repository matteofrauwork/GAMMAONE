import type { Customer, FollowUp } from "@/lib/types";

type Row = Record<string, any>;

export function normalizeCustomer(row: Row): Customer {
  return {
    id: String(row.id),
    createdAt: row.created_at || row.createdAt || new Date().toISOString(),
    name: row.name || "",
    phone: row.phone || "",
    email: row.email || undefined,
    source: row.source || "Manuale",
    interest: row.interest || "Da qualificare",
    status: row.status || "Nuovo",
    assignedTo: row.assigned_to || row.assignedTo || undefined,
    notes: row.notes || undefined
  };
}

export function normalizeFollowUp(row: Row): FollowUp {
  return {
    id: String(row.id),
    createdAt: row.created_at || row.createdAt || new Date().toISOString(),
    dueAt: row.due_at || row.dueAt || new Date().toISOString(),
    customerId: row.customer_id || row.customerId || undefined,
    leadId: row.lead_id || row.leadId || undefined,
    title: row.title || "Follow-up cliente",
    channel: row.channel || "Telefono",
    status: row.status || "Da fare",
    notes: row.notes || undefined
  };
}

export function customerToSupabaseRow(customer: Partial<Customer>) {
  return cleanRow({
    name: customer.name,
    phone: customer.phone,
    email: customer.email,
    source: customer.source,
    interest: customer.interest,
    status: customer.status,
    assigned_to: customer.assignedTo,
    notes: customer.notes
  });
}

export function followUpToSupabaseRow(followUp: Partial<FollowUp>) {
  return cleanRow({
    due_at: followUp.dueAt,
    customer_id: followUp.customerId,
    lead_id: followUp.leadId,
    title: followUp.title,
    channel: followUp.channel,
    status: followUp.status,
    notes: followUp.notes
  });
}

export function cleanRow(row: Record<string, unknown>) {
  return Object.fromEntries(Object.entries(row).filter(([, value]) => value !== undefined));
}
