import { text } from "@/lib/api/security";

export type ValidationResult<T> = { ok: true; value: T } | { ok: false; error: string };

export function isValidPhone(value: string) {
  const compact = value.replace(/[\s().-]/g, "");
  return /^\+?[0-9]{8,16}$/.test(compact);
}

export function isValidEmail(value: string) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export function validateLeadInput(body: Record<string, unknown>) {
  const name = text(body.name, 120);
  const phone = text(body.phone, 80);
  const email = text(body.email, 160);
  const message = text(body.message, 2400);
  const type = text(body.type, 120) || "Richiesta generica";
  const vehicleSlug = text(body.vehicleSlug, 160) || undefined;

  if (name.length < 2) return { ok: false, error: "Inserisci un nome valido." } as const;
  if (!isValidPhone(phone)) return { ok: false, error: "Inserisci un numero di telefono valido." } as const;
  if (!isValidEmail(email)) return { ok: false, error: "Inserisci un indirizzo email valido oppure lascialo vuoto." } as const;
  if (message.length < 8) return { ok: false, error: "Aggiungi almeno un dettaglio alla richiesta." } as const;

  return { ok: true, value: { name, phone, email: email || undefined, message, type, vehicleSlug } } as const;
}

export function validateAppointmentInput(body: Record<string, unknown>) {
  const name = text(body.name, 120);
  const phone = text(body.phone, 80);
  const email = text(body.email, 160);
  const reason = text(body.reason, 120) || "Appuntamento";
  const date = text(body.date, 40);
  const slot = text(body.slot, 40);
  const vehicle = text(body.vehicle, 160) || undefined;

  if (name.length < 2) return { ok: false, error: "Inserisci un nome valido." } as const;
  if (!isValidPhone(phone)) return { ok: false, error: "Inserisci un numero di telefono valido." } as const;
  if (!isValidEmail(email)) return { ok: false, error: "Inserisci un indirizzo email valido oppure lascialo vuoto." } as const;
  if (!date || !slot) return { ok: false, error: "Seleziona data e fascia oraria." } as const;

  return { ok: true, value: { name, phone, email: email || undefined, reason, date, slot, vehicle } } as const;
}
