export const company = {
  legalName: "Gamma One Srl Semplificata",
  vatNumber: "P.IVA 04216800922",
  registeredOffice: "Via Dei Fiori, 6 - 09040 San Basilio (SU)",
  phone: process.env.NEXT_PUBLIC_COMPANY_PHONE || "Da inserire",
  whatsapp: process.env.NEXT_PUBLIC_COMPANY_WHATSAPP || "Da inserire",
  email: process.env.NEXT_PUBLIC_COMPANY_EMAIL || "Da inserire",
  mapsUrl: process.env.NEXT_PUBLIC_COMPANY_MAPS_URL || "",
  reviewsUrl: process.env.NEXT_PUBLIC_GOOGLE_REVIEWS_URL || "",
  hours: process.env.NEXT_PUBLIC_COMPANY_HOURS || "Da confermare",
  operatingOffice: process.env.NEXT_PUBLIC_COMPANY_OPERATING_OFFICE || "Da confermare"
};
