import { vehicles as seedVehicles } from "@/lib/data";
import { readDb } from "@/lib/store";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { Vehicle } from "@/lib/types";

type SupabaseVehicleRow = Record<string, any>;

export function normalizeVehicle(row: SupabaseVehicleRow): Vehicle {
  return {
    id: String(row.id),
    slug: row.slug,
    title: row.title,
    brand: row.brand,
    model: row.model,
    version: row.version || "",
    year: Number(row.year || new Date().getFullYear()),
    registrationMonth: row.registration_month || row.registrationMonth || "Da inserire",
    km: Number(row.km || 0),
    price: Number(row.price || 0),
    monthlyFrom: row.monthly_from ?? row.monthlyFrom ?? undefined,
    rentDailyFrom: row.rent_daily_from ?? row.rentDailyFrom ?? undefined,
    location: row.location || "Sardegna",
    distanceKm: Number(row.distance_km || row.distanceKm || 0),
    body: row.body || "Berlina",
    fuel: row.fuel || "Benzina",
    gearbox: row.gearbox || "Manuale",
    powerHp: Number(row.power_hp || row.powerHp || 0),
    displacement: row.displacement || undefined,
    doors: Number(row.doors || 5),
    seats: Number(row.seats || 5),
    color: row.color || "Da inserire",
    seller: row.seller || "Gamma One",
    service: row.service || "Vendita",
    status: row.status || "Disponibile",
    visibility: row.visibility || "public",
    warrantyMonths: row.warranty_months ?? row.warrantyMonths ?? undefined,
    finance: Boolean(row.finance),
    iva: Boolean(row.iva),
    neopatentati: Boolean(row.neopatentati),
    equipment: Array.isArray(row.equipment) ? row.equipment : [],
    images: Array.isArray(row.images) ? row.images : row.hero_image ? [row.hero_image] : [],
    heroImage: row.hero_image || row.heroImage || "/media/vehicles/supercar-coupe.svg",
    videoUrl: row.video_url || row.videoUrl || undefined,
    description: row.description || "Descrizione da completare.",
    highlights: Array.isArray(row.highlights) ? row.highlights : [],
    inspection: row.inspection || {
      serviceHistory: "Da verificare",
      tyres: "Da verificare",
      brakes: "Da verificare",
      revision: "Da verificare",
      owners: "Da verificare"
    }
  };
}

export function vehicleToSupabaseRow(vehicle: Partial<Vehicle>) {
  return {
    slug: vehicle.slug,
    title: vehicle.title,
    brand: vehicle.brand,
    model: vehicle.model,
    version: vehicle.version,
    year: vehicle.year,
    registration_month: vehicle.registrationMonth,
    km: vehicle.km,
    price: vehicle.price,
    monthly_from: vehicle.monthlyFrom,
    rent_daily_from: vehicle.rentDailyFrom,
    location: vehicle.location,
    distance_km: vehicle.distanceKm,
    body: vehicle.body,
    fuel: vehicle.fuel,
    gearbox: vehicle.gearbox,
    power_hp: vehicle.powerHp,
    displacement: vehicle.displacement,
    doors: vehicle.doors,
    seats: vehicle.seats,
    color: vehicle.color,
    seller: vehicle.seller,
    service: vehicle.service,
    status: vehicle.status,
    visibility: vehicle.visibility,
    warranty_months: vehicle.warrantyMonths,
    finance: vehicle.finance,
    iva: vehicle.iva,
    neopatentati: vehicle.neopatentati,
    description: vehicle.description,
    hero_image: vehicle.heroImage,
    video_url: vehicle.videoUrl,
    images: vehicle.images,
    equipment: vehicle.equipment,
    highlights: vehicle.highlights,
    inspection: vehicle.inspection
  };
}

export function cleanSupabaseRow(row: Record<string, unknown>) {
  return Object.fromEntries(Object.entries(row).filter(([, value]) => value !== undefined));
}

async function readMockVehicles() {
  try {
    const db = await readDb();
    return db.vehicles;
  } catch {
    return seedVehicles;
  }
}

export async function getPublicVehicles() {
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("vehicles")
      .select("*")
      .eq("visibility", "public")
      .in("status", ["Disponibile", "In arrivo", "Prenotato"])
      .order("created_at", { ascending: false });

    if (!error && data) {
      return data.map(normalizeVehicle);
    }
  }

  const vehicles = await readMockVehicles();
  return vehicles.filter((vehicle) => vehicle.visibility !== "hidden" && vehicle.status !== "Venduto");
}

export async function getPublicVehiclesByStatus(statuses: string[]) {
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("vehicles")
      .select("*")
      .eq("visibility", "public")
      .in("status", statuses)
      .order("created_at", { ascending: false });

    if (!error && data) {
      return data.map(normalizeVehicle);
    }
  }

  const vehicles = await readMockVehicles();
  return vehicles.filter((vehicle) => vehicle.visibility !== "hidden" && statuses.includes(vehicle.status));
}

export async function getAllVehicles() {
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase.from("vehicles").select("*").order("created_at", { ascending: false });
    if (!error && data) {
      return data.map(normalizeVehicle);
    }
  }

  return readMockVehicles();
}

export async function getVehicleBySlugFromRepository(slug: string) {
  const supabase = createSupabaseAdminClient();

  if (supabase) {
    const { data, error } = await supabase
      .from("vehicles")
      .select("*")
      .eq("slug", slug)
      .maybeSingle();

    if (!error && data) {
      return normalizeVehicle(data);
    }
  }

  const vehicles = await readMockVehicles();
  return vehicles.find((vehicle) => vehicle.slug === slug);
}
