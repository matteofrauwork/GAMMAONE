import type { Vehicle } from "./types";

export function vehicleQualityScore(vehicle: Vehicle) {
  const checks = [
    Boolean(vehicle.title),
    Boolean(vehicle.price || vehicle.rentDailyFrom),
    Boolean(vehicle.year),
    Boolean(vehicle.km >= 0),
    Boolean(vehicle.heroImage),
    Boolean(vehicle.images && vehicle.images.length >= 4),
    Boolean(vehicle.description && vehicle.description.length > 80),
    Boolean(vehicle.warrantyMonths),
    Boolean(vehicle.inspection?.revision),
    Boolean(vehicle.inspection?.tyres),
    Boolean(vehicle.equipment?.length >= 4),
    Boolean(vehicle.location),
    typeof vehicle.finance === "boolean",
    typeof vehicle.iva === "boolean",
    typeof vehicle.neopatentati === "boolean"
  ];

  const passed = checks.filter(Boolean).length;
  return Math.round((passed / checks.length) * 100);
}

export function missingVehicleFields(vehicle: Vehicle) {
  const missing: string[] = [];

  if (!vehicle.title) missing.push("Titolo");
  if (!vehicle.price && !vehicle.rentDailyFrom) missing.push("Prezzo");
  if (!vehicle.heroImage) missing.push("Immagine copertina");
  if (!vehicle.images || vehicle.images.length < 4) missing.push("Almeno 4 foto");
  if (!vehicle.description || vehicle.description.length < 80) missing.push("Descrizione completa");
  if (!vehicle.warrantyMonths) missing.push("Garanzia");
  if (!vehicle.inspection?.revision) missing.push("Revisione");
  if (!vehicle.inspection?.tyres) missing.push("Stato gomme");
  if (!vehicle.equipment?.length) missing.push("Dotazioni");
  if (!vehicle.location) missing.push("Località");

  return missing;
}
