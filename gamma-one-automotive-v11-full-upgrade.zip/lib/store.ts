import { promises as fs } from "fs";
import path from "path";
import { demoAppointments, demoLeads, vehicles } from "./data";
import type { Appointment, Customer, FollowUp, Lead, Vehicle } from "./types";

const dbPath = path.join(process.cwd(), "data", "mock-db.json");

type MockDb = {
  vehicles: Vehicle[];
  leads: Lead[];
  appointments: Appointment[];
  customers?: Customer[];
  followUps?: FollowUp[];
  consents?: Array<Record<string, unknown>>;
  analyticsEvents?: Array<Record<string, unknown>>;
};

async function ensureDb(): Promise<void> {
  try {
    await fs.access(dbPath);
  } catch {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const initial: MockDb = {
      vehicles,
      leads: demoLeads,
      appointments: demoAppointments
    };
    await fs.writeFile(dbPath, JSON.stringify(initial, null, 2), "utf-8");
  }
}

export async function readDb(): Promise<MockDb> {
  await ensureDb();
  const raw = await fs.readFile(dbPath, "utf-8");
  return JSON.parse(raw) as MockDb;
}

export async function writeDb(db: MockDb): Promise<void> {
  await fs.mkdir(path.dirname(dbPath), { recursive: true });
  await fs.writeFile(dbPath, JSON.stringify(db, null, 2), "utf-8");
}
