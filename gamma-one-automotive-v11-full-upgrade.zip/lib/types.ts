export type VehicleStatus = "Disponibile" | "Venduto" | "Prenotato" | "In arrivo" | "Noleggiato";
export type VehicleService = "Vendita" | "Noleggio" | "Vendita/Noleggio";
export type VehicleVisibility = "public" | "draft" | "hidden";
export type Gearbox = "Manuale" | "Automatico";
export type Fuel = "Benzina" | "Diesel" | "Ibrida" | "Elettrica" | "GPL/Metano";
export type Seller = "Gamma One" | "Dealer partner" | "Privato verificato";
export type AdminRole = "owner" | "staff" | "editor" | "viewer";

export type Vehicle = {
  id: string;
  slug: string;
  title: string;
  brand: string;
  model: string;
  version: string;
  year: number;
  registrationMonth: string;
  km: number;
  price: number;
  monthlyFrom?: number;
  rentDailyFrom?: number;
  location: string;
  distanceKm: number;
  body: string;
  fuel: Fuel;
  gearbox: Gearbox;
  powerHp: number;
  displacement?: string;
  doors: number;
  seats: number;
  color: string;
  seller: Seller;
  service: VehicleService;
  status: VehicleStatus;
  visibility?: VehicleVisibility;
  warrantyMonths?: number;
  finance: boolean;
  iva: boolean;
  neopatentati: boolean;
  equipment: string[];
  images: string[];
  heroImage: string;
  videoUrl?: string;
  description: string;
  highlights: string[];
  inspection: {
    serviceHistory: string;
    tyres: string;
    brakes: string;
    revision: string;
    owners: string;
  };
};

export type Customer = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  email?: string;
  source: string;
  interest: string;
  status: "Nuovo" | "Attivo" | "In follow-up" | "Cliente" | "Non interessato";
  assignedTo?: string;
  notes?: string;
};

export type FollowUp = {
  id: string;
  createdAt: string;
  dueAt: string;
  customerId?: string;
  leadId?: string;
  title: string;
  channel: "Telefono" | "WhatsApp" | "Email" | "Appuntamento";
  status: "Da fare" | "Completato" | "Saltato";
  notes?: string;
};

export type Lead = {
  id: string;
  createdAt: string;
  name: string;
  phone: string;
  email?: string;
  type: string;
  message: string;
  vehicleSlug?: string;
  status: "Nuovo" | "Contattato" | "In trattativa" | "Chiuso" | "Perso";
  score: number;
};

export type Appointment = {
  id: string;
  createdAt: string;
  date: string;
  slot: string;
  reason: string;
  name: string;
  phone: string;
  email?: string;
  vehicle?: string;
  status: "Richiesto" | "Confermato" | "Completato" | "Annullato";
};

export type SearchFilters = {
  intent: "Compra" | "Noleggia" | "Ricerca su richiesta" | "Permuta";
  brand: string;
  model: string;
  keyword: string;
  location: string;
  radius: number;
  priceMin: number;
  priceMax: number;
  monthlyMax: number;
  yearMin: number;
  yearMax: number;
  kmMax: number;
  powerMin: number;
  powerMax: number;
  doors: string;
  seats: string;
  seller: string;
  body: string[];
  fuel: string[];
  gearbox: string[];
  equipment: string[];
  color: string;
  warranty: boolean;
  neopatentati: boolean;
  finance: boolean;
  iva: boolean;
  order: string;
};
