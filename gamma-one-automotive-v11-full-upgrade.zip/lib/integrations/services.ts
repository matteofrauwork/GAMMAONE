import { Resend } from "resend";
import { google } from "googleapis";
import { v2 as cloudinary } from "cloudinary";
import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

export function buildWhatsAppLink(input: {
  phone?: string;
  name?: string;
  message: string;
  vehicle?: string;
}) {
  const phone = (input.phone || process.env.NEXT_PUBLIC_COMPANY_WHATSAPP || "").replace(/\D/g, "");
  if (!phone) {
    return "/contatti";
  }

  const lines = [
    input.name ? `Nome: ${input.name}` : "",
    input.vehicle ? `Veicolo: ${input.vehicle}` : "",
    input.message
  ].filter(Boolean);

  return `https://wa.me/${phone}?text=${encodeURIComponent(lines.join("\n"))}`;
}

export async function sendLeadEmail(input: {
  subject: string;
  html: string;
  replyTo?: string;
}) {
  if (!process.env.RESEND_API_KEY) {
    return { skipped: true, reason: "RESEND_API_KEY mancante" };
  }

  const resend = new Resend(process.env.RESEND_API_KEY);
  const to = process.env.LEAD_NOTIFICATION_EMAIL || process.env.NEXT_PUBLIC_COMPANY_EMAIL;
  const from = process.env.RESEND_FROM || "Gamma One <onboarding@resend.dev>";

  if (!to) {
    return { skipped: true, reason: "LEAD_NOTIFICATION_EMAIL mancante" };
  }

  return resend.emails.send({
    from,
    to,
    subject: input.subject,
    html: input.html,
    replyTo: input.replyTo
  });
}

export async function sendWhatsAppTemplate(input: {
  to: string;
  body: string;
}) {
  if (!process.env.WHATSAPP_PHONE_NUMBER_ID || !process.env.WHATSAPP_ACCESS_TOKEN) {
    return {
      skipped: true,
      reason: "WhatsApp Cloud API non configurata",
      fallback: buildWhatsAppLink({ phone: input.to, message: input.body })
    };
  }

  const url = `https://graph.facebook.com/v19.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: input.to.replace(/\D/g, ""),
      type: "text",
      text: { body: input.body }
    })
  });

  const data = await response.json();
  return { ok: response.ok, data };
}

export async function createGoogleCalendarEvent(input: {
  summary: string;
  description?: string;
  startDateTime: string;
  endDateTime: string;
  attendeeEmail?: string;
}) {
  if (!process.env.GOOGLE_CLIENT_EMAIL || !process.env.GOOGLE_PRIVATE_KEY || !process.env.GOOGLE_CALENDAR_ID) {
    return { skipped: true, reason: "Google Calendar non configurato" };
  }

  const auth = new google.auth.JWT({
    email: process.env.GOOGLE_CLIENT_EMAIL,
    key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, "\n"),
    scopes: ["https://www.googleapis.com/auth/calendar"]
  });

  const calendar = google.calendar({ version: "v3", auth });

  const event = {
    summary: input.summary,
    description: input.description,
    start: { dateTime: input.startDateTime, timeZone: "Europe/Rome" },
    end: { dateTime: input.endDateTime, timeZone: "Europe/Rome" },
    attendees: input.attendeeEmail ? [{ email: input.attendeeEmail }] : undefined
  };

  return calendar.events.insert({
    calendarId: process.env.GOOGLE_CALENDAR_ID,
    requestBody: event
  });
}


async function uploadImageToS3(file: File) {
  const bucket = process.env.S3_BUCKET;
  const region = process.env.S3_REGION;
  const accessKeyId = process.env.S3_ACCESS_KEY_ID;
  const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;

  if (!bucket || !region || !accessKeyId || !secretAccessKey) {
    return null;
  }

  const client = new S3Client({
    region,
    credentials: {
      accessKeyId,
      secretAccessKey
    }
  });

  const key = `gamma-one/vehicles/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "-")}`;
  const bytes = Buffer.from(await file.arrayBuffer());

  await client.send(new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: bytes,
    ContentType: file.type
  }));

  return {
    provider: "s3",
    key,
    url: process.env.S3_PUBLIC_BASE_URL ? `${process.env.S3_PUBLIC_BASE_URL.replace(/\/$/, "")}/${key}` : key
  };
}

export async function uploadImageToStorage(file: File) {
  const s3Result = await uploadImageToS3(file);
  if (s3Result) {
    return s3Result;
  }

  return uploadImageToCloudinary(file);
}

export async function uploadImageToCloudinary(file: File) {
  if (!process.env.CLOUDINARY_URL && !(process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET && process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME)) {
    return { skipped: true, reason: "Cloudinary non configurato" };
  }

  if (process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
    cloudinary.config({
      cloud_name: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_API_SECRET
    });
  }

  const bytes = Buffer.from(await file.arrayBuffer());

  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder: "gamma-one/vehicles",
        resource_type: "image",
        transformation: [
          { width: 1600, height: 1000, crop: "limit", quality: "auto", fetch_format: "auto" }
        ]
      },
      (error, result) => {
        if (error) reject(error);
        else resolve(result);
      }
    );

    stream.end(bytes);
  });
}
