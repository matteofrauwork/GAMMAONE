import type { Vehicle } from "./types";
import { formatCurrency, formatNumber } from "./data";

export function whatsappNumber() {
  return (process.env.NEXT_PUBLIC_COMPANY_WHATSAPP || "").replace(/\D/g, "");
}

export function hasCompanyWhatsApp() {
  return whatsappNumber().length >= 8;
}

function buildWhatsAppHref(message: string) {
  const phone = whatsappNumber();
  return phone ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}` : "/contatti";
}

export function buildVehicleWhatsApp(vehicle: Vehicle) {
  const price = vehicle.service === "Noleggio" && vehicle.rentDailyFrom
    ? `da ${formatCurrency(vehicle.rentDailyFrom)}/giorno`
    : formatCurrency(vehicle.price);

  const message = `Ciao, sono interessato a ${vehicle.title} (${vehicle.year}, ${formatNumber(vehicle.km)} km, ${price}). È ancora disponibile?`;
  return buildWhatsAppHref(message);
}

export function buildFinanceWhatsApp(vehicle: Vehicle) {
  const message = `Ciao, vorrei valutare un finanziamento per ${vehicle.title}. Posso indicarti anticipo, durata desiderata e rata indicativa.`;
  return buildWhatsAppHref(message);
}

export function buildRentalWhatsApp(input?: string) {
  const message = input || "Ciao, vorrei informazioni per un noleggio auto/moto. Posso indicarti date, durata e categoria desiderata.";
  return buildWhatsAppHref(message);
}

export function buildCustomSearchWhatsApp() {
  const message = "Ciao, cerco un veicolo su richiesta. Vorrei indicarvi budget, modello, km massimi, anno minimo, cambio, alimentazione e tempistiche.";
  return buildWhatsAppHref(message);
}

export function buildTradeInWhatsApp() {
  const message = "Ciao, vorrei valutare il mio veicolo in permuta. Posso inviarvi marca, modello, anno, km e foto.";
  return buildWhatsAppHref(message);
}
