import type { Lead, Vehicle } from "@/lib/types";

export function vehicleCompleteness(vehicle: Vehicle) {
  const checks: Array<[boolean, string]> = [
    [Boolean(vehicle.title && vehicle.brand && vehicle.model && vehicle.version), "Identità veicolo"],
    [Boolean(vehicle.price > 0 || vehicle.rentDailyFrom), "Prezzo o tariffa"],
    [Boolean(vehicle.year && vehicle.km >= 0 && vehicle.fuel && vehicle.gearbox), "Dati tecnici base"],
    [Boolean(vehicle.powerHp && vehicle.displacement), "Motore e potenza"],
    [Boolean(vehicle.warrantyMonths), "Garanzia"],
    [Boolean(vehicle.equipment?.length >= 5), "Dotazioni"],
    [Boolean(vehicle.images?.length >= 4), "Gallery reale"],
    [Boolean(vehicle.description && vehicle.description.length > 220), "Descrizione commerciale"],
    [Boolean(vehicle.highlights?.length >= 3), "Punti forti"],
    [Boolean(vehicle.inspection?.serviceHistory && vehicle.inspection.serviceHistory !== "Da verificare"), "Storico tagliandi"],
    [Boolean(vehicle.inspection?.tyres && vehicle.inspection.tyres !== "Da verificare"), "Stato gomme"],
    [Boolean(vehicle.inspection?.revision && vehicle.inspection.revision !== "Da verificare"), "Revisione"],
  ];

  const completed = checks.filter(([ok]) => ok).length;
  const missing = checks.filter(([ok]) => !ok).map(([, label]) => label);
  const score = Math.round((completed / checks.length) * 100);

  return {
    score,
    completed,
    total: checks.length,
    missing,
    level: score >= 86 ? "Pronta" : score >= 65 ? "Da rifinire" : "Debole"
  };
}

export function vehicleCommercialBadges(vehicle: Vehicle) {
  const badges: string[] = [vehicle.status, vehicle.service];
  if (vehicle.finance) badges.push("Finanziabile");
  if (vehicle.warrantyMonths) badges.push(`${vehicle.warrantyMonths} mesi garanzia`);
  if (vehicle.neopatentati) badges.push("Neopatentati");
  if (vehicle.iva) badges.push("IVA esposta");
  return Array.from(new Set(badges)).slice(0, 5);
}

export function leadPriority(lead: Pick<Lead, "score" | "status" | "phone" | "message" | "vehicleSlug">) {
  let score = Number(lead.score || 0);
  if (lead.phone) score += 12;
  if (lead.vehicleSlug) score += 18;
  if ((lead.message || "").length > 80) score += 8;
  if (lead.status === "Nuovo") score += 10;

  if (score >= 72) return { label: "Caldo", score, nextAction: "Chiamare oggi e proporre appuntamento." };
  if (score >= 42) return { label: "Tiepido", score, nextAction: "Rispondere entro 24h e qualificare budget/esigenza." };
  return { label: "Freddo", score, nextAction: "Follow-up leggero, senza perdere troppo tempo." };
}
