import { NextResponse } from "next/server";
import type { AdminRole } from "@/lib/types";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient, hasSupabaseEnv } from "@/lib/supabase/server";

const rateBuckets = new Map<string, { count: number; resetAt: number }>();

export function getClientIp(request: Request) {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "local"
  );
}

export function rateLimit(request: Request, key: string, limit = 12, windowMs = 60_000) {
  const bucketKey = `${key}:${getClientIp(request)}`;
  const now = Date.now();
  const current = rateBuckets.get(bucketKey);

  if (!current || current.resetAt < now) {
    rateBuckets.set(bucketKey, { count: 1, resetAt: now + windowMs });
    return null;
  }

  if (current.count >= limit) {
    return NextResponse.json({ error: "Troppe richieste. Riprova tra poco." }, { status: 429 });
  }

  current.count += 1;
  return null;
}

export async function getAdminRole(): Promise<AdminRole | null> {
  const supabase = createSupabaseServerClient();
  const { data, error } = supabase ? await supabase.auth.getUser() : { data: { user: null }, error: null };

  if (error || !data.user) {
    return null;
  }

  const metadataRole = data.user.app_metadata?.role;
  if (metadataRole && ["owner", "staff", "editor", "viewer"].includes(String(metadataRole))) {
    return metadataRole as AdminRole;
  }

  const adminSupabase = createSupabaseAdminClient();
  if (!adminSupabase) {
    return null;
  }

  const { data: profile } = await adminSupabase
    .from("admin_profiles")
    .select("role, active")
    .eq("id", data.user.id)
    .maybeSingle();

  if (!profile?.active || !profile.role) {
    return null;
  }

  return profile.role as AdminRole;
}

export async function requireAdmin(_request: Request, allowedRoles: AdminRole[] = ["owner", "staff", "editor", "viewer"]) {
  if (!hasSupabaseEnv()) {
    if (process.env.NODE_ENV === "production") {
      return NextResponse.json({ error: "Area admin non configurata." }, { status: 503 });
    }

    return null;
  }

  const role = await getAdminRole();

  if (!role) {
    return NextResponse.json({ error: "Accesso non autorizzato." }, { status: 401 });
  }

  if (!allowedRoles.includes(role)) {
    return NextResponse.json({ error: "Permessi insufficienti." }, { status: 403 });
  }

  return null;
}

export function text(value: unknown, max = 800) {
  return String(value || "").trim().slice(0, max);
}

export function numberValue(value: unknown, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function boolValue(value: unknown) {
  return value === true || value === "true" || value === 1 || value === "1";
}

export function isHoneypotFilled(body: Record<string, unknown>) {
  return Boolean(text(body.companyWebsite, 120));
}

export function escapeHtml(value: unknown) {
  return text(value, 4000)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function validateImageFile(file: File, maxBytes = 8 * 1024 * 1024) {
  const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/avif"];

  if (!allowedTypes.includes(file.type)) {
    return "Formato non valido. Carica un'immagine.";
  }

  if (file.size > maxBytes) {
    return "Immagine troppo pesante. Limite massimo 8 MB.";
  }

  return "";
}
