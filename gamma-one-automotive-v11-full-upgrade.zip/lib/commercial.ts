import type { Lead, Vehicle } from "@/lib/types";

export type FinanceEstimate = {
  downPayment: number;
  financedAmount: number;
  months: number;
  apr: number;
  monthly: number;
  totalCreditCost: number;
};

export function estimateFinance(vehicle: Vehicle, months = 72, apr = 8.9, downPaymentRate = 0.18): FinanceEstimate {
  const safeMonths = Math.max(12, Math.min(96, Math.round(months)));
  const downPayment = Math.round(vehicle.price * downPaymentRate);
  const financedAmount = Math.max(0, vehicle.price - downPayment);
  const monthlyRate = apr / 100 / 12;
  const monthly = monthlyRate > 0
    ? Math.round((financedAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -safeMonths)))
    : Math.round(financedAmount / safeMonths);

  return {
    downPayment,
    financedAmount,
    months: safeMonths,
    apr,
    monthly,
    totalCreditCost: Math.max(0, monthly * safeMonths + downPayment - vehicle.price)
  };
}

export function vehicleFitScore(vehicle: Vehicle) {
  let score = 50;
  const reasons: string[] = [];

  if (vehicle.status === "Disponibile") {
    score += 12;
    reasons.push("disponibile subito");
  }
  if (vehicle.finance) {
    score += 10;
    reasons.push("finanziabile");
  }
  if (vehicle.warrantyMonths && vehicle.warrantyMonths >= 12) {
    score += 10;
    reasons.push("garanzia forte");
  }
  if (vehicle.km < 80000) {
    score += 8;
    reasons.push("km interessanti");
  }
  if (vehicle.images.length > 3) {
    score += 6;
    reasons.push("galleria completa");
  }
  if (vehicle.inspection.serviceHistory !== "Da verificare") {
    score += 6;
    reasons.push("storico manutenzione chiaro");
  }
  if (vehicle.iva) {
    score += 4;
    reasons.push("IVA esposta");
  }
  if (vehicle.neopatentati) {
    score += 4;
    reasons.push("ok neopatentati");
  }

  const finalScore = Math.min(100, score);
  const label = finalScore >= 85 ? "Molto forte" : finalScore >= 70 ? "Solido" : finalScore >= 55 ? "Da verificare bene" : "Scheda debole";

  return { score: finalScore, label, reasons: reasons.slice(0, 4) };
}

export function nextBestActionForVehicle(vehicle: Vehicle) {
  if (vehicle.status === "Venduto") return "Tieni la scheda come prova sociale e spingi alternative simili.";
  if (vehicle.status === "In arrivo") return "Raccogli richieste prima dell'arrivo e crea lista interessati.";
  if (vehicle.service === "Noleggio") return "Porta l'utente su verifica date, cauzione e condizioni noleggio.";
  if (vehicle.finance) return "Spingi finanziamento + permuta: abbassa la barriera di contatto.";
  return "Spingi appuntamento e WhatsApp: il contatto rapido vale piu del form lungo.";
}

export function leadTemperature(lead: Lead) {
  const base = lead.score || 0;
  if (base >= 80) return { label: "Caldo", action: "Chiamare entro 15 minuti", className: "is-hot" };
  if (base >= 60) return { label: "Tiepido", action: "WhatsApp + follow-up entro oggi", className: "is-warm" };
  return { label: "Freddo", action: "Qualificare con messaggio breve", className: "is-cold" };
}
